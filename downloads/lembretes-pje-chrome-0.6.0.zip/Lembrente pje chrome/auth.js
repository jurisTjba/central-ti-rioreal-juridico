/* =========================================================================
   auth.js — autenticação por e-mail/senha via Firebase Auth (Identity
   Toolkit), por REST. Mesma filosofia do firestore.js: sem SDK, só fetch.

   Reaproveita FIRESTORE_CONFIG.apiKey (definido em firestore.js), que deve
   ser carregado ANTES deste arquivo.

   A sessão { uid, email, idToken, refreshToken, expiraEm } fica em
   api.storage.local (NÃO em sync): o refreshToken é uma credencial e não
   deve viajar entre dispositivos. O idToken vale ~1h; o refreshToken não
   expira, então o usuário entra uma vez e a sessão se renova sozinha.
   ========================================================================= */

const AUTH_BASE = "https://identitytoolkit.googleapis.com/v1/accounts";
const TOKEN_URL = "https://securetoken.googleapis.com/v1/token";
const MARGEM_MS = 5 * 60 * 1000;   // renova o idToken 5 min antes de expirar

// Chamada aos endpoints de conta (signUp / signInWithPassword). Devolve a
// sessão já normalizada e persistida.
async function _authFetch(endpoint, body) {
  const resp = await fetch(`${AUTH_BASE}:${endpoint}?key=${FIRESTORE_CONFIG.apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ returnSecureToken: true, ...body })
  });
  const d = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(d?.error?.message || "AUTH_ERRO");
  const sessao = {
    uid: d.localId,
    email: d.email,
    idToken: d.idToken,
    refreshToken: d.refreshToken,
    expiraEm: Date.now() + Number(d.expiresIn) * 1000
  };
  await api.storage.local.set({ sessao });
  return sessao;
}

const entrar     = (email, senha) => _authFetch("signInWithPassword", { email, password: senha });
const criarConta = (email, senha) => _authFetch("signUp",             { email, password: senha });

async function sair() {
  await api.storage.local.remove("sessao");
}

// Dispara o e-mail de redefinição de senha (fluxo padrão do Firebase).
async function resetSenha(email) {
  const resp = await fetch(`${AUTH_BASE}:sendOobCode?key=${FIRESTORE_CONFIG.apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ requestType: "PASSWORD_RESET", email })
  });
  const d = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(d?.error?.message || "AUTH_ERRO");
  return d;
}

async function sessaoAtual() {
  const { sessao } = await api.storage.local.get("sessao");
  return sessao || null;
}

// Erros que significam "esta sessão morreu de vez" — só nestes vale deslogar.
const REFRESH_MORTO = /TOKEN_EXPIRED|USER_DISABLED|USER_NOT_FOUND|INVALID_REFRESH_TOKEN|MISSING_REFRESH_TOKEN/;

// Devolve um idToken válido, renovando pelo refresh token se estiver perto de
// expirar. IMPORTANTE: uma falha de REDE não desloga — senão abrir a extensão
// offline (ex.: logo após reiniciar o PC) apagaria a sessão. Só limpamos a
// sessão quando o servidor diz explicitamente que o refresh token não vale mais.
async function tokenValido() {
  const s = await sessaoAtual();
  if (!s) return null;
  if (Date.now() < s.expiraEm - MARGEM_MS) return s.idToken;

  let r;
  try {
    r = await fetch(`${TOKEN_URL}?key=${FIRESTORE_CONFIG.apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(s.refreshToken)}`
    });
  } catch {
    return null;   // offline: mantém a sessão e tenta de novo na próxima chamada
  }

  if (!r.ok) {
    const d = await r.json().catch(() => ({}));
    if (REFRESH_MORTO.test(String(d?.error?.message || ""))) await sair();
    return null;   // 5xx/quota: também mantém a sessão
  }

  const d = await r.json();
  const nova = {
    ...s,
    idToken: d.id_token,
    refreshToken: d.refresh_token,
    expiraEm: Date.now() + Number(d.expires_in) * 1000
  };
  await api.storage.local.set({ sessao: nova });
  return nova.idToken;
}

// Traduz os códigos de erro do Firebase Auth para mensagens em português.
function traduzErroAuth(codigo) {
  const c = String(codigo || "");
  if (c.includes("EMAIL_EXISTS")) return "Este e-mail já tem conta. Use Entrar.";
  if (c.includes("EMAIL_NOT_FOUND")) return "E-mail não encontrado. Crie uma conta.";
  // ponytail: o projeto está com email enumeration protection — o Firebase
  // devolve INVALID_LOGIN_CREDENTIALS tanto para senha errada quanto para
  // e-mail sem conta, e não dá para distinguir. A mensagem precisa citar os
  // dois, senão quem errou o e-mail acha que errou a senha.
  if (c.includes("INVALID_PASSWORD") || c.includes("INVALID_LOGIN_CREDENTIALS"))
    return "Senha incorreta — ou não existe conta com esse e-mail. Confira o e-mail letra por letra.";
  if (c.includes("WEAK_PASSWORD")) return "Senha fraca — use ao menos 6 caracteres.";
  if (c.includes("INVALID_EMAIL")) return "E-mail inválido.";
  if (c.includes("TOO_MANY_ATTEMPTS")) return "Muitas tentativas. Tente mais tarde.";
  if (c.includes("USER_DISABLED")) return "Esta conta foi desativada.";
  return "Não foi possível concluir. Verifique os dados e a conexão.";
}
