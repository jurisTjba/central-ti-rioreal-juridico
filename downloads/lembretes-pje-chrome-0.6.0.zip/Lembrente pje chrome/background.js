/* =========================================================================
   background.js — service worker
   1. A cada 6 h (e na partida) sincroniza as notas PESSOAIS (Firestore, por
      uid) e as DO GABINETE (Firestore, por token), agendando as notificações
      de prazo — o Firestore gratuito não tem push, então o polling periódico
      é o caminho de custo zero.
   2. Notas antigas ainda em storage.sync (pré-login) seguem sendo agendadas
      pelo caminho legado, até o usuário migrá-las ao entrar na conta.
   ========================================================================= */

// No Chrome/Edge o background é um service worker e as dependências entram por
// importScripts. No Firefox elas já vêm pelo array "scripts" do manifesto — lá
// importScripts nem existe, daí a checagem.
if (typeof importScripts === "function") {
  importScripts("api.js", "comum.js", "firestore.js", "auth.js");
}

const HORA_DO_AVISO = 9;              // avisa às 09:00 do dia do lembrete
const SYNC_GABINETE_MIN = 60;         // varredura de fundo: de hora em hora
const SYNC_SOB_DEMANDA_MS = 2 * 60 * 1000;  // piso entre sincronizações pedidas
const VALIDADE_AVISADOS_DIAS = 60;    // travas de aviso mais velhas que isto são podadas

/* ---------- utilidades de data (sempre no fuso local) ---------- */

// "2026-07-20" -> timestamp local às 09:00. Nunca new Date(str): lê UTC.
function quandoAvisar(dataISO) {
  const [ano, mes, dia] = dataISO.split("-").map(Number);
  return new Date(ano, mes - 1, dia, HORA_DO_AVISO, 0, 0).getTime();
}

const formatarCnj = (d) =>
  d.replace(/^(\d{7})(\d{2})(\d{4})(\d)(\d{2})(\d{4})$/, "$1-$2.$3.$4.$5.$6");

/* ---------- notificação (com trava contra repetição) ----------
   O alarme some depois de disparar; na ressincronização seguinte a nota
   pendente seria reagendada e notificaria de novo. A trava `avisados`
   garante um único aviso por nota + data de lembrete.                  */

async function jaAvisado(chave) {
  const { avisados = {} } = await api.storage.local.get("avisados");
  return Boolean(avisados[chave]);
}

async function marcarAvisado(chave) {
  const { avisados = {} } = await api.storage.local.get("avisados");
  avisados[chave] = Date.now();
  await api.storage.local.set({ avisados });
}

// A trava `avisados` cresceria sem limite (uma entrada por nota+data, para
// sempre). Na partida, remove as entradas antigas — a nota já notificou há
// muito e não vai reaparecer no ciclo de sincronização.
async function podarAvisados() {
  const { avisados = {} } = await api.storage.local.get("avisados");
  const limite = Date.now() - VALIDADE_AVISADOS_DIAS * 86400000;
  let mudou = false;
  for (const [chave, ts] of Object.entries(avisados)) {
    if (typeof ts !== "number" || ts < limite) { delete avisados[chave]; mudou = true; }
  }
  if (mudou) await api.storage.local.set({ avisados });
}

// O service worker MV3 não toca áudio; quem toca é uma aba aberta do PJe
// (content script, Web Audio). Sem aba do PJe, fica o som de sistema da
// própria notificação. Melhor esforço: qualquer falha é silenciosa.
async function tocarSomNasAbas() {
  try {
    const abas = await api.tabs.query({ url: "https://pje.tjba.jus.br/*" });
    const alvo = abas.find((t) => t.active) || abas[0];
    if (alvo?.id != null) {
      const r = api.tabs.sendMessage(alvo.id, { tipo: "tocarSom" });
      if (r && typeof r.catch === "function") r.catch(() => {});
    }
  } catch (_) { /* sem aba do PJe aberta */ }
}

async function notificar(idNotif, titulo, mensagem) {
  const base = { type: "basic", iconUrl: "icon128.png", title: titulo, message: mensagem };
  try {
    // requireInteraction/priority são do Chrome; o Firefox rejeita.
    await api.notifications.create(idNotif, { ...base, requireInteraction: true, priority: 2 });
  } catch {
    try { await api.notifications.create(idNotif, base); } catch { /* sem notificações */ }
  }
  tocarSomNasAbas();
}

/* ---------- resumo de vencidos: "X lembretes passaram do prazo" ----------
   Além do aviso individual no dia do prazo, um resumo diário do acumulado
   de pendências vencidas (data < hoje). A trava `vencidas|<dia>` garante um
   único resumo por dia; o gate de horário evita notificação de madrugada
   quando o ciclo de sincronização atravessa a meia-noite.               */

async function contarVencidas() {
  const d = new Date();
  const hojeISO = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const { cachePessoal, cacheGabinete } = await api.storage.local.get(["cachePessoal", "cacheGabinete"]);
  const pendentes = [...(cachePessoal?.notas || []), ...(cacheGabinete?.notas || [])]
    .filter((n) => !n.concluido && n.data_lembrete);
  return {
    hojeISO,
    total: pendentes.filter((n) => n.data_lembrete < hojeISO).length,
    deHoje: pendentes.filter((n) => n.data_lembrete === hojeISO).length
  };
}

// Uma frase só, por pior que esteja a fila: "2 lembretes vencem hoje e 5
// passaram do prazo." — nunca um toast por nota.
function textoResumo(deHoje, vencidas) {
  const partes = [];
  if (deHoje) partes.push(deHoje === 1 ? "1 lembrete vence hoje" : `${deHoje} lembretes vencem hoje`);
  if (vencidas) partes.push(deHoje
    ? `${vencidas} ${vencidas === 1 ? "passou" : "passaram"} do prazo`
    : (vencidas === 1 ? "1 lembrete passou do prazo" : `${vencidas} lembretes passaram do prazo`));
  return partes.join(" e ") + ".";
}

async function avisarVencidas({ forcar = false } = {}) {
  const { hojeISO, total, deHoje } = await contarVencidas();
  if (!total && !deHoje) return { total: 0 };
  if (!forcar) {
    if (new Date().getHours() < 8) return { total };        // nada de aviso de madrugada
    const trava = `vencidas|${hojeISO}`;
    if (await jaAvisado(trava)) return { total };
    await marcarAvisado(trava);
  }
  await notificar("vencidas", "Lembretes PJe",
    textoResumo(deHoje, total) + " Clique para ver no painel.");
  return { total };
}

/* ---------- notas individuais (api.storage.sync) ----------
   A chave é "nota:<20 dígitos do CNJ>:<id>" — um processo pode ter várias
   notas. O nome do alarme é a própria chave de storage (começa com "nota:"),
   o que dá um alarme único por nota.                                      */

const digitosDaChave = (chave) => chave.split(":")[1] || "";

async function agendarNotaIndividual(chave, nota) {
  if (!nota?.data_lembrete || nota.concluido) {
    api.alarms.clear(chave);
    return;
  }
  const trava = `${chave}|${nota.data_lembrete}`;
  const quando = quandoAvisar(nota.data_lembrete);

  if (quando <= Date.now()) {
    // Prazo já passou quando o navegador abriu: NÃO notifica uma a uma (com
    // várias atrasadas virava rajada de toasts). O resumo agregado
    // ("X lembretes passaram do prazo") cobre todas de uma vez.
    if (!(await jaAvisado(trava))) await marcarAvisado(trava);
    return;
  }
  api.alarms.create(chave, { when: quando });
}

/* ---------- notas do gabinete (Firestore) ---------- */

const alarmeGab = (id) => `gab|${id}`;

async function sincronizarGabinete() {
  if (!fsConfigurado()) return;

  // Os gabinetes agora vêm do perfil da conta (usuarios/{uid}.grupos).
  const sessao = (typeof sessaoAtual === "function") ? await sessaoAtual() : null;
  const vazio = async () =>
    api.storage.local.set({ cacheGabinete: { notas: [], em: Date.now() } });

  if (!sessao) return vazio();

  let tokens = [];
  try {
    const perfil = await fsLerPerfil(sessao.uid);
    tokens = (perfil?.grupos || []).map((g) => g.token).filter(Boolean);
  } catch {
    return; // offline — tenta de novo no próximo ciclo
  }
  if (!tokens.length) return vazio();

  let notas;
  try {
    notas = await fsNotasDosGrupos(tokens);
  } catch {
    return; // offline ou regra negou — tenta de novo no próximo ciclo
  }

  // Cache para o popup abrir instantâneo e para o clique na notificação.
  await api.storage.local.set({ cacheGabinete: { notas, em: Date.now() } });

  for (const n of notas) {
    if (!n.data_lembrete || n.concluido) {
      api.alarms.clear(alarmeGab(n.id));
      continue;
    }
    const trava = `gab|${n.id}|${n.data_lembrete}`;
    const quando = quandoAvisar(n.data_lembrete);

    if (quando <= Date.now()) {
      // Atrasada: sem toast individual — o resumo agregado avisa o conjunto.
      if (!(await jaAvisado(trava))) await marcarAvisado(trava);
    } else {
      api.alarms.create(alarmeGab(n.id), { when: quando });
    }
  }
}

/* ---------- notas PESSOAIS (Firestore, usuarios/{uid}) ----------
   Espelham as do gabinete, mas escopadas pelo uid do usuário logado. Ficam
   em cachePessoal para o popup abrir instantâneo, o content script contar e
   o clique na notificação abrir o processo.                                */

const alarmePess = (id) => `pess|${id}`;

async function sincronizarPessoais() {
  if (!fsConfigurado()) return;
  const sessao = (typeof sessaoAtual === "function") ? await sessaoAtual() : null;

  if (!sessao) {
    // Deslogado: zera o cache para o content script/popup pararem de contar.
    await api.storage.local.set({ cachePessoal: { notas: [], em: Date.now() } });
    return;
  }

  let notas;
  try {
    notas = await fsTodasNotasPessoais(sessao.uid);
  } catch {
    return; // offline ou token expirado — tenta de novo no próximo ciclo
  }

  await api.storage.local.set({ cachePessoal: { notas, em: Date.now() } });

  for (const n of notas) {
    if (!n.data_lembrete || n.concluido) {
      api.alarms.clear(alarmePess(n.id));
      continue;
    }
    const trava = `pess|${n.id}|${n.data_lembrete}`;
    const quando = quandoAvisar(n.data_lembrete);

    if (quando <= Date.now()) {
      // Atrasada: sem toast individual — o resumo agregado avisa o conjunto.
      if (!(await jaAvisado(trava))) await marcarAvisado(trava);
    } else {
      api.alarms.create(alarmePess(n.id), { when: quando });
    }
  }
}

/* ---------- disparo dos alarmes ---------- */

// Vários lembretes com o MESMO dia disparam seus alarmes às 9h em rajada.
// Junta o que chegar numa janela curta: 1 nota → aviso detalhado; 2+ →
// um único "X lembretes vencem hoje", clicável para o painel.
let loteAvisos = [];
let loteTimer = null;

function notificarEmLote(aviso) {
  loteAvisos.push(aviso);
  if (loteTimer) return;
  loteTimer = setTimeout(() => {
    const lote = loteAvisos;
    loteAvisos = [];
    loteTimer = null;
    if (lote.length === 1) {
      notificar(lote[0].id, lote[0].titulo, lote[0].msg);
    } else {
      notificar("prazos-hoje", "Lembretes PJe",
        `${lote.length} lembretes vencem hoje. Clique para ver no painel.`);
    }
  }, 2500);
}

api.alarms.onAlarm.addListener(async (alarme) => {
  if (alarme.name === "syncGabinete") {
    await sincronizarGabinete();
    await sincronizarPessoais();
    await avisarVencidas().catch(() => {});   // resumo diário pega carona no ciclo horário
    return;
  }

  // Nota pessoal (Firestore): nome do alarme "pess|<id>".
  if (alarme.name.startsWith("pess|")) {
    const id = alarme.name.slice(5);
    const { cachePessoal } = await api.storage.local.get("cachePessoal");
    const nota = cachePessoal?.notas?.find((n) => n.id === id);
    if (nota && !nota.concluido) {
      await marcarAvisado(`pess|${id}|${nota.data_lembrete}`);
      notificarEmLote({
        id: alarme.name,
        titulo: "Lembrete · " + (nota.cnj || formatarCnj(nota.cnj_digitos || "")),
        msg: nota.texto.slice(0, 120)
      });
    }
    return;
  }

  // Nota individual: o nome do alarme é a própria chave "nota:<dig>:<id>".
  if (alarme.name.startsWith("nota:")) {
    const chave = alarme.name;
    const dados = await api.storage.sync.get(chave);
    const nota = dados[chave];
    if (nota && !nota.concluido) {
      await marcarAvisado(`${chave}|${nota.data_lembrete}`);
      notificarEmLote({
        id: chave,
        titulo: "Lembrete · " + formatarCnj(digitosDaChave(chave)),
        msg: nota.texto.slice(0, 120)
      });
    }
    return;
  }

  if (alarme.name.startsWith("gab|")) {
    const id = alarme.name.slice(4);
    const { cacheGabinete } = await api.storage.local.get("cacheGabinete");
    const nota = cacheGabinete?.notas?.find((n) => n.id === id);
    if (nota && !nota.concluido) {
      await marcarAvisado(`gab|${id}|${nota.data_lembrete}`);
      notificarEmLote({
        id: alarme.name,
        titulo: "Gabinete · " + nota.cnj,
        msg: `${nota.texto.slice(0, 100)} — ${nota.autor}`
      });
    }
  }
});

// Clique na notificação abre o processo no PJe (pela url guardada na nota).
// O resumo de vencidas abre o painel, que lista tudo o que passou do prazo.
api.notifications.onClicked.addListener(async (nome) => {
  if (nome === "vencidas" || nome === "prazos-hoje" || nome === "teste-notif") {
    api.notifications.clear(nome);
    try { await api.tabs.create({ url: api.runtime.getURL("options/index.html#/painel") }); }
    catch { api.runtime.openOptionsPage(); }
    return;
  }
  if (nome.startsWith("pess|")) {
    const id = nome.slice(5);
    const { cachePessoal } = await api.storage.local.get("cachePessoal");
    const nota = cachePessoal?.notas?.find((n) => n.id === id);
    if (nota?.url) api.tabs.create({ url: nota.url });
  } else if (nome.startsWith("nota:")) {                 // legado (storage.sync)
    const dados = await api.storage.sync.get(nome);
    if (dados[nome]?.url) api.tabs.create({ url: dados[nome].url });
  }
  api.notifications.clear(nome);
});

/* ---------- mensagens do popup ---------- */

/* ---------- serviços pedidos pelo popup, painel e content script ---------- */

// O content script não carrega firestore.js/auth.js (roda no mundo isolado da
// página). Ele pergunta aqui o que precisa para montar o compositor inline.
async function contextoDaConta() {
  const sessao = (typeof sessaoAtual === "function") ? await sessaoAtual() : null;
  if (!sessao) return { logado: false, nome: "", grupos: [] };
  let perfil = null;
  try { perfil = await fsLerPerfil(sessao.uid); } catch { /* offline */ }
  return {
    logado: true,
    nome: String(perfil?.nome || "").trim(),
    grupos: (perfil?.grupos || []).filter((g) => g && g.token)
  };
}

// Cria a nota pedida pelo compositor inline do PJe e já ressincroniza, para a
// contagem nos selos refletir a nova nota na hora.
async function criarNotaDoConteudo(msg) {
  const sessao = (typeof sessaoAtual === "function") ? await sessaoAtual() : null;
  if (!sessao) return { erro: "Entre na sua conta da extensão." };

  const d = msg.dados || {};
  const texto = String(d.texto || "").trim();
  if (!texto) return { erro: "Nota vazia." };
  if (!d.cnj) return { erro: "Não identifiquei o número do processo." };

  try {
    if (msg.origem === "gab") {
      const perfil = await fsLerPerfil(sessao.uid);
      const nome = String(perfil?.nome || "").trim();
      if (!nome) return { erro: "Defina seu nome na extensão antes de publicar no gabinete." };
      if (!d.tokens?.length) return { erro: "Escolha ao menos um gabinete." };
      await fsCriarNota(d.tokens, {
        cnj: d.cnj, texto, autor: nome, data_lembrete: d.data_lembrete || null, url: d.url || null
      });
      await sincronizarGabinete();
    } else {
      await fsCriarNotaPessoal(sessao.uid, {
        cnj: d.cnj, texto, data_lembrete: d.data_lembrete || null, url: d.url || null
      });
      await sincronizarPessoais();
    }
    return { ok: true };
  } catch {
    return { erro: "Falha ao salvar na nuvem. Verifique a conexão." };
  }
}

// Lista as notas do processo (pessoais + gabinete) para a aba "Lembretes" do
// diálogo injetado no PJe. Busca direto no Firestore para não mostrar lista
// defasada; o diálogo pinta o cache enquanto espera esta resposta.
async function notasDoProcessoParaConteudo(dig) {
  const sessao = (typeof sessaoAtual === "function") ? await sessaoAtual() : null;
  if (!sessao || !dig) return null;

  const perfil = await fsLerPerfil(sessao.uid).catch(() => null);
  const tokens = (perfil?.grupos || []).map((g) => g.token).filter(Boolean);

  const [minhas, doGab] = await Promise.all([
    fsNotasPessoaisDoProcesso(sessao.uid, dig)
      .then((ns) => ns.map((n) => ({ ...n, origem: "ind" })))
      .catch(() => null),
    tokens.length
      ? fsNotasDoProcesso(tokens, dig)
          .then((ns) => ns.map((n) => ({ ...n, origem: "gab" })))
          .catch(() => null)
      : []
  ]);
  if (minhas === null && doGab === null) return null;   // rede caiu de vez
  return { ok: true, notas: [...(minhas || []), ...(doGab || [])] };
}

// Ações do diálogo do PJe sobre uma nota existente (concluir/reabrir, editar
// texto/prazo, excluir). Ressincroniza ao final para caches, selos e badge
// refletirem a mudança na hora.
async function acaoNotaDoConteudo(msg) {
  const sessao = (typeof sessaoAtual === "function") ? await sessaoAtual() : null;
  if (!sessao) return { erro: "Entre na sua conta da extensão." };
  if (!msg.id) return { erro: "Nota sem identificador." };

  const deGabinete = msg.origem === "gab";
  try {
    if (msg.acao === "concluir") {
      if (deGabinete) {
        const perfil = await fsLerPerfil(sessao.uid).catch(() => null);
        await fsConcluirNota(msg.id, Boolean(msg.concluido),
                             String(perfil?.nome || "").trim() || "assessor");
      } else {
        await fsConcluirNotaPessoal(sessao.uid, msg.id, Boolean(msg.concluido));
      }
    } else if (msg.acao === "editar") {
      const recebidos = msg.campos || {};
      const campos = {};
      if ("texto" in recebidos) {
        campos.texto = String(recebidos.texto || "").trim();
        if (!campos.texto) return { erro: "Nota vazia." };
      }
      if ("data_lembrete" in recebidos) campos.data_lembrete = recebidos.data_lembrete || null;
      if (!Object.keys(campos).length) return { erro: "Nada para alterar." };
      if (deGabinete) await fsEditarNota(msg.id, campos);
      else await fsEditarNotaPessoal(sessao.uid, msg.id, campos);
    } else if (msg.acao === "excluir") {
      if (deGabinete) await fsExcluirNota(msg.id);
      else await fsExcluirNotaPessoal(sessao.uid, msg.id);
    } else {
      return { erro: "Ação desconhecida." };
    }

    if (deGabinete) await sincronizarGabinete();
    else await sincronizarPessoais();
    return { ok: true };
  } catch {
    return { erro: "Falha ao salvar na nuvem. Verifique a conexão." };
  }
}

// Selo clicado no PJe: abre os lembretes já filtrados por aquele processo. O
// popup é o destino preferido; se o navegador recusar (openPopup exige gesto
// recente e o vínculo se perde no salto content → SW), cai no painel.
async function abrirLembretes(termo) {
  await api.storage.local.set({ focoBusca: { termo: termo || "", em: Date.now() } });
  try {
    if (api.action && api.action.openPopup) {
      await api.action.openPopup();
      return;
    }
  } catch (_) { /* sem gesto válido */ }
  try {
    await api.tabs.create({ url: api.runtime.getURL("options/index.html#/notas") });
  } catch { api.runtime.openOptionsPage(); }
}

// Notas criadas antes desta correção guardaram o error.seam (ou nada, no caso
// das de gabinete). Ao abrir o processo no PJe, elas recebem o link bom.
const LINKS_CORRIGIDOS = new Set();
const LIMITE_CORRECAO = 25;

async function corrigirLinks(dig, url) {
  if (!dig || !linkUtil(url) || LINKS_CORRIGIDOS.has(dig)) return;
  LINKS_CORRIGIDOS.add(dig);

  const sessao = (typeof sessaoAtual === "function") ? await sessaoAtual() : null;
  if (!sessao) return;

  const { cachePessoal, cacheGabinete } = await api.storage.local.get(["cachePessoal", "cacheGabinete"]);
  const semLink = (n) => (n.cnj_digitos || "") === dig && !linkUtil(n.url);
  const pessoais = (cachePessoal?.notas || []).filter(semLink).slice(0, LIMITE_CORRECAO);
  const doGrupo = (cacheGabinete?.notas || []).filter(semLink).slice(0, LIMITE_CORRECAO);
  if (!pessoais.length && !doGrupo.length) return;

  try {
    for (const n of pessoais) await fsEditarNotaPessoal(sessao.uid, n.id, { url });
    for (const n of doGrupo) await fsEditarNota(n.id, { url });
  } catch {
    LINKS_CORRIGIDOS.delete(dig);   // rede caiu: tenta de novo na próxima visita
    return;
  }

  if (pessoais.length) await sincronizarPessoais();
  if (doGrupo.length) await sincronizarGabinete();
}

// Sincronização sob demanda com piso de tempo: a aba do PJe pede de 5 em 5
// min e a cada foco, mas não faz sentido varrer o Firestore a cada pedido.
async function sincronizarSePreciso() {
  const { ultimoSync = 0 } = await api.storage.local.get("ultimoSync");
  if (Date.now() - ultimoSync < SYNC_SOB_DEMANDA_MS) return;
  await api.storage.local.set({ ultimoSync: Date.now() });
  await sincronizarPessoais();
  await sincronizarGabinete();
}

api.runtime.onMessage.addListener((msg, sender, responder) => {
  // Handlers assíncronos disparados sem await: sem .catch, uma rejeição
  // (storage/rede) vira "unhandled rejection" no service worker.
  if (msg?.tipo === "sincronizarPessoais") sincronizarPessoais().catch(() => {});
  if (msg?.tipo === "sincronizarGabinete") sincronizarGabinete().catch(() => {});
  if (msg?.tipo === "sincronizarSePreciso") sincronizarSePreciso().catch(() => {});
  if (msg?.tipo === "definirBadge") definirBadge(sender?.tab?.id, msg.pend).catch(() => {});
  if (msg?.tipo === "abrirLembretes") abrirLembretes(msg.termo).catch(() => {});
  if (msg?.tipo === "corrigirLinks") corrigirLinks(msg.dig, msg.url).catch(() => {});
  if (msg?.tipo === "abrirPainel") {
    const vista = ["painel", "notas", "processos", "ajustes"].includes(msg.vista) ? msg.vista : "painel";
    api.tabs.create({ url: api.runtime.getURL(`options/index.html#/${vista}`) }).catch(() => {});
  }

  // Estes precisam responder: devolver `true` mantém o canal aberto até o
  // responder() ser chamado (exigência do onMessage no MV3).
  if (msg?.tipo === "contexto") {
    contextoDaConta().then(responder).catch(() => responder(null));
    return true;
  }
  if (msg?.tipo === "criarNota") {
    criarNotaDoConteudo(msg).then(responder)
      .catch(() => responder({ erro: "Falha inesperada ao salvar." }));
    return true;
  }
  if (msg?.tipo === "notasDoProcesso") {
    notasDoProcessoParaConteudo(msg.dig).then(responder).catch(() => responder(null));
    return true;
  }
  if (msg?.tipo === "acaoNota") {
    acaoNotaDoConteudo(msg).then(responder)
      .catch(() => responder({ erro: "Falha inesperada." }));
    return true;
  }
  // Botão "Testar notificação e som" dos Ajustes: dispara uma notificação de
  // exemplo e, se houver vencidas, o resumo real — sem esperar o dia virar.
  if (msg?.tipo === "testarNotificacoes") {
    (async () => {
      await notificar("teste-notif", "Lembretes PJe — teste",
        "As notificações estão funcionando. Clique para abrir o painel.");
      const { total } = await avisarVencidas({ forcar: true });
      return { ok: true, vencidas: total };
    })().then(responder).catch(() => responder({ erro: "Não consegui notificar." }));
    return true;
  }
  return false;
});

// Um gancho só, em vez de espalhar chamadas: todo caminho que grava o cache
// (sync de fundo, sync sob demanda, criação pelo popup ou pelo PJe) passa aqui.
api.storage.onChanged.addListener((mudancas, area) => {
  if (area === "local" && (mudancas.cachePessoal || mudancas.cacheGabinete)) {
    atualizarBadgeGlobal().catch(() => {});
  }
});

/* ---------- primeira execução: leva o usuário ao guia ---------- */

api.runtime.onInstalled.addListener((detalhe) => {
  if (detalhe.reason !== "install") return;
  api.tabs.create({ url: api.runtime.getURL("options/index.html#/bemvindo") })
    .catch(() => { try { api.runtime.openOptionsPage(); } catch (_) { /* ignora */ } });
});

// Badge no ícone da extensão com o nº de pendências do processo aberto na aba
// (o content script informa a contagem). Preso ao tabId: some sozinho quando
// a aba fecha, e cada aba tem o seu número.
async function definirBadge(tabId, pend) {
  if (tabId == null) return;
  const texto = pend > 0 ? String(pend) : "";
  try {
    await api.action.setBadgeText({ tabId, text: texto });
    if (texto) await api.action.setBadgeBackgroundColor({ tabId, color: "#A6402C" });
  } catch (_) { /* aba fechada ou action indisponível */ }
}

// Badge GLOBAL (sem tabId): o que vence hoje ou já venceu, em qualquer
// processo. Antes o badge só existia com uma aba do PJe aberta e era zerado
// fora dela — sumia justamente quando serviria de lembrete.
async function atualizarBadgeGlobal() {
  const hoje = new Date();
  const hojeISO = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, "0")}-${String(hoje.getDate()).padStart(2, "0")}`;
  const { cachePessoal, cacheGabinete } = await api.storage.local.get(["cachePessoal", "cacheGabinete"]);
  const todas = [...(cachePessoal?.notas || []), ...(cacheGabinete?.notas || [])];
  const cobram = todas.filter((n) => !n.concluido && n.data_lembrete && n.data_lembrete <= hojeISO);
  try {
    await api.action.setBadgeText({ text: cobram.length ? String(cobram.length) : "" });
    if (cobram.length) await api.action.setBadgeBackgroundColor({ color: "#A6402C" });
  } catch (_) { /* action indisponível */ }
}

// O botão "✚ nota" do PJe não abre mais o popup: o compositor é montado na
// própria página (content.js). action.openPopup() exigia um gesto recente do
// usuário e o vínculo se perdia no salto content → service worker, então o
// mesmo clique às vezes abria o popup e às vezes uma aba com o painel.

/* ---------- partida: reconstruir alarmes perdidos ---------- */

async function ressincronizar() {
  await podarAvisados();

  // Legado: notas antigas em storage.sync (pré-login) continuam sendo
  // agendadas até o usuário migrá-las ao entrar na conta.
  const tudo = await api.storage.sync.get(null);
  for (const [chave, nota] of Object.entries(tudo)) {
    if (chave.startsWith("nota:")) await agendarNotaIndividual(chave, nota);
  }

  await sincronizarPessoais();   // agenda os lembretes das notas na nuvem
  await sincronizarGabinete();
  await avisarVencidas().catch(() => {});   // ao abrir o navegador, cobra o acumulado

  api.alarms.create("syncGabinete", {
    periodInMinutes: SYNC_GABINETE_MIN,
    delayInMinutes: 1
  });
}

api.runtime.onStartup.addListener(ressincronizar);
api.runtime.onInstalled.addListener(ressincronizar);
