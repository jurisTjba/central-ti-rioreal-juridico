# Política de Privacidade — Lembretes PJe

_Última atualização: 5 de agosto de 2026_

A extensão **Lembretes PJe** permite que servidores e colaboradores anexem
anotações e lembretes de prazo aos processos do PJe do Tribunal de Justiça da
Bahia (`pje.tjba.jus.br`). Esta política descreve quais dados a extensão trata,
para quê e com quem eles são compartilhados.

## 1. Dados coletados

| Dado | Origem | Finalidade |
|---|---|---|
| **E-mail e senha** | Informados pelo usuário no login | Autenticação da conta (Firebase Authentication). A senha não é armazenada pela extensão: ela é enviada de forma criptografada (HTTPS) diretamente ao serviço de autenticação do Google (Identity Toolkit), que devolve apenas tokens de sessão. |
| **Nome do usuário** | Informado pelo usuário no perfil | Identificar o autor das notas compartilhadas com o gabinete. |
| **Conteúdo das notas e datas de lembrete** | Criado pelo usuário | Finalidade central da extensão: exibir anotações e alertas de prazo por processo. |
| **Número do processo (CNJ) e URL da página do processo** | Lido da página do PJe aberta pelo usuário no momento em que ele cria uma nota | Vincular a nota ao processo correto e permitir voltar a ele com um clique. |

A extensão **não coleta** histórico de navegação, localização, dados
financeiros, comunicações pessoais nem qualquer conteúdo de páginas fora de
`pje.tjba.jus.br`. Nenhum dado é coletado de forma automática ou em segundo
plano: só é tratado aquilo que o próprio usuário digita ou a página do processo
em que ele aciona a extensão.

## 2. Onde os dados ficam armazenados

- **Na nuvem (Cloud Firestore / Google Cloud):** perfil do usuário
  (`usuarios/{uid}`), notas pessoais (`usuarios/{uid}/notas`) e notas de
  gabinete (`lembretes`). As regras de segurança do Firestore exigem usuário
  autenticado; notas pessoais são legíveis e editáveis apenas pelo próprio dono
  (`request.auth.uid`).
- **No dispositivo (armazenamento local do navegador):** tokens de sessão,
  preferências de interface e cache das notas, para evitar novo login a cada
  uso e acelerar a exibição dos lembretes.

Toda a comunicação com os serviços do Google (Firestore, Identity Toolkit e
Secure Token) ocorre por HTTPS.

## 3. Compartilhamento

- **Notas pessoais** são privadas: apenas o usuário autenticado que as criou
  pode lê-las.
- **Notas de gabinete** são visíveis somente para as pessoas que possuem o
  código de acesso do respectivo gabinete, junto com o nome do autor.
- **Não vendemos nem transferimos dados a terceiros.** Os dados não são usados
  para publicidade, para determinar credibilidade nem para fins de crédito, e
  não são tratados para nenhuma finalidade estranha ao propósito único da
  extensão (notas e lembretes de processos).

O armazenamento é feito na infraestrutura do Google Firebase, que atua como
operadora de dados; nenhum outro serviço externo recebe informações.

## 4. Retenção e exclusão

As notas permanecem armazenadas enquanto o usuário não as excluir. O usuário
pode apagar qualquer nota pela própria extensão. Para excluir a conta e todos
os dados associados, basta solicitar pelo e-mail de contato abaixo.

## 5. Contato

Dúvidas ou solicitações sobre privacidade: **rioreal.asstop@gmail.com**
