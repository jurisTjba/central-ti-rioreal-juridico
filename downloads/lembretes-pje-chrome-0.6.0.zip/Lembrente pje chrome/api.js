/* =========================================================================
   api.js — ponte entre Chrome/Edge e Firefox.

   Chrome e Edge expõem as APIs de extensão em `chrome.*`, já retornando
   promessas no Manifest V3. O Firefox expõe as mesmas APIs em `browser.*`
   (com promessas) e mantém um `chrome.*` legado baseado em CALLBACK — nele,
   um `await chrome.storage.local.get(...)` devolveria undefined e quebraria
   tudo em silêncio.

   Por isso o resto do código fala com `api.*`: aqui escolhemos a
   implementação certa para o navegador em uso.

   É `var` de propósito: precisa valer em todos os contextos (páginas do
   popup/painel, service worker via importScripts, e o mundo isolado dos
   content scripts).
   ========================================================================= */

var api = (typeof globalThis.browser !== "undefined" && globalThis.browser.runtime)
  ? globalThis.browser
  : globalThis.chrome;
