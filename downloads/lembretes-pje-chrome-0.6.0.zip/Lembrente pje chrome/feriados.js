// >>> Feriados locais do seu tribunal/estado. Cada item pode ser:
//     "MM-DD"      -> repete todo ano   (ex.: "07-02" p/ 2 de Julho na Bahia)
//     "AAAA-MM-DD" -> só naquele ano    (ex.: "2026-11-30" ponto facultativo)

const FERIADOS_EXTRA = [
  "07-02",   // Independência da Bahia (feriado estadual)

  // --- TJBA: dias sem expediente forense recorrentes (confira a portaria anual) ---
  "10-28",   // Dia do Servidor Público
  "12-08",   // Dia da Justiça

  // --- Comarca de Rio Real: feriados municipais (preencha conforme a lei local) ---
  // "MM-DD", // aniversário da cidade / padroeiro(a) — edite com as datas certas
];


const FORMATO_FERIADO = /^(\d{4}-)?(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
const FERIADOS_EXTRA_OK = FERIADOS_EXTRA.filter((item) => {
  if (!item) return false;
  if (!FORMATO_FERIADO.test(item)) {
    console.warn(
      `[Lembretes PJe] feriado ignorado (use "MM-DD" ou "AAAA-MM-DD"): ${item}`);
    return false;
  }
  return true;
});

const RECESSO_INICIO = { mes: 12, dia: 20 };
const RECESSO_FIM = { mes: 1, dia: 20 };

function isoLocal(d) {
  const a = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dia = String(d.getDate()).padStart(2, "0");
  return `${a}-${m}-${dia}`;
}

function somaDias(base, n) {
  const d = new Date(base.getFullYear(), base.getMonth(), base.getDate());
  d.setDate(d.getDate() + n);
  return d;
}

// Domingo de Páscoa (algoritmo de Meeus/Butcher) — âncora dos feriados móveis.
function calcularPascoa(ano) {
  const a = ano % 19;
  const b = Math.floor(ano / 100), c = ano % 100;
  const d = Math.floor(b / 4), e = b % 4;
  const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4), k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const mes = Math.floor((h + l - 7 * m + 114) / 31);
  const dia = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(ano, mes - 1, dia);
}

const _cacheFeriados = {};

// Conjunto de "AAAA-MM-DD" de todos os feriados nacionais do ano.
function feriadosDoAno(ano) {
  if (_cacheFeriados[ano]) return _cacheFeriados[ano];
  const set = new Set();

  // Fixos nacionais.
  for (const md of ["01-01", "04-21", "05-01", "09-07",
                    "10-12", "11-02", "11-15", "12-25"]) {
    set.add(`${ano}-${md}`);
  }
  // Consciência Negra virou feriado nacional (Lei 14.759/2023), a partir de 2024.
  if (ano >= 2024) set.add(`${ano}-11-20`);

  const pascoa = calcularPascoa(ano);
  set.add(isoLocal(somaDias(pascoa, -48))); // Carnaval (segunda)
  set.add(isoLocal(somaDias(pascoa, -47))); // Carnaval (terça)
  set.add(isoLocal(somaDias(pascoa, -2)));  // Sexta-feira Santa
  set.add(isoLocal(somaDias(pascoa, 60)));  // Corpus Christi

  // Locais informados pelo usuário (já validados em FERIADOS_EXTRA_OK).
  for (const item of FERIADOS_EXTRA_OK) {
    set.add(/^\d{4}-/.test(item) ? item : `${ano}-${item}`);
  }

  _cacheFeriados[ano] = set;
  return set;
}

// Recesso forense (RECESSO_INICIO..RECESSO_FIM, que atravessa a virada do ano) — prazos suspensos, logo esses dias não contam.
function emRecessoForense(d) {
  const mes = d.getMonth() + 1, dia = d.getDate();
  return (mes === RECESSO_INICIO.mes && dia >= RECESSO_INICIO.dia)
      || (mes === RECESSO_FIM.mes && dia <= RECESSO_FIM.dia);
}

function ehDiaUtil(d) {
  const dow = d.getDay();
  if (dow === 0 || dow === 6) return false;         // fim de semana
  if (emRecessoForense(d)) return false;            // recesso forense
  if (feriadosDoAno(d.getFullYear()).has(isoLocal(d))) return false; // feriado
  return true;
}

// Data que fica N dias úteis à frente de `base` (N >= 1), sempre num dia útil.
function somarDiasUteis(base, n) {
  const d = new Date(base.getFullYear(), base.getMonth(), base.getDate());
  // Teto de segurança (~10 anos úteis) contra um n absurdo que travaria o laço.
  let restantes = Math.min(2600, Math.max(0, Math.floor(n)));
  while (restantes > 0) {
    d.setDate(d.getDate() + 1);
    if (ehDiaUtil(d)) restantes--;
  }
  return d;
}
