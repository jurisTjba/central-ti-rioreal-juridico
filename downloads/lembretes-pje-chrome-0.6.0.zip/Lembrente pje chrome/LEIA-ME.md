# Lembretes PJe — notas por processo, com conta e gabinetes compartilhados

Extensão de navegador que anexa **anotações e lembretes de prazo** aos processos
do PJe (TJBA). Cada pessoa entra com **e-mail e senha**; as notas pessoais ficam
privadas na conta e as notas de gabinete são compartilhadas com quem tem o
**código de acesso** do grupo.

> **O que mudou nesta versão**
> - **Selo de notas na lista de processos da tarefa** (e das etiquetas): cada cartão mostra um sino com a contagem de notas daquele processo, sem precisar abri-lo — **verde** quando há nota pendente dentro do prazo (ou sem prazo), **vermelho** quando alguma pendente passou do prazo, cinza quando só há concluídas. Clicar abre o diálogo na aba Lembretes daquele processo. Como o painel do PJe é um **iframe de outra origem** (`frontend.cloud.pje.jus.br`), o manifest passou a injetar o content script em todos os frames e nessa origem — ao atualizar a extensão o navegador pede a nova permissão de site.
> - **Filtro por nota na lista**: no topo da lista de processos, "Notas: Todas · Com nota · Vencidas · Sem nota" esconde os cartões que não interessam à triagem (a seleção "marcar todos" do PJe continua incluindo os ocultos).
> - **Prévia no selo**: passar o mouse (ou focar) no selo mostra as notas pendentes do processo — texto, origem, autor e prazo — sem clicar. O selo ganha 👥 quando há nota do gabinete.
> - **Modelos de nota**: atalhos acima da caixa de texto (no PJe e no popup) com os modelos definidos em Ajustes (lista com adicionar/remover, salva sozinha) e os últimos textos salvos.
> - **Sino sem conta**: enquanto não há sessão, o sino do PJe fica com um "!" âmbar e leva direto a Ajustes para entrar; depois do login volta a mostrar só as vencidas.
> - **Popup em agenda**: a aba Lembretes agrupa as pendências em Vencidas, Hoje, Amanhã, Esta semana, Mais adiante e Sem prazo; o número do processo abre o processo (ou copia o número, quando a nota não tem link).
> - **Sino de vencidas** agora fica na mesma linha do bloco do usuário (a `<ul>` da navbar do PJe é flex em coluna; o sino entra dentro do `li.menu-usuario`).
> - **Sino de vencidas na página inicial do PJe**: ao lado do bloco do usuário, um sino com contador mostra quantos lembretes passaram do prazo; clicar abre o painel da extensão. Não aparece nas telas de processo (lá valem os selos por processo).
> - **Resumo diário "X lembretes passaram do prazo"** por notificação do navegador (uma vez por dia, a partir das 8h), clicável para abrir o painel — além do aviso individual no dia do prazo, agora com **toque sonoro** quando houver uma aba do PJe aberta. Botão **"Testar notificação e som"** em Ajustes & conexão.
> - **Diálogo do PJe com abas "Anotação" e "Lembretes"**: além de escrever a nota, o histórico do processo agora aparece ali mesmo, com concluir, adiar, editar e excluir — sem abrir o popup. Os selos de contagem (🔒/👥) ao lado do "✚ nota" abrem direto a aba Lembretes.
> - **Login obrigatório** (Firebase Auth, e-mail/senha). Nada mais depende do dispositivo: entrando na mesma conta em outro computador, tudo reaparece.
> - **Perfil na conta**: seu **nome** e seus **gabinetes** ficam em `usuarios/{uid}` — não é preciso reconfigurar em cada máquina/navegador.
> - **Nome é obrigatório apenas para as notas do gabinete** (é o autor exibido). Nota privada não pede nome.
> - **Vários gabinetes**: você participa de quantos quiser, e **uma anotação pode ser publicada em mais de um** de uma vez.
> - **Código de acesso** por gabinete, gerado com entropia forte, com botão de copiar — substitui o token digitado à mão.
> - **Notas pessoais na nuvem** (`usuarios/{uid}/notas`), com isolamento real por `request.auth.uid`. Notas antigas do `storage.sync` são migradas no primeiro login.
> - **Chrome, Edge e Firefox** — ver [seção 7](#7-instalação-por-navegador-chrome-edge-e-firefox).
> - **Compositor na própria página do PJe**: o botão **✚ nota** abre um formulário ali mesmo, sem trocar de aba nem abrir o popup.
> - **Editar e adiar** qualquer nota (adiar = +7 dias úteis) no popup e no painel.
> - **Badge no ícone**: por aba, as pendências do processo aberto; global, o que vence hoje ou já venceu.
> - Prazo em **dias úteis** (5/10/15, nº livre ou data), pulando fim de semana, feriados nacionais e o **recesso forense (20/12–20/01)**.

---

## 1. Modelagem no Firestore

Três estruturas, todas exigindo usuário autenticado:

```
usuarios (coleção)
  └── {uid}  ← PERFIL: nome + lista de gabinetes
        └── notas (subcoleção)
              └── {id}  ← NOTA PESSOAL (só o dono lê/escreve)

lembretes (coleção raiz)
  └── {id}  ← NOTA DE GABINETE, ligada aos grupos pelo array `tokens`
```

**Perfil** — `usuarios/{uid}`:

```json
{
  "nome": "Ana Souza",
  "grupos": [
    { "token": "GAB-a7k3-m9p2-x4qn-7bvd", "nome": "2ª Vara Cível" },
    { "token": "GAB-t2wm-9prs-k5zj-3nhy", "nome": "Plantão" }
  ]
}
```

**Nota pessoal** — `usuarios/{uid}/notas/{id}`:

```json
{
  "cnj": "0001234-56.2026.8.05.0001",
  "cnj_digitos": "00012345620268050001",
  "texto": "Conferir se a inicial juntou a procuração atualizada.",
  "data_lembrete": "2026-07-28",
  "url": "https://pje.tjba.jus.br/...",
  "concluido": false,
  "concluido_em": null,
  "criado_em": "2026-07-16T14:05:00Z",
  "atualizado_em": "2026-07-16T14:05:00Z"
}
```

**Nota de gabinete** — `lembretes/{id}`:

```json
{
  "tokens": ["GAB-a7k3-m9p2-x4qn-7bvd", "GAB-t2wm-9prs-k5zj-3nhy"],
  "cnj": "0001234-56.2026.8.05.0001",
  "cnj_digitos": "00012345620268050001",
  "texto": "Minutar decisão sobre a tutela de urgência antes da audiência.",
  "autor": "Ana Souza",
  "criado_em": "2026-07-16T14:05:00Z",
  "data_lembrete": "2026-07-28",
  "concluido": false,
  "concluido_por": null,
  "concluido_em": null,
  "atualizado_em": "2026-07-16T14:05:00Z"
}
```

Decisões de modelagem que valem registrar:

- **`tokens` é um array**, não uma string — é o que permite publicar a mesma nota em vários gabinetes. A consulta usa `ARRAY_CONTAINS_ANY` com os gabinetes do seu perfil, numa chamada só. Notas criadas antes disso têm a string `token_gabinete`; o código consulta os **dois formatos** e não perde nada.
- **As regras proíbem alterar `tokens` depois da criação.** Os gabinetes de uma nota são escolhidos **no momento de criar** — não dá para adicionar a nota a outro grupo depois.
- **`cnj_digitos`**: o CNJ só com dígitos. A filtragem por processo é feita **no cliente**, sobre as notas dos seus gabinetes — assim nenhuma consulta precisa de índice composto no console.
- **`data_lembrete` é string `"AAAA-MM-DD"`, não timestamp.** Prazo processual é uma *data*, não um instante: como timestamp UTC, "28/07" viraria "27/07 21:00" no fuso de Salvador e o aviso sairia no dia errado.
- **`criado_em`, `concluido_em`, `atualizado_em`** são `timestampValue` (instantes reais de auditoria). A ordenação é feita no cliente, de novo para evitar índice composto.

## 2. Configuração no console (uma vez)

1. **Authentication → Método de login** → habilite **E-mail/senha**.
2. **Authentication → Configurações → Ações do usuário** → marque **Proteção contra enumeração de e-mails**.
3. **Firestore Database → Regras** → cole o conteúdo de [`firestore.rules`](firestore.rules) → Publicar.
4. **API key** (`console.cloud.google.com` → APIs e serviços → Credenciais): a chave usada em [`firestore.js`](firestore.js) precisa permitir **três** APIs:
   - `Cloud Firestore API`
   - `Identity Toolkit API` (login e criação de conta)
   - `Token Service API` (renovação da sessão)

> ⚠️ Se o cadastro falhar com **403 `API_KEY_SERVICE_BLOCKED`**, o problema é a restrição de API da chave — não o código. Confira se as três APIs acima estão liberadas **na chave que está no `firestore.js`** (um projeto pode ter várias chaves).

## 3. Estrutura de arquivos

```
lembretes-pje/
├── manifest.json          ← Chrome / Edge
├── manifest.firefox.json  ← Firefox (background por scripts + id gecko)
├── api.js                 ← ponte chrome.* (Chrome/Edge) ↔ browser.* (Firefox)
├── auth.js                ← Firebase Auth por REST: entrar, criar conta, sessão
├── firestore.js           ← cliente REST do Firestore + perfil e notas
├── comum.js               ← utilitários compartilhados (datas locais, CNJ)
├── feriados.js            ← dias úteis (feriados nacionais + recesso + FERIADOS_EXTRA)
├── background.js          ← alarmes de prazo + sincronização + badge + grava as notas do PJe
├── content.js             ← extrai CNJ/contexto do PJe + selos (processo e lista) + compositor na página
├── popup.html / popup.js  ← 3 abas: Processo · Lembretes · Conta
├── options/               ← painel em tela cheia (conta, gabinetes, agenda)
├── firestore.rules        ← NÃO vai na extensão: publique no console
└── icon16/48/128.png
```

Ordem de carga importa: **`api.js` sempre primeiro** (todo o código usa `api.*`).

## 4. Como os dados fluem

- **Sessão**: `auth.js` guarda `{ uid, email, idToken, refreshToken }` em `storage.local`. O `idToken` vale 1 h e é renovado sozinho pelo `refreshToken`, que não expira — por isso **o login sobrevive a reiniciar o computador**. Falha de rede **não** desloga: a sessão só é apagada quando o servidor diz que o refresh morreu.
- **Perfil**: lido de `usuarios/{uid}` na abertura do popup, do painel e pelo service worker. É de onde saem o **nome** (autor) e a lista de **gabinetes** usada nas consultas.
- **Nota pessoal**: gravada em `usuarios/{uid}/notas` via REST. Cache em `storage.local.cachePessoal` para abrir instantâneo e para o clique na notificação.
- **Nota de gabinete**: gravada em `lembretes` com o array `tokens`. Cache em `storage.local.cacheGabinete`.
- **Prazo (`data_lembrete`)**: gravado como data absoluta `"AAAA-MM-DD"`. A *entrada* é em dias úteis — o popup calcula com [`feriados.js`](feriados.js) e grava o resultado. Mantenha `FERIADOS_EXTRA` atualizada com a portaria anual do tribunal.
- **Avisos**: `chrome.alarms` às 09:00 do dia do lembrete. Nomes: `pess|<id>` (pessoal), `gab|<id>` (gabinete) e `nota:<chave>` (legado). Um alarme periódico de 1 h refaz a varredura, e a aba do PJe pede uma sincronização a cada 5 min (com piso de 2 min entre elas) — o Firestore no plano gratuito não tem push.
- **Trava `avisados`** (`storage.local`) garante **um único aviso** por nota/data mesmo com as ressincronizações; entradas com mais de 60 dias são podadas na partida.
- **Selos na página do PJe**: dois selos ao lado do botão **✚ nota**, com tons distintos — 🔒 **verde** = suas notas pessoais, 👥 **azul** = notas do gabinete. Cada um mostra as pendências daquele processo e ganha um anel vermelho quando há prazo vencido (sem perder a cor que identifica a origem).
- **Selo na lista de processos** (painel de tarefas e etiquetas): o content script lê o CNJ de cada `<processo-datalist-card>`, cruza com `cachePessoal`/`cacheGabinete` (uma leitura por varredura, não por cartão) e põe um sino na faixa de ícones do cartão. Verde = pendente no prazo, vermelho = pendente vencida, cinza = só concluídas, oculto = sem nota. O selo é repintado quando o cache muda e quando o Angular reaproveita o cartão para outro processo ao paginar. Clicar abre o mesmo diálogo, na aba Lembretes, apontando para o processo do cartão; a nota criada dali fica sem link até o processo ser aberto (o service worker corrige via `corrigirLinks`). O painel roda num iframe de `frontend.cloud.pje.jus.br`, por isso o `content_scripts` tem `all_frames: true` e essa origem em `matches`; dentro de um frame o script **não** grava `processoAtual` nem mexe no badge (só o frame principal fala pelo processo aberto), e numa página com cartões o CNJ solto no texto não é tratado como processo aberto.
- **Filtro e prévia na lista**: o filtro fica em `sessionStorage` (`lpje-filtro`) e oculta o `<li>` do cartão; a prévia é um `<div id="lpje-previa">` fixo, montado a partir da última contagem (`contagemAtual`), que guarda as notas por processo.
- **Modelos de nota**: `storage.sync.modelosNota` (lista editada em Ajustes, até 20) e `storage.local.textosRecentes` (últimos 6 textos salvos); `montarChipsModelos()` em `comum.js` monta os chips nas duas telas.
- **Badge**: o content script conta as pendências do processo aberto e o service worker pinta o número **por aba**. Fora do PJe vale o badge **global**, com o que vence hoje ou já venceu — antes o contador sumia justamente fora do PJe.
- **Compositor no PJe**: o botão **✚ nota** monta um `<dialog>` na própria página. O content script não carrega `firestore.js`/`auth.js` (roda no mundo isolado), então pergunta ao service worker o contexto da conta (`tipo: "contexto"`) e manda a nota para ele gravar (`tipo: "criarNota"`). Antes o botão tentava `action.openPopup()`, que exige gesto recente do usuário e falhava no salto content → service worker: o mesmo clique ora abria o popup, ora uma aba com o painel. Para abrir o popup, use **Alt+Shift+L** ou o ícone da barra.
- **Som dos avisos**: a extensão **não toca som próprio** — quem emite o som é o sistema operacional, conforme as configurações de notificação do Windows. Se o som estiver desligado lá (ou o Assistente de Foco ativo), o aviso aparece calado.
- **Legado**: notas antigas em `storage.sync` (`nota:*`) continuam disparando lembretes até o primeiro login, quando o popup oferece **migrá-las** para a conta. O token único antigo vira automaticamente um gabinete do perfil.

## 5. Segurança e LGPD — leia antes de distribuir ao gabinete

**O que o login resolveu:**

- **Notas pessoais são privadas de verdade.** A regra compara o `uid` do caminho com o `uid` do login (`request.auth.uid == uid`); ninguém acessa a nota de outra pessoa, e só a API key não lê mais nada.
- **Toda operação exige usuário autenticado** — não há mais acesso anônimo ao banco.

**O que continua sendo limitação — e precisa ser dito à equipe:**

- **O código de acesso do gabinete é uma senha compartilhada.** Quem o tem lê, escreve e apaga as notas daquele grupo. Ele é gerado com entropia forte e tem botão de copiar; envie **apenas por canal interno**.
- **Não há isolamento real entre gabinetes.** As regras não têm como saber quais códigos você digitou, então **qualquer usuário logado pode, em tese, listar a coleção `lembretes` inteira**. A separação por grupo é feita no cliente. O código é "não fica óbvio", não controle de acesso.
- **Por isso: não transcreva conteúdo de processo em segredo de justiça em nota compartilhada.** A extensão já detecta o selo e não envia partes/classe ao Firestore, mas o texto que você digita vai como está — e o Firestore é nuvem fora do tribunal.
- **Não existe revogação individual de gabinete.** Alguém sai da equipe → crie um gabinete novo e avise os demais. As notas antigas permanecem sob o código antigo.
- **Autoria não é verificável a fundo**: o campo `autor` vem do nome que a pessoa definiu no próprio perfil. Dá para rastrear a conta (`uid`), mas o nome exibido é auto-declarado.
- A **API key** vai embutida na extensão e não é segredo — a proteção real são as regras. Ainda assim, mantenha a restrição de API da chave limitada às três APIs da [seção 2](#2-configuração-no-console-uma-vez).

## 6. Custo

Plano gratuito (Spark): 50 mil leituras, 20 mil gravações e 1 GiB/dia. Cada
sincronização lê o perfil + as notas dos seus gabinetes + as suas notas
pessoais. Um gabinete de 10 pessoas com 300 notas, com a varredura de 1 h mais
os pedidos da aba do PJe (piso de 2 min entre eles), fica na casa de algumas
dezenas de milhares de leituras/dia no pior caso. Se apertar, aumente
`SYNC_GABINETE_MIN` e `SYNC_SOB_DEMANDA_MS` em [`background.js`](background.js).

## 7. Instalação por navegador (Chrome, Edge e Firefox)

O código é o mesmo para os três. O que muda é só o **manifesto**, porque o
Firefox não suporta `background.service_worker` (usa background *scripts*).

| Navegador | Manifesto | Como carregar |
|---|---|---|
| Chrome | `manifest.json` | `chrome://extensions` → Modo do desenvolvedor → "Carregar sem compactação" |
| Edge | `manifest.json` | `edge://extensions` → Modo de desenvolvedor → "Carregar sem pacote" |
| Firefox | `manifest.firefox.json` | ver abaixo |

**Firefox** — troque o manifesto antes de carregar:

```bash
cp manifest.json manifest.chrome.json      # guarda o original
cp manifest.firefox.json manifest.json
```

Depois abra `about:debugging#/runtime/this-firefox` → "Carregar extensão
temporária" → escolha o `manifest.json`. Lembre de restaurar
(`cp manifest.chrome.json manifest.json`) antes de voltar ao Chrome.

Detalhes do porte para Firefox:

- [`api.js`](api.js) escolhe `browser.*` (Firefox, com promessas) ou `chrome.*`
  (Chrome/Edge). Todo o código usa `api.*` — nunca `chrome.*` direto.
- `importScripts` só roda quando existe (service worker); no Firefox as
  dependências vêm pelo array `background.scripts`.
- `requireInteraction`/`priority` nas notificações são do Chrome: há um
  *fallback* que recria a notificação sem eles.
- No MV3 do Firefox as `host_permissions` são **opcionais** — o usuário precisa
  autorizar o acesso ao `pje.tjba.jus.br` na primeira vez.
- Instalação permanente no Firefox exige extensão **assinada** pela Mozilla
  (AMO). O carregamento temporário some ao fechar o navegador.
- Ao publicar na AMO, será preciso declarar
  `browser_specific_settings.gecko.data_collection_permissions` — escolha as
  categorias conforme o que o gabinete considera que a extensão coleta.

> Validado com `npx web-ext lint`: **0 erros, 0 avisos** no manifesto do Firefox.

## 8. Primeiro uso (roteiro)

Ao instalar, a extensão abre sozinha a tela **Bem-vindo** do painel, com os
três passos abaixo e um botão em cada um. Se quiser refazer, é `#/bemvindo`.

1. **Sua conta** — escolha *Criar conta*, informe e-mail e senha (mínimo 6
   caracteres) e **confirme a senha**. Guarde-a: a sessão não expira, então
   você só vai redigitá-la ao trocar de computador — e é fácil esquecer.
2. **Seu nome** — obrigatório só para as notas do gabinete (é o autor exibido).
   Notas privadas funcionam sem ele.
3. **Gabinete (opcional)** — crie um (ganha um código de acesso) ou entre com o
   código que recebeu.
4. Abra um processo no PJe e clique em **✚ nota** ao lado do número: o
   formulário abre na própria página. Escolha em **Quem vê** entre *Só eu* e
   *Gabinete*.

Se ninguém receber o e-mail de redefinição de senha (comum em correio
institucional que barra o remetente do Firebase), troque a senha direto no
Console do Firebase → **Authentication → Users → ⋮ → Editar usuário**. O `uid`
não muda, então as notas continuam onde estão.
