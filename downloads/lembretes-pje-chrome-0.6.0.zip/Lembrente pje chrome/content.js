const CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;

// O painel do PJe (tarefas, etiquetas) é um iframe de OUTRA origem
// (frontend.cloud.pje.jus.br) dentro de pje.tjba.jus.br. O manifest injeta
// este script em todos os frames; aqui só o frame principal fala pelo
// "processo aberto" (badge, processoAtual) — os frames cuidam dos selos da lista.
const EM_FRAME = window !== window.top;

// Cartão de processo nas listas do painel (tarefas, etiquetas).
const SELETOR_CARTAO = "processo-datalist-card";

// Fala com o service worker tolerando o contexto invalidado (o MV3 hiberna
// o SW; sendMessage pode lançar "Extension context invalidated").
function enviarBg(msg) {
  try { api.runtime.sendMessage(msg); } catch (_) { /* SW reiniciando */ }
}

// Igual ao enviarBg, mas espera a resposta. Devolve null se o SW não responder.
function pedirBg(msg) {
  return new Promise((resolve) => {
    try {
      const r = api.runtime.sendMessage(msg);
      if (r && typeof r.then === "function") r.then(resolve).catch(() => resolve(null));
      else resolve(r ?? null);
    } catch (_) { resolve(null); }
  });
}

function extrairNumero() {
  // 1. Fonte mais confiável: o número limpo dentro do onclick do botão "copiar".
  const clipboard = document.querySelector(".mais-detalhes i.fa-clipboard[onclick]");
  const doOnclick = clipboard?.getAttribute("onclick")?.match(CNJ)?.[0];
  if (doOnclick) return doOnclick;

  // 2. Reserva: texto do título do processo no topo.
  const titulo = document.querySelector("a.titulo-topo");
  const doTitulo = titulo?.textContent.match(CNJ)?.[0];
  if (doTitulo) return doTitulo;

  // 3. Último recurso: qualquer CNJ no texto da página — mas nunca numa lista
  // de processos, onde o primeiro cartão viraria o "processo aberto".
  if (document.querySelector(SELETOR_CARTAO)) return null;
  return document.body.innerText.match(CNJ)?.[0] ?? null;
}

// Lê o <dd> que vem logo depois de um <dt> com o rótulo pedido.
function lerCampo(rotulo) {
  const dts = document.querySelectorAll("#maisDetalhes dt");
  for (const dt of dts) {
    if (dt.textContent.trim().toLowerCase() === rotulo.toLowerCase()) {
      return dt.nextElementSibling?.textContent.trim() || null;
    }
  }
  return null;
}

// linkUtil() vem de comum.js. location.href já traz query e hash inteiros —
// é o link completo do processo que o PJe abre.
function capturarUrl() {
  processoUrl = linkUtil(location.href) || processoUrl;
}

function extrairContexto() {
  const numero = extrairNumero();
  if (!numero) return null;

  const segredo = (lerCampo("Segredo de justiça?") || "").toUpperCase() === "SIM";

  return {
    numero,
    url: processoUrl,
    segredo,
    classe: lerCampo("Classe judicial"),
    orgao: document.querySelector("#maisDetalhes dd")
      ? lerCampo("Órgão julgador")
      : null,
    // Sob segredo de justiça, nada de partes sai da página.
    partes: segredo
      ? null
      : document.querySelector("a.titulo-topo small")?.textContent.trim() || null,
    capturadoEm: new Date().toISOString()
  };
}

/* =========================================================================
   Controles injetados no cabeçalho do processo:
   - selos com a contagem de notas (pessoais e do gabinete);
   - botão "✚ nota" que abre o COMPOSITOR NA PRÓPRIA PÁGINA.

   Antes o botão mandava abrir o popup e, quando o navegador recusava (o
   gesto se perde no salto content → service worker), o painel abria numa aba
   nova. Mesmo clique, dois destinos possíveis — imprevisível e sempre com
   troca de contexto. Agora a nota é escrita aqui mesmo, sem sair do processo.
   ========================================================================= */

function injetarEstilo() {
  if (document.getElementById("lpje-estilo")) return;
  const s = document.createElement("style");
  s.id = "lpje-estilo";
  s.textContent = `
    #lpje-barra { display: inline-flex; align-items: center; gap: 6px;
      vertical-align: middle; list-style: none;
      font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
    li#lpje-barra { padding: 15px 12px 0; }
    span#lpje-barra { margin-left: 10px; }
    #lpje-barra .lpje-aviso { display: none; align-items: center; gap: 4px;
      border-radius: 12px; padding: 4px 9px; font-size: 12px; min-height: 24px;
      font-weight: 600; line-height: 1; border: 1px solid transparent;
      background: none; cursor: pointer; font-family: inherit; }
    /* Verde-carimbo = suas notas pessoais. */
    #lpje-barra .lpje-aviso.priv { background: #EBF2EF; color: #2F6F5E; border-color: #cfe0d9; }
    /* Azul-arquivo = notas do gabinete (mesma cor usada no popup e no painel). */
    #lpje-barra .lpje-aviso.gab { background: #EDF0F7; color: #4A5A8A; border-color: #ccd5ea; }
    /* Vencida: anel vermelho, mas SEM perder o tom que identifica a origem. */
    #lpje-barra .lpje-aviso.venceu { border-color: #A6402C; box-shadow: 0 0 0 2px rgba(166,64,44,.22); }
    #lpje-barra .lpje-num { font-variant-numeric: tabular-nums; }
    #lpje-barra .lpje-add { display: inline-flex; align-items: center; gap: 5px;
      background: #2F6F5E; color: #fff; border: 0; border-radius: 12px;
      padding: 5px 12px; font-size: 12px; font-weight: 600; cursor: pointer;
      line-height: 1; min-height: 26px; font-family: inherit; }
    #lpje-barra .lpje-add:hover { background: #265a4c; }
    #lpje-barra button:focus-visible { outline: 2px solid #2F6F5E; outline-offset: 2px; }

    /* ---------- sino de vencidas na navbar do PJe ---------- */
    /* A <ul class="navbar-info"> do PJe é flex em COLUNA: um <li> irmão ficava
       empilhado acima do usuário. O sino entra DENTRO do li.menu-usuario, que
       passa a ser flex em linha (o .dropdown-menu é absoluto e não participa). */
    li.menu-usuario.lpje-com-sino { display: flex !important; align-items: center !important; }
    #lpje-sino { display: flex; align-items: center; flex: none; }
    #lpje-sino button {
      position: relative; background: none; border: 0; cursor: pointer;
      padding: 10px 12px; display: flex; align-items: center; line-height: 1;
    }
    #lpje-sino svg { width: 20px; height: 20px; fill: #fff; opacity: .85; }
    #lpje-sino button:hover svg { opacity: 1; }
    #lpje-sino button:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
    #lpje-sino.lpje-sem-conta svg { opacity: .7; }
    #lpje-sino .lpje-sino-num.conta { background: #D08A1E; }
    #lpje-sino .lpje-sino-num {
      position: absolute; top: 3px; right: 3px; background: #A6402C; color: #fff;
      border-radius: 9px; font-size: 10.5px; font-weight: 700; min-width: 16px;
      height: 16px; line-height: 16px; text-align: center; padding: 0 3px;
      font-family: system-ui, sans-serif; font-variant-numeric: tabular-nums;
    }

    /* ---------- selo nas listas de processos (tarefas, etiquetas) ---------- */
    .lpje-selo-lista { display: inline-flex; align-items: center; gap: 4px;
      vertical-align: middle; margin: 0 6px 0 0; padding: 2px 8px; min-height: 22px;
      border-radius: 11px; border: 1px solid transparent; background: none;
      font: 600 11.5px/1 system-ui, -apple-system, "Segoe UI", sans-serif;
      cursor: pointer; }
    .lpje-selo-lista svg { width: 13px; height: 13px; fill: currentColor; flex: none; }
    .lpje-selo-lista .lpje-num { font-variant-numeric: tabular-nums; }
    /* Verde = há nota pendente e nenhuma passou do prazo. */
    .lpje-selo-lista.ok { background: #EBF2EF; color: #2F6F5E; border-color: #cfe0d9; }
    /* Vermelho = ao menos uma nota pendente passou do prazo. */
    .lpje-selo-lista.venceu { background: #F8ECE8; color: #A6402C; border-color: #e6c4bb; }
    /* Cinza = só notas concluídas. */
    .lpje-selo-lista.feito { background: #F1F0EC; color: #5F6562; border-color: #E2DFD8; }
    .lpje-selo-lista:hover { filter: brightness(.95); }
    .lpje-selo-lista:focus-visible { outline: 2px solid #2F6F5E; outline-offset: 2px; }

    .lpje-selo-lista .lpje-gab { font-size: 11px; line-height: 1; }

    /* ---------- prévia das notas ao passar o mouse no selo ---------- */
    #lpje-previa { position: fixed; z-index: 100000; width: 300px; max-width: calc(100vw - 16px);
      background: #FBFAF7; color: #1A211E; border: 1px solid #E2DFD8; border-radius: 6px;
      box-shadow: 0 12px 32px -14px rgba(26,33,30,.5); padding: 6px 10px; text-align: left;
      font: 12.5px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif; }
    #lpje-previa .lpje-pv { padding: 6px 0; border-bottom: 1px dashed #E2DFD8; }
    #lpje-previa .lpje-pv:last-child { border-bottom: 0; }
    #lpje-previa .lpje-pv-texto { margin: 0; white-space: pre-wrap; overflow-wrap: break-word; }
    #lpje-previa .lpje-pv-meta { margin: 3px 0 0; font-size: 11.5px; color: #5F6562;
      display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
    #lpje-previa .lpje-pv-meta b { color: #1A211E; font-weight: 600; }
    #lpje-previa .lpje-etq { font-size: 10px; padding: 2px 5px; border-radius: 2px; font-weight: 600; }
    #lpje-previa .lpje-etq.sua { background: #EBF2EF; color: #2F6F5E; }
    #lpje-previa .lpje-etq.gab { background: #EDF0F7; color: #4A5A8A; }
    #lpje-previa time { color: #2F6F5E; font-family: ui-monospace, Menlo, monospace; }
    #lpje-previa .venceu time { color: #A6402C; font-weight: 600; }
    #lpje-previa .lpje-pv-mais { margin: 4px 0 2px; font-size: 11.5px; color: #5F6562; }

    /* ---------- filtro por nota no topo da lista ---------- */
    #lpje-filtro-lista { display: inline-flex; align-items: center; gap: 4px; margin: 3px 8px;
      vertical-align: middle; font: 600 11.5px/1 system-ui, -apple-system, "Segoe UI", sans-serif; }
    #lpje-filtro-lista .lpje-rotulo { color: #5F6562; margin-right: 2px; }
    #lpje-filtro-lista button { border: 1px solid #E2DFD8; background: #fff; color: #5F6562;
      border-radius: 11px; padding: 4px 9px; font: inherit; cursor: pointer; min-height: 22px; }
    #lpje-filtro-lista button[aria-checked="true"] { background: #2F6F5E; border-color: #2F6F5E; color: #fff; }
    #lpje-filtro-lista button[data-f="venc"][aria-checked="true"] { background: #A6402C; border-color: #A6402C; }
    #lpje-filtro-lista button:focus-visible { outline: 2px solid #2F6F5E; outline-offset: 2px; }
    #lpje-filtro-lista .lpje-ocultos { color: #5F6562; font-weight: 400; margin-left: 4px; }

    /* ---------- modelos no compositor ---------- */
    #lpje-dlg .lpje-modelos { display: flex; gap: 5px; flex-wrap: wrap; margin: 0 0 8px; }
    #lpje-dlg .lpje-modelos button { border: 1px solid #E2DFD8; background: #fff; border-radius: 12px;
      padding: 4px 10px; font: inherit; font-size: 12px; color: #5F6562; cursor: pointer; min-height: 26px; }
    #lpje-dlg .lpje-modelos button.recente { border-style: dashed; }
    #lpje-dlg .lpje-modelos button:hover { border-color: #2F6F5E; color: #2F6F5E; }

    /* ---------- compositor na página ---------- */
    #lpje-dlg {
      border: 1px solid #E2DFD8; border-radius: 6px; padding: 0; width: 500px;
      max-width: calc(100vw - 32px); background: #FBFAF7; color: #1A211E;
      font: 14px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif;
      box-shadow: 0 18px 48px -20px rgba(26,33,30,.55);
    }
    #lpje-dlg::backdrop { background: rgba(26,33,30,.38); }
    /* [hidden] perde para display:flex/grid de regra de autor; aqui ele SEMPRE esconde. */
    #lpje-dlg [hidden] { display: none !important; }
    #lpje-dlg .lpje-cab { position: relative; padding: 14px 44px 6px 16px; }
    #lpje-dlg .lpje-x {
      position: absolute; top: 10px; right: 10px; width: 28px; height: 28px;
      border: 1px solid transparent; border-radius: 3px; background: none;
      color: #5F6562; font-size: 17px; line-height: 1; cursor: pointer;
      display: grid; place-items: center; padding: 0; font-family: inherit;
    }
    #lpje-dlg .lpje-x:hover { border-color: #E2DFD8; color: #A6402C; background: #fff; }

    /* ---------- abas do diálogo (mesmo desenho do popup) ---------- */
    #lpje-dlg .lpje-abas { display: flex; gap: 16px; padding: 0 16px;
      border-bottom: 1px solid #E2DFD8; }
    #lpje-dlg .lpje-abas button {
      border: 0; background: none; cursor: pointer; font: inherit;
      font-size: 12px; letter-spacing: .06em; text-transform: uppercase;
      color: #5F6562; padding: 9px 2px; margin-bottom: -1px;
      border-bottom: 2px solid transparent;
    }
    #lpje-dlg .lpje-abas button[aria-selected="true"] {
      color: #1A211E; border-bottom-color: #2F6F5E; font-weight: 600;
    }

    /* ---------- lista de lembretes do processo ---------- */
    #lpje-dlg .lpje-lista { max-height: 330px; overflow-y: auto; }
    #lpje-dlg .lpje-item { display: flex; gap: 8px; padding: 9px 0;
      align-items: flex-start; border-bottom: 1px dashed #E2DFD8; font-size: 13px; }
    #lpje-dlg .lpje-item:last-child { border-bottom: 0; }
    #lpje-dlg .lpje-item .lpje-marcar { flex: none; width: 24px; height: 24px;
      border: 0; background: none; padding: 0; cursor: pointer;
      display: grid; place-items: center; min-height: 24px; }
    #lpje-dlg .lpje-item .lpje-marcar input { width: 15px; height: 15px; margin: 0;
      pointer-events: none; accent-color: #2F6F5E; }
    #lpje-dlg .lpje-item.gab .lpje-marcar input { accent-color: #4A5A8A; }
    #lpje-dlg .lpje-item .lpje-meio { flex: 1; min-width: 0; }
    #lpje-dlg .lpje-item .lpje-texto { margin: 0; white-space: pre-wrap;
      overflow-wrap: break-word; }
    #lpje-dlg .lpje-item.feito .lpje-texto { color: #5F6562; text-decoration: line-through; }
    #lpje-dlg .lpje-item .lpje-roda { margin: 4px 0 0; font-size: 12px; color: #5F6562;
      display: flex; flex-wrap: wrap; gap: 4px 8px; align-items: center; }
    #lpje-dlg .lpje-item .lpje-roda b { font-weight: 600; color: #1A211E; }
    #lpje-dlg .lpje-item .lpje-etq { font-size: 10px; padding: 2px 6px;
      letter-spacing: .04em; border-radius: 2px; font-weight: 600; white-space: nowrap; }
    #lpje-dlg .lpje-item .lpje-etq.sua { background: #EBF2EF; color: #2F6F5E; }
    #lpje-dlg .lpje-item .lpje-etq.gab { background: #EDF0F7; color: #4A5A8A; }
    #lpje-dlg .lpje-item time { color: #2F6F5E; font-family: ui-monospace, Menlo, monospace; }
    #lpje-dlg .lpje-item.venceu time { color: #A6402C; font-weight: 600; }
    #lpje-dlg .lpje-item .lpje-acoes { display: flex; gap: 2px; flex: none; }
    #lpje-dlg .lpje-item .lpje-acoes button {
      width: 24px; height: 24px; min-height: 24px; min-width: 24px;
      border: 1px solid transparent; background: none; color: #5F6562;
      cursor: pointer; border-radius: 3px; font-size: 13px; line-height: 1;
      display: grid; place-items: center; padding: 0; font-family: inherit;
    }
    #lpje-dlg .lpje-item .lpje-acoes button:hover {
      border-color: #E2DFD8; color: #2F6F5E; background: #fff; }
    #lpje-dlg .lpje-item .lpje-acoes button.lpje-apagar:hover {
      border-color: #A6402C; color: #A6402C; }
    #lpje-dlg .lpje-vazio { margin: 0; padding: 14px 0; font-size: 13px; color: #5F6562; }
    #lpje-dlg .lpje-cab h2 { font: 600 12px/1.3 inherit; letter-spacing: .1em;
      text-transform: uppercase; color: #5F6562; margin: 0 0 4px; }
    #lpje-dlg .lpje-cab .lpje-cnj { font-family: ui-monospace, Menlo, monospace; font-size: 14px; }
    #lpje-dlg .lpje-corpo { padding: 14px 16px 16px; }
    #lpje-dlg textarea {
      width: 100%; min-height: 76px; resize: vertical; padding: 9px 11px;
      border: 1px solid #E2DFD8; border-radius: 3px; background: #fff;
      font: inherit; color: #1A211E; box-sizing: border-box; margin: 0;
    }
    #lpje-dlg .lpje-lbl { display: block; font-size: 12px; letter-spacing: .04em;
      text-transform: uppercase; color: #5F6562; margin: 14px 0 6px; }
    #lpje-dlg .lpje-chips { display: flex; gap: 5px; flex-wrap: wrap; }
    #lpje-dlg .lpje-chips button, #lpje-dlg .lpje-quem button {
      border: 1px solid #E2DFD8; background: #fff; border-radius: 3px;
      padding: 6px 11px; font: inherit; font-size: 12.5px; color: #5F6562;
      cursor: pointer; min-height: 30px; min-width: 32px;
    }
    #lpje-dlg .lpje-quem { display: flex; gap: 6px; flex-wrap: wrap; }
    #lpje-dlg .lpje-quem button { border-radius: 15px; padding: 6px 13px; }
    #lpje-dlg .lpje-chips button[aria-checked="true"] {
      background: #2F6F5E; border-color: #2F6F5E; color: #fff; font-weight: 600;
    }
    #lpje-dlg .lpje-quem button[aria-checked="true"] {
      background: #EBF2EF; border-color: #2F6F5E; color: #2F6F5E; font-weight: 600;
    }
    #lpje-dlg .lpje-quem button[data-quem="gab"][aria-checked="true"] {
      background: #EDF0F7; border-color: #4A5A8A; color: #4A5A8A;
    }
    #lpje-dlg .lpje-quem button:disabled { opacity: .55; cursor: not-allowed; }
    #lpje-dlg input[type="number"], #lpje-dlg input[type="date"] {
      margin-top: 8px; padding: 7px 10px; border: 1px solid #E2DFD8;
      border-radius: 3px; background: #fff; font: inherit; font-size: 12.5px;
      color: #1A211E; width: 100%; box-sizing: border-box;
    }
    #lpje-dlg .lpje-info { margin: 6px 0 0; font-size: 12px; color: #5F6562; min-height: 16px; }
    #lpje-dlg .lpje-info b { color: #2F6F5E; }
    #lpje-dlg .lpje-destinos { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
    #lpje-dlg .lpje-destinos label {
      display: inline-flex; align-items: center; gap: 6px; cursor: pointer;
      border: 1px solid #E2DFD8; border-radius: 15px; padding: 5px 11px;
      font-size: 12.5px; color: #5F6562; background: #fff; min-height: 28px;
    }
    #lpje-dlg .lpje-destinos label.marcado {
      background: #EDF0F7; border-color: #4A5A8A; color: #4A5A8A; font-weight: 600;
    }
    #lpje-dlg .lpje-pe { display: flex; align-items: center; gap: 8px; margin-top: 16px; }
    #lpje-dlg .lpje-pe .lpje-atalho { margin-left: auto; font-size: 11.5px; color: #5F6562; }
    #lpje-dlg .lpje-salvar {
      border: 0; border-radius: 3px; background: #2F6F5E; color: #fff;
      font: inherit; font-size: 13.5px; font-weight: 600; padding: 9px 18px;
      cursor: pointer; min-height: 38px;
    }
    #lpje-dlg .lpje-salvar:disabled { background: #E2DFD8; color: #5F6562; cursor: not-allowed; }
    #lpje-dlg .lpje-fechar {
      border: 1px solid #E2DFD8; border-radius: 3px; background: #fff; color: #5F6562;
      font: inherit; font-size: 13px; padding: 9px 14px; cursor: pointer; min-height: 38px;
    }
    #lpje-dlg .lpje-status { margin: 10px 0 0; font-size: 12.5px; color: #2F6F5E; min-height: 17px; }
    #lpje-dlg .lpje-status.ruim { color: #A6402C; font-weight: 500; }
    #lpje-dlg .lpje-bloqueio { font-size: 13px; color: #5F6562; }
    #lpje-dlg .lpje-bloqueio b { color: #1A211E; }
    #lpje-dlg :focus-visible { outline: 2px solid #2F6F5E; outline-offset: 1px; }
    @media (prefers-reduced-motion: reduce) {
      #lpje-dlg, #lpje-dlg * { animation: none !important; transition: none !important; }
    }
  `;
  document.head.appendChild(s);
}

// Grupo de ícones da esquerda da navbar: espaço livre ao lado do título e o
// lugar certo para controles de topo. Dentro do <a class="titulo-topo"> a barra
// quebrava linha (o <small> das partes está lá) e cobria a barra de pesquisa —
// e todo clique caía no dropdown "mais detalhes" daquele mesmo <a>.
function listaDeIcones() {
  return document.querySelector("ul.navbar-nav.navbar-left.menu-icones-topo");
}

// Reserva para instalações do PJe sem esse grupo de ícones.
function pontoDeInjecao() {
  return document.querySelector(".mais-detalhes i.fa-clipboard")
      || document.querySelector(".mais-detalhes a.titulo-topo-desktop")
      || document.querySelector(".mais-detalhes a.titulo-topo")
      || document.querySelector("a.titulo-topo");
}

// Selo de contagem. Vira <button> para ser focável e anunciável: como <span>
// com title, a informação "já existe nota aqui" não existia para leitor de tela.
function criarAviso(classe, icone) {
  const aviso = document.createElement("button");
  aviso.type = "button";
  aviso.className = "lpje-aviso " + classe;
  const ico = document.createElement("span");
  ico.textContent = icone;
  ico.setAttribute("aria-hidden", "true");
  const num = document.createElement("span");
  num.className = "lpje-num";
  aviso.append(ico, num);
  aviso.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    // Histórico ali mesmo, sem trocar de contexto: o mesmo diálogo do "✚ nota",
    // já aberto na aba Lembretes (antes ia para o popup/painel da extensão).
    abrirCompositor("lembretes");
  });
  return aviso;
}

function construirControles(tag) {
  const barra = document.createElement(tag);
  barra.id = "lpje-barra";

  const add = document.createElement("button");
  add.type = "button";
  add.className = "lpje-add";
  add.textContent = "✚ nota";
  add.title = "Anotar neste processo (Lembretes PJe)";
  add.setAttribute("aria-label", "Anotar neste processo");
  add.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    abrirCompositor();
  });

  barra.append(criarAviso("priv", "🔒"), criarAviso("gab", "👥"), add);
  return barra;
}

function garantirControles() {
  const existente = document.getElementById("lpje-barra");
  const lista = listaDeIcones();

  if (lista) {
    if (existente && lista.contains(existente)) return;   // já no lugar
    existente?.remove();
    injetarEstilo();
    lista.appendChild(construirControles("li"));
    atualizarContagem();
    return;
  }

  const ponto = pontoDeInjecao();
  if (!ponto) return;
  if (existente && existente.previousElementSibling === ponto) return;
  existente?.remove();
  injetarEstilo();
  ponto.insertAdjacentElement("afterend", construirControles("span"));
  atualizarContagem();
}

/* =========================================================================
   Sino na navbar do PJe (ao lado do bloco do usuário): mostra quantos
   lembretes PASSARAM do prazo, em qualquer processo. Clicar abre o painel
   da extensão (#/painel), que lista as vencidas no topo.
   ========================================================================= */

function garantirSino() {
  // Âncora: o bloco do usuário (li.menu-usuario), que só existe na PÁGINA
  // INICIAL do PJe (painel-usuario-interno). As telas de processo têm outra
  // estrutura de navbar — lá valem os selos por processo, não o sino global.
  const perfilUsuario = document.querySelector("ul.navbar-right li.menu-usuario")
                     || document.querySelector(".navbar-collapse li.menu-usuario");
  const existente = document.getElementById("lpje-sino");
  if (!perfilUsuario) {
    existente?.remove();
    document.querySelector("li.menu-usuario.lpje-com-sino")?.classList.remove("lpje-com-sino");
    return;
  }
  if (existente && perfilUsuario.firstElementChild === existente) return;
  existente?.remove();

  injetarEstilo();
  const li = document.createElement("span");   // <span>: é filho do li.menu-usuario
  li.id = "lpje-sino";
  li.style.display = "none";              // só aparece quando há vencidas

  const btn = document.createElement("button");
  btn.type = "button";
  // Sino sólido (desenho próprio, sem depender do font-awesome do PJe).
  btn.innerHTML =
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a2 2 0 0 0-2 2v.34C7.06 5.16 5 7.83 5 11v4l-1.7 2.55A1 1 0 0 0 4.13 19h15.74a1 1 0 0 0 .83-1.45L19 15v-4c0-3.17-2.06-5.84-5-6.66V4a2 2 0 0 0-2-2Zm0 20a3 3 0 0 0 2.82-2H9.18A3 3 0 0 0 12 22Z"/></svg>'
    + '<span class="lpje-sino-num"></span>';
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    const semConta = document.getElementById("lpje-sino")?.classList.contains("lpje-sem-conta");
    enviarBg({ tipo: "abrirPainel", vista: semConta ? "ajustes" : "painel" });
  });

  li.appendChild(btn);
  perfilUsuario.classList.add("lpje-com-sino");
  perfilUsuario.prepend(li);
  atualizarSino();
}

// Conta as pendências vencidas (data < hoje) em TODOS os processos, a partir
// dos caches que o service worker mantém — mesma fonte do badge global.
async function atualizarSino() {
  const li = document.getElementById("lpje-sino");
  if (!li) return;
  const num = li.querySelector(".lpje-sino-num");
  const btn = li.querySelector("button");

  let logado = false;
  try { logado = Boolean((await api.storage.local.get("sessao")).sessao); } catch (_) { /* sem storage */ }

  // Sem conta, o sino vira convite para entrar.
  if (!logado) {
    li.style.display = "flex";
    li.classList.add("lpje-sem-conta");
    num.classList.add("conta");
    if (num.textContent !== "!") num.textContent = "!";
    const rotulo = "Lembretes PJe: entre na sua conta para anotar — clique para configurar";
    btn.title = rotulo;
    btn.setAttribute("aria-label", rotulo);
    return;
  }
  li.classList.remove("lpje-sem-conta");
  num.classList.remove("conta");

  let total = 0;
  const hoje = hojeISO();
  try {
    const { cachePessoal, cacheGabinete } =
      await api.storage.local.get(["cachePessoal", "cacheGabinete"]);
    for (const n of [...(cachePessoal?.notas || []), ...(cacheGabinete?.notas || [])]) {
      if (!n.concluido && n.data_lembrete && n.data_lembrete < hoje) total++;
    }
  } catch (_) { /* storage indisponível */ }

  if (!total) { li.style.display = "none"; return; }
  li.style.display = "flex";
  const texto = total > 99 ? "99+" : String(total);
  if (num.textContent !== texto) num.textContent = texto;
  const rotulo = total === 1
    ? "1 lembrete passou do prazo — abrir o painel"
    : `${total} lembretes passaram do prazo — abrir o painel`;
  btn.title = rotulo;
  btn.setAttribute("aria-label", rotulo);
}

/* ---------- som de aviso (pedido pelo service worker ao notificar) ----------
   O worker MV3 não toca áudio; esta aba toca um toque duplo curto via Web
   Audio. Se o navegador exigir gesto prévio (autoplay), falha em silêncio e
   fica só o som de sistema da notificação.                                  */

function tocarSom() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
    const nota = (freq, inicio, dur) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + inicio);
      gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + inicio + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + inicio + dur);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + inicio);
      osc.stop(ctx.currentTime + inicio + dur + 0.05);
    };
    nota(880, 0, 0.35);       // lá5
    nota(1174.66, 0.28, 0.5); // ré6
    setTimeout(() => ctx.close().catch(() => {}), 1500);
  } catch (_) { /* sem áudio disponível */ }
}

/* ---------- compositor na página ---------- */

let dlgAberto = false;

function chip(rotulo, valor) {
  const b = document.createElement("button");
  b.type = "button";
  b.setAttribute("role", "radio");
  b.setAttribute("aria-checked", "false");
  b.dataset.v = valor;
  b.textContent = rotulo;
  return b;
}

// Diálogo com duas abas: "Anotação" (compositor) e "Lembretes" (histórico do
// processo, com concluir/adiar/editar/excluir — o mesmo que o popup oferece).
// `abaInicial` decide onde abre: "✚ nota" → Anotação; selos de contagem → Lembretes.
// `processoAlvo` ({numero, digitos, url}) aponta outro processo que não o da página —
// é o caso do selo na lista de tarefas, onde cada cartão é um processo.
async function abrirCompositor(abaInicial = "nota", processoAlvo = null) {
  if (dlgAberto) return;
  injetarEstilo();

  const numero = processoAlvo?.numero ?? processoNumero;
  const digitos = processoAlvo?.digitos ?? processoDigitos;
  const url = processoAlvo?.url ?? processoUrl;

  const ctx = await pedirBg({ tipo: "contexto" });
  const dlg = document.createElement("dialog");
  dlg.id = "lpje-dlg";
  dlg.setAttribute("aria-labelledby", "lpje-dlg-tit");

  const cab = document.createElement("div");
  cab.className = "lpje-cab";
  const h2 = document.createElement("h2");
  h2.id = "lpje-dlg-tit";
  h2.textContent = "Notas deste processo";
  const cnj = document.createElement("div");
  cnj.className = "lpje-cnj";
  cnj.textContent = numero || "";
  cab.append(h2, cnj);

  // Fechar sempre à vista, nas duas abas (a aba Lembretes não tem rodapé).
  const bX = document.createElement("button");
  bX.type = "button";
  bX.className = "lpje-x";
  bX.textContent = "×";
  bX.title = "Fechar (Esc)";
  bX.setAttribute("aria-label", "Fechar");
  bX.onclick = () => fechar();
  cab.appendChild(bX);

  // Painel da aba Anotação. Sem login ele vira o corpo único (sem abas).
  const corpo = document.createElement("div");
  corpo.className = "lpje-corpo";

  // Limpeza no próprio `fechar` e no evento `cancel` (Esc). Nem todo motor
  // dispara `close` em close() — depender só dele deixava o diálogo no DOM e
  // a trava `dlgAberto` presa, impedindo abrir de novo.
  const fechar = () => {
    if (dlg.open) dlg.close();
    dlg.remove();
    dlgAberto = false;
  };

  // O PJe tem handlers globais de tecla e clique que disparam postback do Seam
  // e derrubam a aba em error.seam. Nada que acontece dentro do modal sobe.
  for (const evento of ["keydown", "keypress", "keyup", "click", "dblclick",
                        "mousedown", "mouseup", "input", "change", "submit"]) {
    dlg.addEventListener(evento, (ev) => ev.stopPropagation());
  }

  // Sem conta não há onde gravar: explica e oferece o caminho, sem formulário.
  if (!ctx || !ctx.logado) {
    dlg.append(cab, corpo);
    const p = document.createElement("p");
    p.className = "lpje-bloqueio";
    p.append("Para anotar, ", document.createElement("b"));
    p.querySelector("b").textContent = "entre na sua conta";
    p.append(" da extensão. As notas ficam na conta e aparecem em qualquer computador.");
    const pe = document.createElement("div");
    pe.className = "lpje-pe";
    const bAbrir = document.createElement("button");
    bAbrir.type = "button";
    bAbrir.className = "lpje-salvar";
    bAbrir.textContent = "Abrir a extensão";
    bAbrir.onclick = () => { enviarBg({ tipo: "abrirPainel", vista: "ajustes" }); fechar(); };
    const bFechar = document.createElement("button");
    bFechar.type = "button";
    bFechar.className = "lpje-fechar";
    bFechar.textContent = "Fechar";
    bFechar.onclick = fechar;
    pe.append(bAbrir, bFechar);
    corpo.append(p, pe);
    document.body.appendChild(dlg);
    dlgAberto = true;
    dlg.addEventListener("cancel", fechar);   // Esc
    dlg.addEventListener("close", fechar);
    dlg.showModal();
    bAbrir.focus();
    return;
  }

  /* --- abas: Anotação | Lembretes --- */
  const abas = document.createElement("div");
  abas.className = "lpje-abas";
  abas.setAttribute("role", "tablist");
  abas.setAttribute("aria-label", "Seções do diálogo");

  const abaNota = document.createElement("button");
  abaNota.type = "button";
  abaNota.id = "lpje-aba-nota";
  abaNota.setAttribute("role", "tab");
  abaNota.textContent = "Anotação";

  const abaLem = document.createElement("button");
  abaLem.type = "button";
  abaLem.id = "lpje-aba-lem";
  abaLem.setAttribute("role", "tab");
  abaLem.textContent = "Lembretes";

  abas.append(abaNota, abaLem);

  corpo.setAttribute("role", "tabpanel");
  corpo.setAttribute("aria-labelledby", "lpje-aba-nota");

  const painelLem = document.createElement("div");
  painelLem.className = "lpje-corpo";
  painelLem.setAttribute("role", "tabpanel");
  painelLem.setAttribute("aria-labelledby", "lpje-aba-lem");

  dlg.append(cab, abas, corpo, painelLem);

  const ativar = (qual, focar) => {
    const naNota = qual !== "lembretes";
    abaNota.setAttribute("aria-selected", String(naNota));
    abaLem.setAttribute("aria-selected", String(!naNota));
    abaNota.tabIndex = naNota ? 0 : -1;
    abaLem.tabIndex = naNota ? -1 : 0;
    corpo.hidden = !naNota;
    painelLem.hidden = naNota;
    if (!naNota) carregarLembretes();
    if (focar) (naNota ? abaNota : abaLem).focus();
  };
  abaNota.addEventListener("click", () => ativar("nota", false));
  abaLem.addEventListener("click", () => ativar("lembretes", false));
  for (const b of [abaNota, abaLem]) {
    b.addEventListener("keydown", (ev) => {
      if (ev.key !== "ArrowLeft" && ev.key !== "ArrowRight") return;
      ev.preventDefault();
      ativar(b === abaNota ? "lembretes" : "nota", true);
    });
  }

  /* --- formulário --- */
  const ta = document.createElement("textarea");
  ta.maxLength = 1500;
  ta.placeholder = "O que precisa ser feito neste processo?";
  ta.setAttribute("aria-label", "Texto da nota");

  const modelos = document.createElement("div");
  modelos.className = "lpje-modelos";
  montarChipsModelos(modelos, ta);

  const lblPrazo = document.createElement("span");
  lblPrazo.className = "lpje-lbl";
  lblPrazo.id = "lpje-lbl-prazo";
  lblPrazo.textContent = "Lembrar em dias úteis";

  const chips = document.createElement("div");
  chips.className = "lpje-chips";
  chips.setAttribute("role", "radiogroup");
  chips.setAttribute("aria-labelledby", "lpje-lbl-prazo");
  ["5", "10", "15"].forEach((d) => chips.appendChild(chip(d, d)));
  chips.appendChild(chip("outro", "custom"));
  chips.appendChild(chip("data", "data"));
  chips.appendChild(chip("sem", "0"));

  const inCustom = document.createElement("input");
  inCustom.type = "number"; inCustom.min = "1"; inCustom.max = "365";
  inCustom.placeholder = "quantos dias úteis?";
  inCustom.setAttribute("aria-label", "Quantidade de dias úteis");
  inCustom.hidden = true;

  const inData = document.createElement("input");
  inData.type = "date";
  inData.setAttribute("aria-label", "Data do lembrete");
  inData.hidden = true;

  const info = document.createElement("p");
  info.className = "lpje-info";
  info.textContent = "sem prazo — escolha (opcional)";

  let prazo = { modo: "sem", dias: null, dataISO: null };
  const calcISO = () => {
    if (prazo.modo === "sem") return null;
    if (prazo.modo === "data") return prazo.dataISO || null;
    if (prazo.modo === "dias" && prazo.dias >= 1) return isoLocal(somarDiasUteis(hoje(), prazo.dias));
    return null;
  };
  const pintar = () => {
    const iso = calcISO();
    if (prazo.modo === "sem") { info.textContent = "sem prazo — só nota"; return; }
    if (!iso) { info.textContent = prazo.modo === "dias" ? "informe os dias úteis" : "escolha uma data"; return; }
    info.textContent = "";
    const b = document.createElement("b");
    b.textContent = dataLonga(iso);
    info.append("vence ", b, prazo.modo === "dias" ? ` · ${prazo.dias} dias úteis` : "");
  };

  ligarRadios(chips, (b) => {
    const v = b.dataset.v;
    inCustom.hidden = v !== "custom";
    inData.hidden = v !== "data";
    if (v === "custom") { prazo = { modo: "dias", dias: Number(inCustom.value) || null }; inCustom.focus(); }
    else if (v === "data") { prazo = { modo: "data", dataISO: inData.value || null }; }
    else if (v === "0") { prazo = { modo: "sem" }; }
    else { prazo = { modo: "dias", dias: Number(v) }; }
    pintar();
  });
  inCustom.oninput = () => { prazo = { modo: "dias", dias: Number(inCustom.value) || null }; pintar(); };
  inData.onchange = () => { prazo = { modo: "data", dataISO: inData.value || null }; pintar(); };

  const lblQuem = document.createElement("span");
  lblQuem.className = "lpje-lbl";
  lblQuem.id = "lpje-lbl-quem";
  lblQuem.textContent = "Quem vê";

  const quem = document.createElement("div");
  quem.className = "lpje-quem";
  quem.setAttribute("role", "radiogroup");
  quem.setAttribute("aria-labelledby", "lpje-lbl-quem");
  const bInd = chip("🔒 Só eu", "ind");
  const bGab = chip("👥 Gabinete", "gab");
  bInd.setAttribute("aria-checked", "true");
  bInd.dataset.quem = "ind"; bGab.dataset.quem = "gab";
  const grupos = ctx.grupos || [];
  // Sem gabinete ou sem nome definido, publicar em grupo é impossível — o
  // botão fica desabilitado com o motivo, em vez de falhar só ao salvar.
  const podeGab = grupos.length > 0 && Boolean(ctx.nome);
  bGab.disabled = !podeGab;
  if (!podeGab) {
    bGab.title = grupos.length
      ? "Defina seu nome na extensão para publicar no gabinete"
      : "Você ainda não participa de nenhum gabinete";
  }
  quem.append(bInd, bGab);

  const destinos = document.createElement("div");
  destinos.className = "lpje-destinos";
  destinos.hidden = true;
  for (const g of grupos) {
    const lab = document.createElement("label");
    const c = document.createElement("input");
    c.type = "checkbox"; c.value = g.token; c.checked = grupos.length === 1;
    c.onchange = () => lab.classList.toggle("marcado", c.checked);
    const s = document.createElement("span");
    s.textContent = g.nome || "gabinete";
    lab.classList.toggle("marcado", c.checked);
    lab.append(c, s);
    destinos.appendChild(lab);
  }

  let alvo = "ind";
  ligarRadios(quem, (b) => { alvo = b.dataset.quem; destinos.hidden = alvo !== "gab"; });

  const status = document.createElement("p");
  status.className = "lpje-status";
  status.setAttribute("role", "status");
  status.setAttribute("aria-live", "polite");

  const pe = document.createElement("div");
  pe.className = "lpje-pe";
  const bSalvar = document.createElement("button");
  bSalvar.type = "button";
  bSalvar.className = "lpje-salvar";
  bSalvar.textContent = "Salvar nota";
  const bCancelar = document.createElement("button");
  bCancelar.type = "button";
  bCancelar.className = "lpje-fechar";
  bCancelar.textContent = "Cancelar edição";
  bCancelar.hidden = true;
  const bFechar = document.createElement("button");
  bFechar.type = "button";
  bFechar.className = "lpje-fechar";
  bFechar.textContent = "Fechar";
  bFechar.onclick = fechar;
  const atalho = document.createElement("span");
  atalho.className = "lpje-atalho";
  atalho.textContent = "Ctrl+Enter";
  pe.append(bSalvar, bCancelar, bFechar, atalho);

  corpo.append(modelos, ta, lblPrazo, chips, inCustom, inData, info,
               lblQuem, quem, destinos, pe, status);

  const avisar = (msg, ruim) => {
    status.textContent = msg;
    status.classList.toggle("ruim", Boolean(ruim));
  };

  /* --- edição de nota existente (entra pela aba Lembretes) --- */

  let edicao = null;

  // Pré-seleciona o prazo nos chips. inData.value precisa vir ANTES do click():
  // o handler do chip "data" lê o campo na hora.
  const escolherPrazo = (iso) => {
    if (iso) {
      inData.value = iso;
      chips.querySelector('[data-v="data"]').click();
    } else {
      chips.querySelector('[data-v="0"]').click();
    }
  };

  function entrarEdicao(n) {
    edicao = n;
    ta.value = n.texto || "";
    escolherPrazo(n.data_lembrete || null);
    // Edição só muda texto e prazo — origem e destinos ficam como estavam.
    lblQuem.hidden = true;
    quem.hidden = true;
    destinos.hidden = true;
    bSalvar.textContent = "Salvar alterações";
    bCancelar.hidden = false;
    avisar(n.origem === "gab" ? "Editando nota do gabinete." : "Editando sua nota.");
    ativar("nota", false);
    ta.focus();
  }

  function sairEdicao() {
    edicao = null;
    ta.value = "";
    escolherPrazo(null);
    lblQuem.hidden = false;
    quem.hidden = false;
    destinos.hidden = alvo !== "gab";
    bSalvar.textContent = "Salvar nota";
    bCancelar.hidden = true;
    avisar("");
  }

  bCancelar.onclick = sairEdicao;

  async function salvar() {
    const texto = ta.value.trim();
    if (!texto) { avisar("Escreva o texto da nota.", true); ta.focus(); return; }

    if (edicao) {
      bSalvar.disabled = true;
      bSalvar.textContent = "Salvando…";
      const r = await pedirBg({
        tipo: "acaoNota", acao: "editar", origem: edicao.origem, id: edicao.id,
        campos: { texto, data_lembrete: calcISO() }
      });
      bSalvar.disabled = false;
      bSalvar.textContent = "Salvar alterações";
      if (r?.ok) {
        sairEdicao();
        atualizarContagem();
        ativar("lembretes", false);   // mostra a nota já atualizada na lista
      } else {
        avisar(r?.erro || "Não consegui salvar. Verifique a conexão.", true);
      }
      return;
    }

    const tokens = alvo === "gab"
      ? [...destinos.querySelectorAll("input:checked")].map((i) => i.value)
      : [];
    if (alvo === "gab" && !tokens.length) { avisar("Escolha ao menos um gabinete.", true); return; }

    bSalvar.disabled = true;
    bSalvar.textContent = "Salvando…";
    const r = await pedirBg({
      tipo: "criarNota",
      origem: alvo,
      dados: {
        cnj: numero,
        texto,
        data_lembrete: calcISO(),
        url,
        tokens
      }
    });
    bSalvar.disabled = false;
    bSalvar.textContent = "Salvar nota";

    if (r?.ok) {
      registrarTextoRecente(texto);
      atualizarContagem();
      fechar();
    } else {
      avisar(r?.erro || "Não consegui salvar. Verifique a conexão.", true);
    }
  }

  bSalvar.onclick = (ev) => { ev.preventDefault(); salvar(); };
  ta.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); salvar(); }
  });

  /* --- aba Lembretes: histórico do processo, com as mesmas ações do popup --- */

  const lemLista = document.createElement("div");
  lemLista.className = "lpje-lista";
  const lemStatus = document.createElement("p");
  lemStatus.className = "lpje-status";
  lemStatus.setAttribute("role", "status");
  lemStatus.setAttribute("aria-live", "polite");
  painelLem.append(lemLista, lemStatus);

  const avisarLem = (msg, ruim) => {
    lemStatus.textContent = msg || "";
    lemStatus.classList.toggle("ruim", Boolean(ruim));
  };

  // Cache local primeiro (pinta na hora); o Firestore atualiza em seguida.
  async function notasDoCache() {
    const dig = digitos;
    const notas = [];
    try {
      const { cachePessoal, cacheGabinete } =
        await api.storage.local.get(["cachePessoal", "cacheGabinete"]);
      for (const n of (cachePessoal?.notas || []))
        if ((n.cnj_digitos || "") === dig) notas.push({ ...n, origem: "ind" });
      for (const n of (cacheGabinete?.notas || []))
        if ((n.cnj_digitos || "") === dig) notas.push({ ...n, origem: "gab" });
    } catch (_) { /* sem storage: lista vem só do Firestore */ }
    return notas;
  }

  function renderLembretes(notas) {
    // Mesma ordem do popup: pendentes antes, depois pelo prazo mais próximo.
    const ordenadas = [...notas].sort((a, b) => {
      if (Boolean(a.concluido) !== Boolean(b.concluido)) return a.concluido ? 1 : -1;
      return (a.data_lembrete || "9999").localeCompare(b.data_lembrete || "9999");
    });
    lemLista.textContent = "";
    if (!ordenadas.length) {
      const p = document.createElement("p");
      p.className = "lpje-vazio";
      p.textContent = "Nenhuma nota neste processo ainda. Escreva a primeira na aba Anotação.";
      lemLista.appendChild(p);
      return;
    }
    for (const n of ordenadas) lemLista.appendChild(itemLembrete(n));
  }

  async function acaoNota(botao, msg, sucesso) {
    botao.disabled = true;
    const r = await pedirBg(msg);
    botao.disabled = false;
    if (r?.ok) {
      avisarLem(sucesso || "");
      atualizarContagem();
      await carregarLembretes();
    } else {
      avisarLem(r?.erro || "Sem conexão — a nota não foi atualizada.", true);
    }
  }

  function itemLembrete(n) {
    const div = document.createElement("div");
    div.className = "lpje-item"
      + (n.origem === "gab" ? " gab" : "")
      + (n.concluido ? " feito" : "")
      + (!n.concluido && venceu(n.data_lembrete) ? " venceu" : "");

    const marcar = document.createElement("button");
    marcar.type = "button";
    marcar.className = "lpje-marcar";
    marcar.title = n.concluido ? "Reabrir" : "Marcar como concluída";
    marcar.setAttribute("aria-label", marcar.title);
    const chk = document.createElement("input");
    chk.type = "checkbox";
    chk.checked = Boolean(n.concluido);
    chk.tabIndex = -1;
    chk.setAttribute("aria-hidden", "true");
    marcar.appendChild(chk);
    marcar.onclick = () => acaoNota(marcar, {
      tipo: "acaoNota", acao: "concluir", origem: n.origem, id: n.id,
      concluido: !n.concluido
    });

    const meio = document.createElement("div");
    meio.className = "lpje-meio";
    const texto = document.createElement("p");
    texto.className = "lpje-texto";
    texto.textContent = n.texto;
    const roda = document.createElement("p");
    roda.className = "lpje-roda";
    const etq = document.createElement("span");
    etq.className = "lpje-etq " + (n.origem === "gab" ? "gab" : "sua");
    etq.textContent = n.origem === "gab" ? "gabinete" : "privada";
    const t = document.createElement("time");
    t.textContent = n.data_lembrete
      ? `${dataCurta(n.data_lembrete)} · ${rotuloRelativo(n.data_lembrete)}`
      : "sem prazo";
    roda.append(etq, t);
    const detalhes = [];
    if (n.origem === "gab") detalhes.push(n.autor || "gabinete");
    if (n.concluido && n.concluido_por) detalhes.push(`concluída por ${n.concluido_por}`);
    if (detalhes.length) {
      const b = document.createElement("b");
      b.textContent = detalhes.join(" · ");
      roda.appendChild(b);
    }
    meio.append(texto, roda);

    const acoes = document.createElement("div");
    acoes.className = "lpje-acoes";

    const bEditar = document.createElement("button");
    bEditar.type = "button";
    bEditar.textContent = "✎";
    bEditar.title = "Editar";
    bEditar.setAttribute("aria-label", "Editar nota");
    bEditar.onclick = () => entrarEdicao(n);
    acoes.appendChild(bEditar);

    // Adiar só faz sentido enquanto está pendente.
    if (!n.concluido) {
      const bAdiar = document.createElement("button");
      bAdiar.type = "button";
      bAdiar.textContent = "⏭";
      bAdiar.title = "Adiar 7 dias úteis";
      bAdiar.setAttribute("aria-label", "Adiar 7 dias úteis");
      bAdiar.onclick = () => {
        // Já venceu (ou sem prazo) → conta de hoje; no prazo → conta do prazo atual.
        const base = (n.data_lembrete && !venceu(n.data_lembrete)) ? deISO(n.data_lembrete) : hoje();
        const novo = isoLocal(somarDiasUteis(base, 7));
        acaoNota(bAdiar, {
          tipo: "acaoNota", acao: "editar", origem: n.origem, id: n.id,
          campos: { data_lembrete: novo }
        }, `Adiada para ${dataLonga(novo)}.`);
      };
      acoes.appendChild(bAdiar);
    }

    const bApagar = document.createElement("button");
    bApagar.type = "button";
    bApagar.className = "lpje-apagar";
    bApagar.textContent = "×";
    bApagar.title = "Excluir";
    bApagar.setAttribute("aria-label", "Excluir nota");
    bApagar.onclick = () => {
      const alerta = n.origem === "gab"
        ? "Esta nota some para todos do gabinete. Não dá para desfazer."
        : "Esta nota será excluída. Não dá para desfazer.";
      if (!confirm(alerta)) return;
      acaoNota(bApagar, { tipo: "acaoNota", acao: "excluir", origem: n.origem, id: n.id });
    };
    acoes.appendChild(bApagar);

    div.append(marcar, meio, acoes);
    return div;
  }

  let lemCarregando = false;
  async function carregarLembretes() {
    if (lemCarregando) return;
    lemCarregando = true;
    renderLembretes(await notasDoCache());   // instantâneo, da última sincronização
    const r = await pedirBg({ tipo: "notasDoProcesso", dig: digitos });
    if (r?.ok) { renderLembretes(r.notas); avisarLem(""); }
    else avisarLem("Mostrando a última sincronização — sem conexão agora.", true);
    lemCarregando = false;
  }

  document.body.appendChild(dlg);
  dlgAberto = true;
  dlg.addEventListener("cancel", fechar);   // Esc
  dlg.addEventListener("close", fechar);
  dlg.showModal();
  ativar(abaInicial, abaInicial === "lembretes");
  if (abaInicial !== "lembretes") ta.focus();
}

// Radiogroup mínimo: marca um, desmarca os outros, setas circulam.
function ligarRadios(container, aoEscolher) {
  const itens = [...container.querySelectorAll('[role="radio"]')];
  const marcar = (a) => itens.forEach((i) => {
    const é = i === a;
    i.setAttribute("aria-checked", String(é));
    i.tabIndex = é ? 0 : -1;
  });
  marcar(itens.find((i) => i.getAttribute("aria-checked") === "true") || null);
  itens.forEach((item) => {
    item.onclick = () => { if (!item.disabled) { marcar(item); aoEscolher(item); } };
    item.onkeydown = (ev) => {
      const passo = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[ev.key];
      if (!passo) return;
      ev.preventDefault();
      const livres = itens.filter((i) => !i.disabled);
      const prox = livres[(livres.indexOf(item) + passo + livres.length) % livres.length];
      marcar(prox); prox.focus(); aoEscolher(prox);
    };
  });
}

/* ---------- contagem nos selos ---------- */

// "AAAA-MM-DD" de hoje no fuso local (para saber o que já venceu).
function hojeISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function pintarAviso(elemento, c, rotulo) {
  if (!elemento) return;
  if (!c.total) { elemento.style.display = "none"; elemento.title = ""; return; }
  elemento.style.display = "inline-flex";
  elemento.querySelector(".lpje-num").textContent = String(c.pend > 0 ? c.pend : c.total);
  elemento.classList.toggle("venceu", c.venc > 0);
  const descricao = `${c.total} nota(s) ${rotulo} neste processo`
    + (c.pend > 0 ? ` · ${c.pend} pendente(s)` : " · todas concluídas")
    + (c.venc > 0 ? ` · ${c.venc} vencida(s)` : "");
  elemento.title = descricao + " — clique para ver os lembretes deste processo";
  elemento.setAttribute("aria-label", descricao + ", ver lembretes deste processo");
}

async function atualizarContagem() {
  const dig = processoDigitos;
  const barra = document.getElementById("lpje-barra");
  if (!dig || !barra) return;

  const hoje = hojeISO();
  const priv = { total: 0, pend: 0, venc: 0 };
  const gab = { total: 0, pend: 0, venc: 0 };
  const somar = (alvo, n) => {
    alvo.total++;
    if (n && !n.concluido) {
      alvo.pend++;
      if (n.data_lembrete && n.data_lembrete < hoje) alvo.venc++;
    }
  };

  // Pessoais: cache do service worker (Firestore, usuarios/{uid}/notas).
  try {
    const { cachePessoal } = await api.storage.local.get("cachePessoal");
    for (const n of (cachePessoal?.notas || [])) {
      if ((n.cnj_digitos || "") === dig) somar(priv, n);
    }
  } catch (_) { /* ignora */ }

  // Pessoais legadas, ainda em storage.sync e não migradas.
  try {
    const sync = await api.storage.sync.get(null);
    for (const [k, v] of Object.entries(sync)) {
      if (k === "nota:" + dig || k.startsWith("nota:" + dig + ":")) somar(priv, v);
    }
  } catch (_) { /* sem storage: ignora */ }

  // Gabinete: cache do service worker (coleção `lembretes`).
  try {
    const { cacheGabinete } = await api.storage.local.get("cacheGabinete");
    for (const n of (cacheGabinete?.notas || [])) {
      if ((n.cnj_digitos || "") === dig) somar(gab, n);
    }
  } catch (_) { /* ignora */ }

  pintarAviso(barra.querySelector(".lpje-aviso.priv"), priv, "pessoal(is)");
  pintarAviso(barra.querySelector(".lpje-aviso.gab"), gab, "do gabinete");

  // Espelha as pendências no badge do ícone da extensão.
  if (!EM_FRAME) enviarBg({ tipo: "definirBadge", pend: priv.pend + gab.pend });

  if (processoUrl && (priv.total || gab.total)) {
    enviarBg({ tipo: "corrigirLinks", dig, url: processoUrl });
  }
}

/* =========================================================================
   Selos nas listas de processos (painel de tarefas, etiquetas). Cada cartão
   <processo-datalist-card> ganha um sino com a contagem de notas DAQUELE
   processo — dá para saber quem tem anotação sem abrir processo por processo.
   - verde: há nota pendente e nenhuma passou do prazo (ou é sem prazo);
   - vermelho: ao menos uma nota pendente passou do prazo;
   - cinza: só notas concluídas.
   Sem nota nenhuma, o selo fica oculto. Clicar abre o diálogo na aba
   Lembretes daquele processo (não do "processo da página").
   ========================================================================= */

// Uma leitura do storage por varredura, não uma por cartão:
// Map dígitos do CNJ → {total, pend, venc}. Mesmas fontes de atualizarContagem().
async function contagemPorProcesso() {
  const hoje = hojeISO();
  const mapa = new Map();
  const somar = (dig, n, origem) => {
    if (!dig) return;
    const c = mapa.get(dig) || { total: 0, pend: 0, venc: 0, gab: 0, notas: [] };
    c.total++;
    c.notas.push({ ...n, origem });
    if (n && !n.concluido) {
      c.pend++;
      if (n.data_lembrete && n.data_lembrete < hoje) c.venc++;
      if (origem === "gab") c.gab++;
    }
    mapa.set(dig, c);
  };

  try {
    const { cachePessoal, cacheGabinete } =
      await api.storage.local.get(["cachePessoal", "cacheGabinete"]);
    for (const n of (cachePessoal?.notas || [])) somar(n.cnj_digitos || "", n, "ind");
    for (const n of (cacheGabinete?.notas || [])) somar(n.cnj_digitos || "", n, "gab");
  } catch (_) { /* storage indisponível */ }

  // Pessoais legadas, ainda em storage.sync: chave "nota:<dígitos>[:sufixo]".
  try {
    const sync = await api.storage.sync.get(null);
    for (const [k, v] of Object.entries(sync)) {
      const m = /^nota:(\d{20})(?::|$)/.exec(k);
      if (m) somar(m[1], v || {}, "ind");
    }
  } catch (_) { /* sem storage.sync: ignora */ }

  return mapa;
}

function numeroDoCartao(cartao) {
  const alvo = cartao.querySelector(".tarefa-numero-processo");
  return alvo?.textContent.match(CNJ)?.[0] || cartao.textContent.match(CNJ)?.[0] || null;
}

function criarSeloLista() {
  const selo = document.createElement("button");
  selo.type = "button";
  selo.className = "lpje-selo-lista";
  selo.style.display = "none";
  // Mesmo sino do topo do PJe (desenho próprio, sem depender do font-awesome).
  selo.innerHTML =
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a2 2 0 0 0-2 2v.34C7.06 5.16 5 7.83 5 11v4l-1.7 2.55A1 1 0 0 0 4.13 19h15.74a1 1 0 0 0 .83-1.45L19 15v-4c0-3.17-2.06-5.84-5-6.66V4a2 2 0 0 0-2-2Zm0 20a3 3 0 0 0 2.82-2H9.18A3 3 0 0 0 12 22Z"/></svg>'
    + '<span class="lpje-num"></span>';
  // O cartão inteiro seleciona/abre o processo ao clicar; nada daqui sobe.
  for (const evento of ["mousedown", "mouseup", "dblclick"]) {
    selo.addEventListener(evento, (ev) => ev.stopPropagation());
  }
  selo.addEventListener("click", (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    const numero = selo.dataset.numero;
    if (!numero) return;
    esconderPrevia();
    // Sem URL: o cartão não expõe o link do processo. O service worker corrige
    // o link da nota quando o processo for aberto (corrigirLinks).
    abrirCompositor("lembretes", { numero, digitos: numero.replace(/\D/g, ""), url: null });
  });
  selo.addEventListener("mouseenter", () => mostrarPreviaSelo(selo));
  selo.addEventListener("focus", () => mostrarPreviaSelo(selo));
  selo.addEventListener("mouseleave", esconderPrevia);
  selo.addEventListener("blur", esconderPrevia);
  return selo;
}

function pintarSeloLista(selo, numero, c) {
  selo.dataset.numero = numero;
  if (!c || !c.total) {
    selo.style.display = "none";
    selo.title = "";
    selo.removeAttribute("aria-label");
    return;
  }
  const estado = c.venc > 0 ? "venceu" : c.pend > 0 ? "ok" : "feito";
  selo.classList.remove("ok", "venceu", "feito");
  selo.classList.add(estado);
  selo.style.display = "inline-flex";

  const gab = selo.querySelector(".lpje-gab");
  if (c.gab > 0 && !gab) {
    const g = document.createElement("span");
    g.className = "lpje-gab";
    g.textContent = "👥";
    g.setAttribute("aria-hidden", "true");
    selo.appendChild(g);
  } else if (!c.gab && gab) {
    gab.remove();
  }

  // Só escreve se mudou: trocar o texto gera mutação, que reagenda atualizar(),
  // que voltaria aqui — um laço eterno a cada 250 ms.
  const num = selo.querySelector(".lpje-num");
  const texto = String(c.pend > 0 ? c.pend : c.total);
  if (num.textContent !== texto) num.textContent = texto;

  const descricao = `${c.total} nota(s) no processo ${numero}`
    + (c.pend > 0 ? ` · ${c.pend} pendente(s)` : " · todas concluídas")
    + (c.venc > 0 ? ` · ${c.venc} passou(aram) do prazo` : "")
    + (c.gab > 0 ? " · há nota do gabinete" : "");
  selo.title = descricao + " — clique para ver os lembretes";
  selo.setAttribute("aria-label", descricao + ", ver lembretes deste processo");
}

/* ---------- prévia ao passar o mouse no selo ---------- */

let contagemAtual = new Map();

function esconderPrevia() {
  document.getElementById("lpje-previa")?.remove();
}

function mostrarPreviaSelo(selo) {
  const c = contagemAtual.get((selo.dataset.numero || "").replace(/\D/g, ""));
  if (!c || !c.total) return;
  esconderPrevia();

  const pendentes = c.notas.filter((n) => !n.concluido)
    .sort((a, b) => (a.data_lembrete || "9999").localeCompare(b.data_lembrete || "9999"));
  const lista = pendentes.length ? pendentes : c.notas;

  const box = document.createElement("div");
  box.id = "lpje-previa";
  box.setAttribute("role", "tooltip");
  for (const n of lista.slice(0, 4)) {
    const item = document.createElement("div");
    item.className = "lpje-pv" + (!n.concluido && venceu(n.data_lembrete) ? " venceu" : "");
    const p = document.createElement("p");
    p.className = "lpje-pv-texto";
    const t = String(n.texto || "");
    p.textContent = t.length > 160 ? t.slice(0, 158) + "…" : t;
    const meta = document.createElement("p");
    meta.className = "lpje-pv-meta";
    const etq = document.createElement("span");
    etq.className = "lpje-etq " + (n.origem === "gab" ? "gab" : "sua");
    etq.textContent = n.origem === "gab" ? "gabinete" : "privada";
    const tm = document.createElement("time");
    tm.textContent = n.concluido ? "concluída"
      : n.data_lembrete ? `${dataCurta(n.data_lembrete)} · ${rotuloRelativo(n.data_lembrete)}`
      : "sem prazo";
    meta.append(etq, tm);
    if (n.origem === "gab" && n.autor) {
      const b = document.createElement("b");
      b.textContent = n.autor;
      meta.appendChild(b);
    }
    item.append(p, meta);
    box.appendChild(item);
  }
  if (lista.length > 4) {
    const m = document.createElement("p");
    m.className = "lpje-pv-mais";
    m.textContent = `+${lista.length - 4} — clique no selo para ver todas`;
    box.appendChild(m);
  }
  document.body.appendChild(box);

  const r = selo.getBoundingClientRect();
  let left = Math.max(8, r.right - box.offsetWidth);
  let top = r.bottom + 6;
  if (top + box.offsetHeight > window.innerHeight - 8) top = r.top - box.offsetHeight - 6;
  box.style.left = left + "px";
  box.style.top = Math.max(8, top) + "px";
}

window.addEventListener("scroll", esconderPrevia, true);

/* ---------- filtro por nota no topo da lista ---------- */

const FILTROS_LISTA = [
  { f: "todas", rotulo: "Todas" },
  { f: "com",   rotulo: "Com nota" },
  { f: "venc",  rotulo: "Vencidas" },
  { f: "sem",   rotulo: "Sem nota" }
];
let filtroLista = "todas";
try { filtroLista = sessionStorage.getItem("lpje-filtro") || "todas"; } catch (_) { /* sem sessionStorage */ }

function garantirFiltroLista() {
  if (document.getElementById("lpje-filtro-lista")) return;
  const linha = document.querySelector("#acoes-processos-selecionados .vcenter")
             || document.querySelector(".barra-selecao-processos");
  const datalist = document.querySelector("p-datalist");
  if (!linha && !datalist) return;

  injetarEstilo();
  const box = document.createElement("div");
  box.id = "lpje-filtro-lista";
  box.setAttribute("role", "radiogroup");
  box.setAttribute("aria-label", "Filtrar processos pelas notas do Lembretes PJe");
  const rot = document.createElement("span");
  rot.className = "lpje-rotulo";
  rot.textContent = "Notas:";
  box.appendChild(rot);
  for (const { f, rotulo } of FILTROS_LISTA) {
    const b = document.createElement("button");
    b.type = "button";
    b.dataset.f = f;
    b.textContent = rotulo;
    b.setAttribute("role", "radio");
    b.setAttribute("aria-checked", String(f === filtroLista));
    b.addEventListener("click", (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      filtroLista = f;
      try { sessionStorage.setItem("lpje-filtro", f); } catch (_) { /* sem sessionStorage */ }
      box.querySelectorAll("button").forEach((x) => x.setAttribute("aria-checked", String(x === b)));
      aplicarFiltroLista();
    });
    box.appendChild(b);
  }
  const oc = document.createElement("span");
  oc.className = "lpje-ocultos";
  box.appendChild(oc);

  if (linha) linha.appendChild(box);
  else datalist.parentElement.insertBefore(box, datalist);
}

function estadoDoCartao(cartao) {
  const selo = cartao.querySelector(".lpje-selo-lista");
  if (!selo || selo.style.display === "none") return "sem";
  return selo.classList.contains("venceu") ? "venc" : "com";
}

function aplicarFiltroLista() {
  let ocultos = 0;
  for (const cartao of document.querySelectorAll(SELETOR_CARTAO)) {
    const e = estadoDoCartao(cartao);
    const mostra = filtroLista === "todas"
      || (filtroLista === "sem" && e === "sem")
      || (filtroLista === "com" && e !== "sem")
      || (filtroLista === "venc" && e === "venc");
    (cartao.closest("li") || cartao).style.display = mostra ? "" : "none";
    if (!mostra) ocultos++;
  }
  const oc = document.querySelector("#lpje-filtro-lista .lpje-ocultos");
  if (!oc) return;
  const txt = ocultos ? `${ocultos} oculto${ocultos === 1 ? "" : "s"}` : "";
  if (oc.textContent !== txt) oc.textContent = txt;
}

// Idempotente: pinta só os cartões novos ou cujo processo mudou (o Angular
// reaproveita cartões ao paginar). `forcar` repinta todos — usado quando o
// cache de notas muda (nota criada, concluída, removida, sincronizada).
let selosAtualizando = false;
let selosPendente = false;
async function atualizarSelosLista(forcar = false) {
  const cartoes = document.querySelectorAll(SELETOR_CARTAO);
  if (!cartoes.length) return;
  garantirFiltroLista();

  const alvos = [];
  for (const cartao of cartoes) {
    const numero = numeroDoCartao(cartao);
    const selo = cartao.querySelector(".lpje-selo-lista");
    if (!numero) { selo?.remove(); continue; }
    if (!forcar && selo && selo.dataset.numero === numero) continue;
    alvos.push({ cartao, numero });
  }
  if (!alvos.length) { aplicarFiltroLista(); return; }

  if (selosAtualizando) { selosPendente = true; return; }
  selosAtualizando = true;
  try {
    const mapa = await contagemPorProcesso();
    contagemAtual = mapa;
    for (const { cartao, numero } of alvos) {
      let selo = cartao.querySelector(".lpje-selo-lista");
      if (!selo) {
        // Mesma faixa dos ícones à direita (lembretes do PJe, autos, datas).
        const ponto = cartao.querySelector(".icons-right");
        if (!ponto) continue;
        injetarEstilo();
        selo = criarSeloLista();
        ponto.prepend(selo);
      }
      pintarSeloLista(selo, numero, mapa.get(numero.replace(/\D/g, "")));
    }
    aplicarFiltroLista();
  } finally {
    selosAtualizando = false;
    if (selosPendente) { selosPendente = false; atualizarSelosLista(true); }
  }
}

/* ---------- observação da página (PJe navega por AJAX) ---------- */

let ultimo = null;
let processoNumero = null;
let processoDigitos = null;
let processoUrl = null;

function atualizar() {
  garantirSino();          // independe de processo aberto: vale para toda página do PJe
  atualizarSelosLista();   // listas de processos (tarefas/etiquetas): um selo por cartão

  const numero = extrairNumero();
  const mudou = numero !== processoNumero;

  if (mudou) {
    processoNumero = numero;
    processoDigitos = numero ? numero.replace(/\D/g, "") : null;
    processoUrl = null;
    // Processo mudou: força reinjeção/recontagem.
    document.getElementById("lpje-barra")?.remove();
  }

  if (!numero) {
    document.getElementById("lpje-barra")?.remove();
    if (!EM_FRAME) enviarBg({ tipo: "definirBadge", pend: 0 });   // sem processo: limpa o badge
    return;
  }

  const tinhaUrl = Boolean(processoUrl);
  capturarUrl();
  if (mudou || (!tinhaUrl && processoUrl)) {
    const ctx = extrairContexto();
    if (ctx && !EM_FRAME) { ultimo = ctx; api.storage.local.set({ processoAtual: ctx }); }
  }

  garantirControles();
}

atualizar();

// O PJe navega por AJAX e dispara rajadas de mutações; coalescemos as reações
// num único atualizar() por rajada, para não varrer o DOM a cada mudança.
let atualizacaoAgendada = null;
function agendarAtualizacao() {
  if (atualizacaoAgendada) return;
  atualizacaoAgendada = setTimeout(() => {
    atualizacaoAgendada = null;
    atualizar();
  }, 250);
}

// characterData: o Angular reaproveita cartões da lista ao paginar e só troca o
// texto do número — sem isso o selo ficaria com o processo antigo.
const observer = new MutationObserver(agendarAtualizacao);
observer.observe(document.body, { childList: true, subtree: true, characterData: true });

// Quando uma nota é criada/concluída/removida (aqui ou noutra aba), recontar.
api.storage.onChanged.addListener((changes, area) => {
  if (area === "sync"
      || (area === "local" && (changes.cachePessoal || changes.cacheGabinete || changes.sessao))) {
    atualizarContagem();
    atualizarSino();
    atualizarSelosLista(true);
  }
});

// Com a aba do PJe em foco, pede uma sincronização mais frequente: o ciclo de
// 6 h do service worker fazia a contagem mentir por horas quando um colega
// anotava no mesmo processo.
function pedirSyncSeVisivel() {
  if (document.visibilityState === "visible" && processoDigitos) {
    enviarBg({ tipo: "sincronizarSePreciso" });
  }
}
document.addEventListener("visibilitychange", pedirSyncSeVisivel);
setInterval(pedirSyncSeVisivel, 5 * 60 * 1000);
pedirSyncSeVisivel();

api.runtime.onMessage.addListener((msg, _sender, responder) => {
  if (msg?.tipo === "pedirProcesso") {
    responder(extrairContexto());   // resposta síncrona
  }
  if (msg?.tipo === "tocarSom") tocarSom();
  return false;                     // nada assíncrono aqui: não segura o canal aberto
});
