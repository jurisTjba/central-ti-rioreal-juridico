/* =========================================================================
   popup.js
   - Aba Processo:  UM compositor (privada ou gabinete, escolhido em "Quem vê")
                    sempre acima de UMA lista com as notas do processo.
   - Aba Lembretes: todas as notas, com busca e filtro Pendentes/Concluídas/Todas.
   - Aba Conta:     login (auth.js), nome do perfil e atalho aos gabinetes.
   Toda renderização de texto vindo de usuário usa textContent — nunca
   innerHTML — para impedir injeção de HTML nas notas compartilhadas.
   ========================================================================= */

// SEGMENTOS, el() e os utilitários de data/CNJ vêm de comum.js.

let processo = null;     // contexto vindo do content script
let urlDaAba = null;
let config = {};         // { nome, token } — legado do storage.sync (migração)
let sessao = null;       // sessão do Firebase Auth (auth.js) ou null se deslogado
let perfil = null;       // { nome, grupos: [{ token, nome }] } — vem da conta
let filtroAtual = "pendentes";
let termoBusca = "";
let edicao = null;       // nota em edição no compositor, ou null (modo criar)
let modoConta = "entrar";

const nomeAutor = () => String(perfil?.nome || "").trim();
const gruposDoPerfil = () => (perfil?.grupos || []).filter((g) => g && g.token);
const tokensDosGrupos = () => gruposDoPerfil().map((g) => g.token);

function enviarBg(msg) {
  try { api.runtime.sendMessage(msg); } catch (_) { /* SW reiniciando */ }
}

/* ---------- feedback ----------
   Erro NÃO some sozinho: quem lê devagar ou foi interrompido perderia a única
   explicação do que deu errado. Sucesso some em 4s, mas só se ainda for a
   mensagem que este timer escreveu — senão o timer antigo apagaria a nova. */

function mostrarStatus(id, msg, ruim = false) {
  const alvo = el(id);
  alvo.textContent = msg;
  alvo.classList.toggle("ruim", ruim);
  if (msg && !ruim) {
    setTimeout(() => {
      if (alvo.textContent === msg) { alvo.textContent = ""; alvo.classList.remove("ruim"); }
    }, 4000);
  }
}

function esqueleto(alvo, linhas = 3) {
  alvo.textContent = "";
  const d = document.createElement("div");
  d.className = "esqueleto";
  for (let i = 0; i < linhas; i++) d.appendChild(document.createElement("div"));
  alvo.appendChild(d);
}

function vazio(alvo, texto) {
  alvo.textContent = "";
  const p = document.createElement("p");
  p.className = "vazio";
  p.textContent = texto;
  alvo.appendChild(p);
}

/* ---------- diálogo de confirmação ----------
   <dialog> nativo: prende o foco, fecha no Esc e é anunciado como modal — o
   confirm() do navegador rouba o foco do popup e às Vezes o fecha. */
function confirmar(texto, rotuloOk = "Excluir") {
  const dlg = el("dlgConfirma");
  el("dlgTexto").textContent = texto;
  el("dlgConfirmar").textContent = rotuloOk;
  dlg.showModal();
  return new Promise((resolve) => {
    const fim = (valor) => {
      el("dlgConfirmar").onclick = null;
      el("dlgCancelar").onclick = null;
      dlg.oncancel = null;
      dlg.onclose = null;
      if (dlg.open) dlg.close();
      resolve(valor);
    };
    el("dlgConfirmar").onclick = () => fim(true);
    el("dlgCancelar").onclick = () => fim(false);
    // `cancel` é o Esc. `close` fica como reserva: nem todo motor dispara os
    // dois, e sem um deles a promessa ficaria pendurada para sempre.
    dlg.oncancel = () => fim(false);
    dlg.onclose = () => fim(false);
  });
}

/* ---------- radiogroup acessível ----------
   Setas circulam entre as opções e só a opção marcada fica no tab order
   (roving tabindex) — o padrão ARIA para grupo de escolha única. */
function ligarRadiogroup(container, aoEscolher) {
  const itens = [...container.querySelectorAll('[role="radio"]')];
  const marcar = (alvo) => {
    itens.forEach((i) => {
      const é = i === alvo;
      i.setAttribute("aria-checked", String(é));
      i.tabIndex = é ? 0 : -1;
    });
  };
  const atual = () => itens.find((i) => i.getAttribute("aria-checked") === "true") || itens[0];
  marcar(atual());

  itens.forEach((item) => {
    item.onclick = () => { if (!item.disabled) { marcar(item); aoEscolher(item); } };
    item.onkeydown = (ev) => {
      const passo = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[ev.key];
      if (!passo) return;
      ev.preventDefault();
      const livres = itens.filter((i) => !i.disabled);
      const i = livres.indexOf(item);
      const prox = livres[(i + passo + livres.length) % livres.length];
      marcar(prox); prox.focus(); aoEscolher(prox);
    };
  });
  return { marcar, itens };
}

/* ---------- seletor de prazo em dias úteis ----------
   5 / 10 / 15 dias úteis (os prazos processuais que de fato ocorrem), "outro"
   (nº livre), "data" (calendário) ou "sem". Grava sempre uma data absoluta
   "AAAA-MM-DD" em data_lembrete. Ao editar, começa em "manter": se o usuário
   não tocar no prazo, preserva o que já estava lá.                         */
function criarSeletorPrazo(raiz) {
  const grupo = raiz.querySelector(".chips");
  const inCustom = raiz.querySelector(".dias-custom");
  const inData = raiz.querySelector(".data-exata");
  const info = raiz.querySelector(".prazo-info");
  let estado = { modo: "manter", dias: null, dataISO: null, anteriorISO: null };

  function calcISO() {
    if (estado.modo === "manter") return estado.anteriorISO || null;
    if (estado.modo === "sem") return null;
    if (estado.modo === "data") return estado.dataISO || null;
    if (estado.modo === "dias") {
      if (!estado.dias || estado.dias < 1) return null;
      return isoLocal(somarDiasUteis(hoje(), estado.dias));
    }
    return null;
  }

  function pintarInfo() {
    const iso = calcISO();
    if (estado.modo === "manter") {
      info.textContent = iso ? `prazo atual: ${dataLonga(iso)}` : "sem prazo — escolha (opcional)";
    } else if (estado.modo === "sem") {
      info.textContent = "sem prazo — só nota";
    } else if (!iso) {
      info.textContent = estado.modo === "dias" ? "informe os dias úteis" : "escolha uma data";
    } else if (estado.modo === "dias") {
      info.textContent = "";
      const b = document.createElement("b");
      b.textContent = dataLonga(iso);
      info.append("vence ", b, ` · ${estado.dias} dias úteis`);
    } else {
      info.textContent = "";
      const b = document.createElement("b");
      b.textContent = dataLonga(iso);
      info.append("vence ", b);
    }
  }

  const grupoCtl = ligarRadiogroup(grupo, (btn) => {
    const v = btn.dataset.dias;
    inCustom.hidden = v !== "custom";
    inData.hidden = v !== "data";
    if (v === "custom") { estado = { modo: "dias", dias: Number(inCustom.value) || null }; inCustom.focus(); }
    else if (v === "data") { estado = { modo: "data", dataISO: inData.value || null }; }
    else if (v === "0") { estado = { modo: "sem" }; }
    else { estado = { modo: "dias", dias: Number(v) }; }
    pintarInfo();
  });

  inCustom.oninput = () => { estado = { modo: "dias", dias: Number(inCustom.value) || null }; pintarInfo(); };
  inData.onchange = () => { estado = { modo: "data", dataISO: inData.value || null }; pintarInfo(); };

  return {
    valorISO: () => calcISO(),
    reset: (anteriorISO) => {
      estado = { modo: "manter", dias: null, dataISO: null, anteriorISO: anteriorISO || null };
      grupoCtl.itens.forEach((c) => { c.setAttribute("aria-checked", "false"); c.tabIndex = -1; });
      if (grupoCtl.itens[0]) grupoCtl.itens[0].tabIndex = 0;
      inCustom.hidden = true; inData.hidden = true;
      inCustom.value = ""; inData.value = anteriorISO || "";
      pintarInfo();
    }
  };
}

const seletorPrazo = criarSeletorPrazo(el("prazoNota"));

/* ---------- abas ---------- */

const ABAS = ["processo", "lembretes", "conta"];

function trocarAba(nome) {
  document.querySelectorAll("nav [role=tab]").forEach((b) => {
    const é = b.dataset.aba === nome;
    b.setAttribute("aria-selected", String(é));
    b.tabIndex = é ? 0 : -1;
  });
  for (const aba of ABAS) el("aba-" + aba).hidden = aba !== nome;
  if (nome === "lembretes") montarListaGeral();
}

document.querySelectorAll("nav [role=tab]").forEach((b) => {
  b.onclick = () => trocarAba(b.dataset.aba);
  // Setas navegam entre abas e levam o foco junto (padrão ARIA de tablist).
  b.onkeydown = (ev) => {
    const passo = { ArrowRight: 1, ArrowLeft: -1 }[ev.key];
    if (!passo) return;
    ev.preventDefault();
    const tabs = [...document.querySelectorAll("nav [role=tab]")];
    const prox = tabs[(tabs.indexOf(b) + passo + tabs.length) % tabs.length];
    trocarAba(prox.dataset.aba);
    prox.focus();
  };
});

el("abrirPainel").onclick = () => api.runtime.openOptionsPage();

/* ---------- cabeçalho do processo (CNJ decomposto) ---------- */

function pintarCnj(numero) {
  const { seq, dv, ano, j, tr, origem } = decompor(numero);
  const partes = [
    [seq, "sequencial"], ["-", null], [dv, "dv"], [".", null],
    [ano, "ano"], [".", null], [j, "segmento"], [".", null],
    [tr, "tribunal"], [".", null], [origem, "origem"]
  ];
  const alvo = el("cnj");
  alvo.textContent = "";
  for (const [txt, rot] of partes) {
    const div = document.createElement("div");
    if (!rot) {
      div.className = "sep";
      div.textContent = txt;
    } else {
      const p = document.createElement("span");
      p.className = "parte";
      p.textContent = txt;
      const r = document.createElement("span");
      r.className = "rot";
      r.textContent = rot;
      div.append(p, r);
    }
    alvo.appendChild(div);
  }
}

function pintarMeta() {
  const j = Number(decompor(processo.numero).j);
  el("meta").textContent = [SEGMENTOS[j], processo.classe, processo.orgao]
    .filter(Boolean).join(" · ");
  el("segredo").hidden = !processo.segredo;
}

const digitos = () => processo.numero.replace(/\D/g, "");

/* ---------- compositor: "Quem vê" ---------- */

let quemVe = "ind";

function renderDestinos() {
  const alvo = el("gabDestinos");
  alvo.textContent = "";
  const grupos = gruposDoPerfil();
  const unico = grupos.length === 1;
  for (const g of grupos) {
    const lab = document.createElement("label");
    const chk = document.createElement("input");
    chk.type = "checkbox";
    chk.value = g.token;
    chk.checked = unico;                       // com um só gabinete, já vem marcado
    chk.onchange = () => lab.classList.toggle("marcado", chk.checked);
    const txt = document.createElement("span");
    txt.textContent = g.nome || "gabinete";
    lab.classList.toggle("marcado", chk.checked);
    lab.append(chk, txt);
    alvo.appendChild(lab);
  }
}

const destinosSelecionados = () =>
  [...el("gabDestinos").querySelectorAll("input:checked")].map((i) => i.value);

// Estado visual do bloco "Quem vê" conforme perfil e modo (criar/editar).
function atualizarQuemVe() {
  const temGrupos = gruposDoPerfil().length > 0;
  const btnGab = el("quemVe").querySelector('[data-quem="gab"]');
  const btnInd = el("quemVe").querySelector('[data-quem="ind"]');

  // Editando: a origem da nota não muda (as regras proíbem trocar os tokens
  // de uma nota de gabinete depois de criada).
  const editando = Boolean(edicao);
  btnGab.disabled = editando || !temGrupos;
  btnInd.disabled = editando;

  el("semGabinete").hidden = temGrupos || editando;
  el("gabDestinos").hidden = quemVe !== "gab" || editando;
  el("quemVe").hidden = editando;
  el("lblQuemVe").hidden = editando;
}

const ctlQuemVe = ligarRadiogroup(el("quemVe"), (btn) => {
  quemVe = btn.dataset.quem;
  atualizarQuemVe();
});

/* ---------- lista do processo (privadas + gabinete, unificadas) ---------- */

// Rótulo curto de quantas notas há, para o cabeçalho da lista.
function pintarTituloLista(n) {
  el("tituloLista").textContent = n ? `Neste processo (${n})` : "Neste processo";
}

function itemDeNota(n, { aoAtualizar, comCnj = false }) {
  const div = document.createElement("div");
  div.className = "item"
    + (n.origem === "gab" ? " gab" : "")
    + (n.concluido ? " feito" : "")
    + (!n.concluido && venceu(n.data_lembrete) ? " venceu" : "");

  // Botão de 24px envolvendo o checkbox: alvo acessível sem checkbox gigante.
  const marcar = document.createElement("button");
  marcar.type = "button";
  marcar.className = "marcar";
  marcar.title = n.concluido ? "Reabrir" : "Marcar como concluída";
  marcar.setAttribute("aria-label", marcar.title);
  const chk = document.createElement("input");
  chk.type = "checkbox";
  chk.checked = Boolean(n.concluido);
  chk.tabIndex = -1;
  chk.setAttribute("aria-hidden", "true");
  marcar.appendChild(chk);
  marcar.onclick = async () => {
    marcar.disabled = true;
    try { await concluir(n, !n.concluido, aoAtualizar); } finally { marcar.disabled = false; }
  };

  const corpo = document.createElement("div");
  corpo.className = "corpo";

  const texto = document.createElement("p");
  texto.className = "texto";
  texto.textContent = n.texto;

  const roda = document.createElement("p");
  roda.className = "rodainha";

  const tag = document.createElement("span");
  tag.className = "tag " + (n.origem === "gab" ? "gab" : "sua");
  tag.textContent = n.origem === "gab" ? "gabinete" : "privada";
  roda.appendChild(tag);

  const t = document.createElement("time");
  t.textContent = n.data_lembrete ? `${dataCurta(n.data_lembrete)} · ${rotuloRelativo(n.data_lembrete)}` : "sem prazo";
  roda.appendChild(t);

  if (comCnj && n.cnj) {
    const linkCnj = linkUtil(n.url);
    const cnjBtn = document.createElement("button");
    cnjBtn.type = "button";
    cnjBtn.className = "cnj-link";
    cnjBtn.textContent = n.cnj;
    cnjBtn.title = linkCnj ? "Abrir o processo no PJe" : "Copiar o número do processo";
    cnjBtn.onclick = async () => {
      if (linkCnj) { api.tabs.create({ url: linkCnj }); return; }
      try {
        await navigator.clipboard.writeText(n.cnj);
        mostrarStatus(avisoDaAba(), "Número copiado.");
      } catch {
        mostrarStatus(avisoDaAba(), "Não consegui copiar o número.", true);
      }
    };
    roda.appendChild(cnjBtn);
  }

  const detalhes = [];
  if (n.origem === "gab") detalhes.push(n.autor || "gabinete");
  if (n.concluido && n.concluido_por) detalhes.push(`concluída por ${n.concluido_por}`);
  if (detalhes.length) {
    const b = document.createElement("b");
    b.textContent = detalhes.join(" · ");
    roda.appendChild(b);
  }

  const link = linkUtil(n.url);
  if (link) {
    const btn = document.createElement("button");
    btn.className = "abrir";
    btn.type = "button";
    btn.title = "Abrir o processo no PJe";
    btn.onclick = () => api.tabs.create({ url: link });
    btn.append(texto);
    corpo.append(btn, roda);
  } else {
    corpo.append(texto, roda);
  }

  const acoes = document.createElement("div");
  acoes.className = "acoes";

  const bEditar = document.createElement("button");
  bEditar.type = "button";
  bEditar.textContent = "✎";
  bEditar.title = "Editar";
  bEditar.setAttribute("aria-label", "Editar nota");
  bEditar.onclick = () => abrirEdicao(n);
  acoes.appendChild(bEditar);

  // Adiar só faz sentido enquanto está pendente.
  if (!n.concluido) {
    const bAdiar = document.createElement("button");
    bAdiar.type = "button";
    bAdiar.textContent = "⏭";
    bAdiar.title = "Adiar 7 dias úteis";
    bAdiar.setAttribute("aria-label", "Adiar 7 dias úteis");
    bAdiar.onclick = async () => {
      bAdiar.disabled = true;
      try { await adiar(n, 7, aoAtualizar); } finally { bAdiar.disabled = false; }
    };
    acoes.appendChild(bAdiar);
  }

  const bApagar = document.createElement("button");
  bApagar.type = "button";
  bApagar.className = "apagar";
  bApagar.textContent = "×";
  bApagar.title = "Excluir";
  bApagar.setAttribute("aria-label", "Excluir nota");
  bApagar.onclick = () => apagar(n, aoAtualizar);
  acoes.appendChild(bApagar);

  div.append(marcar, corpo, acoes);
  return div;
}

async function carregarListaProcesso() {
  const lista = el("listaProcesso");
  const compositor = el("compositor");

  if (!sessao) {
    el("precisaLogin").hidden = false;
    el("formNota").hidden = true;
    compositor.classList.remove("editando");
    vazio(lista, "Entre na sua conta para ver e criar notas deste processo.");
    pintarTituloLista(0);
    return;
  }

  el("precisaLogin").hidden = true;
  el("formNota").hidden = false;
  atualizarQuemVe();

  esqueleto(lista);

  const dig = digitos();
  let minhas = [], doGab = [];
  let falhou = false;

  try {
    minhas = (await fsNotasPessoaisDoProcesso(sessao.uid, dig))
      .map((n) => ({ ...n, origem: "ind" }));
  } catch { falhou = true; }

  if (tokensDosGrupos().length) {
    try {
      doGab = (await fsNotasDoProcesso(tokensDosGrupos(), dig))
        .map((n) => ({ ...n, origem: "gab" }));
    } catch { falhou = true; }
  }

  const todas = [...minhas, ...doGab].sort((a, b) => {
    if (Boolean(a.concluido) !== Boolean(b.concluido)) return a.concluido ? 1 : -1;
    return (a.data_lembrete || "9999").localeCompare(b.data_lembrete || "9999");
  });

  pintarTituloLista(todas.length);
  lista.textContent = "";

  if (!todas.length) {
    vazio(lista, falhou
      ? "Não consegui carregar as notas. Verifique a conexão."
      : "Nenhuma nota neste processo ainda. Escreva a primeira acima.");
    return;
  }
  if (falhou) mostrarStatus("statusNota", "Parte das notas não carregou. Verifique a conexão.", true);

  for (const n of todas) {
    lista.appendChild(itemDeNota(n, { aoAtualizar: carregarListaProcesso }));
  }
}

/* ---------- salvar / editar ---------- */

function abrirEdicao(n) {
  edicao = n;
  quemVe = n.origem;
  el("txtNota").value = n.texto;
  seletorPrazo.reset(n.data_lembrete || null);
  el("tituloCompositor").textContent = n.origem === "gab" ? "Editando nota do gabinete" : "Editando sua nota";
  el("salvarNota").textContent = "Salvar alterações";
  el("cancelarEdicao").hidden = false;
  el("compositor").classList.add("editando");
  atualizarQuemVe();
  el("txtNota").focus();
  el("compositor").scrollIntoView({ block: "nearest" });
}

function sairDaEdicao() {
  edicao = null;
  quemVe = "ind";
  ctlQuemVe.marcar(el("quemVe").querySelector('[data-quem="ind"]'));
  el("txtNota").value = "";
  seletorPrazo.reset(null);
  el("tituloCompositor").textContent = "Escrever";
  el("salvarNota").textContent = "Salvar nota";
  el("cancelarEdicao").hidden = true;
  el("compositor").classList.remove("editando");
  atualizarQuemVe();
}

el("cancelarEdicao").onclick = sairDaEdicao;

async function salvarNota() {
  if (!sessao) {
    mostrarStatus("statusNota", "Entre na sua conta para criar notas.", true);
    return;
  }
  const texto = el("txtNota").value.trim();
  if (!texto) {
    mostrarStatus("statusNota", "Escreva o texto da nota.", true);
    el("txtNota").focus();
    return;
  }

  const prazo = seletorPrazo.valorISO();
  const btn = el("salvarNota");
  btn.disabled = true;

  try {
    if (edicao) {
      // Edição: só texto e prazo mudam. Origem e destinos ficam como estavam.
      if (edicao.origem === "gab") {
        await fsEditarNota(edicao.id, { texto, data_lembrete: prazo });
        enviarBg({ tipo: "sincronizarGabinete" });
      } else {
        await fsEditarNotaPessoal(sessao.uid, edicao.id, { texto, data_lembrete: prazo });
        enviarBg({ tipo: "sincronizarPessoais" });
      }
      sairDaEdicao();
      mostrarStatus("statusNota", "Nota atualizada.");
    } else if (quemVe === "gab") {
      if (!nomeAutor()) {
        mostrarStatus("statusNota", "Defina seu nome na aba Conta para publicar no gabinete.", true);
        return;
      }
      const destinos = destinosSelecionados();
      if (!destinos.length) {
        mostrarStatus("statusNota", "Escolha ao menos um gabinete.", true);
        return;
      }
      await fsCriarNota(destinos, {
        cnj: processo.numero, texto, autor: nomeAutor(), data_lembrete: prazo, url: urlDaAba
      });
      el("txtNota").value = "";
      seletorPrazo.reset(null);
      registrarTextoRecente(texto);
      enviarBg({ tipo: "sincronizarGabinete" });
      mostrarStatus("statusNota", destinos.length === 1
        ? "Nota publicada no gabinete."
        : `Nota publicada em ${destinos.length} gabinetes.`);
    } else {
      // Nota privada: NÃO exige nome — o campo autor não existe nela.
      await fsCriarNotaPessoal(sessao.uid, {
        cnj: processo.numero, texto, data_lembrete: prazo, url: urlDaAba
      });
      el("txtNota").value = "";
      seletorPrazo.reset(null);
      registrarTextoRecente(texto);
      enviarBg({ tipo: "sincronizarPessoais" });
      mostrarStatus("statusNota", "Nota salva.");
    }
    montarChipsModelos(el("modelosNota"), el("txtNota"));
    el("txtNota").focus();          // pronto para a próxima, sem recliques
    await carregarListaProcesso();
  } catch {
    mostrarStatus("statusNota", "Falha ao salvar na nuvem. Verifique a conexão e tente de novo.", true);
  } finally {
    btn.disabled = false;
  }
}

el("salvarNota").onclick = salvarNota;

// Ctrl+Enter salva (Enter puro precisa quebrar linha no textarea).
el("txtNota").addEventListener("keydown", (ev) => {
  if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); salvarNota(); }
});

el("irLogin").onclick = () => { trocarAba("conta"); el("authEmail").focus(); };
el("irPainelGrupos2").onclick = () => api.runtime.openOptionsPage();

/* ---------- ações sobre notas (uma implementação para as duas origens) ---------- */

function avisoDaAba() {
  return el("aba-processo").hidden ? "statusLista" : "statusNota";
}

async function concluir(n, marcado, recarregar) {
  try {
    if (n.origem === "gab") {
      await fsConcluirNota(n.id, marcado, nomeAutor() || "assessor");
      enviarBg({ tipo: "sincronizarGabinete" });
    } else {
      await fsConcluirNotaPessoal(sessao.uid, n.id, marcado);
      enviarBg({ tipo: "sincronizarPessoais" });
    }
  } catch {
    // Sem isto o checkbox voltava sozinho e o usuário achava que errou o clique.
    mostrarStatus(avisoDaAba(), "Sem conexão — a nota não foi atualizada.", true);
  }
  await recarregar();
}

// Adia o prazo em N dias úteis. Já venceu (ou não tinha prazo) → conta de hoje;
// ainda no prazo → conta do prazo atual, que é o que "adiar" significa.
async function adiar(n, dias, recarregar) {
  const base = (n.data_lembrete && !venceu(n.data_lembrete)) ? deISO(n.data_lembrete) : hoje();
  const novo = isoLocal(somarDiasUteis(base, dias));
  try {
    if (n.origem === "gab") {
      await fsEditarNota(n.id, { data_lembrete: novo });
      enviarBg({ tipo: "sincronizarGabinete" });
    } else {
      await fsEditarNotaPessoal(sessao.uid, n.id, { data_lembrete: novo });
      enviarBg({ tipo: "sincronizarPessoais" });
    }
    mostrarStatus(avisoDaAba(), `Adiada para ${dataLonga(novo)}.`);
  } catch {
    mostrarStatus(avisoDaAba(), "Sem conexão — não consegui adiar.", true);
  }
  await recarregar();
}

async function apagar(n, recarregar) {
  const ok = await confirmar(n.origem === "gab"
    ? "Esta nota some para todos do gabinete. Não dá para desfazer."
    : "Esta nota será excluída. Não dá para desfazer.");
  if (!ok) return;
  try {
    if (n.origem === "gab") {
      await fsExcluirNota(n.id);
      enviarBg({ tipo: "sincronizarGabinete" });
    } else {
      await fsExcluirNotaPessoal(sessao.uid, n.id);
      enviarBg({ tipo: "sincronizarPessoais" });
    }
    if (edicao && edicao.id === n.id) sairDaEdicao();
  } catch {
    mostrarStatus(avisoDaAba(), "Sem conexão — a nota não foi excluída.", true);
  }
  await recarregar();
}

/* ---------- aba Lembretes: busca + filtros ---------- */

ligarRadiogroup(el("filtros"), (b) => { filtroAtual = b.dataset.f; montarListaGeral(); });

el("buscaPopup").oninput = (e) => {
  termoBusca = e.target.value.trim().toLowerCase();
  montarListaGeral();
};

function passaNoFiltro(n) {
  if (filtroAtual === "pendentes" && n.concluido) return false;
  if (filtroAtual === "concluidos" && !n.concluido) return false;
  if (!termoBusca) return true;
  return `${n.texto} ${n.autor || ""} ${n.cnj || ""} ${n.cnj_digitos || ""}`
    .toLowerCase().includes(termoBusca);
}

async function montarListaGeral() {
  const lista = el("listaGeral");
  el("statusLista").textContent = "";
  el("statusLista").classList.remove("ruim");

  // Estado vazio honesto: sem sessão o problema é o login, não a falta de notas.
  if (!sessao) {
    vazio(lista, "Entre na sua conta (aba Conta) para ver seus lembretes.");
    return;
  }

  esqueleto(lista, 4);

  let individuais = [];
  try {
    individuais = await fsTodasNotasPessoais(sessao.uid);
  } catch {
    const { cachePessoal } = await api.storage.local.get("cachePessoal");
    individuais = cachePessoal?.notas || [];
    mostrarStatus("statusLista", "Sem conexão — mostrando a última sincronização.", true);
  }
  individuais = individuais.map((n) => ({ ...n, origem: "ind" }));

  let doGab = [];
  if (tokensDosGrupos().length) {
    try {
      doGab = await fsNotasDosGrupos(tokensDosGrupos());
    } catch {
      const { cacheGabinete } = await api.storage.local.get("cacheGabinete");
      doGab = cacheGabinete?.notas || [];
      mostrarStatus("statusLista", "Sem conexão — mostrando a última sincronização do gabinete.", true);
    }
    doGab = doGab.map((n) => ({ ...n, origem: "gab" }));
  }

  const todas = [...individuais, ...doGab]
    .filter(passaNoFiltro)
    .sort((a, b) => (a.data_lembrete || "9999").localeCompare(b.data_lembrete || "9999"));

  lista.textContent = "";

  if (!todas.length) {
    vazio(lista, termoBusca
      ? "Nada encontrado para essa busca."
      : filtroAtual === "concluidos"
        ? "Nada concluído ainda."
        : "Nenhum lembrete por aqui. Abra um processo no PJe e anote.");
    return;
  }

  if (filtroAtual !== "pendentes") {
    for (const n of todas) {
      lista.appendChild(itemDeNota(n, { aoAtualizar: montarListaGeral, comCnj: true }));
    }
    return;
  }

  // Pendentes viram agenda: vencidas, hoje, amanhã, esta semana…
  for (const b of BALDES) {
    const itens = todas.filter((n) => baldeDe(n) === b.chave);
    if (!itens.length) continue;
    const h = document.createElement("h3");
    h.className = "grupo-cab" + (b.chave === "venc" ? " venc" : "");
    const q = document.createElement("span");
    q.textContent = String(itens.length);
    h.append(b.titulo, q);
    lista.appendChild(h);
    for (const n of itens) {
      lista.appendChild(itemDeNota(n, { aoAtualizar: montarListaGeral, comCnj: true }));
    }
  }
}

/* ---------- conta ---------- */

async function atualizarUIConta() {
  sessao = await sessaoAtual();
  el("contaDeslogado").hidden = !!sessao;
  el("contaLogado").hidden = !sessao;
  el("blocoPerfil").hidden = !sessao;

  if (sessao) {
    el("contaEmail").textContent = sessao.email;
    try { perfil = await fsLerPerfil(sessao.uid); } catch { /* offline: mantém o que tem */ }
    await migrarTokenLegado();
    if (document.activeElement !== el("perfilNome")) {
      el("perfilNome").value = perfil?.nome || "";
    }
    const gs = gruposDoPerfil();
    el("resumoGrupos").textContent = gs.length
      ? gs.map((g) => g.nome || "gabinete").join(" · ")
      : "nenhum ainda";
    el("quem").textContent = nomeAutor() || sessao.email;
    el("quem").title = sessao.email;
    renderDestinos();
  } else {
    perfil = null;
    el("quem").textContent = "";
    el("quem").title = "";
  }
  atualizarQuemVe();
}

// Ao entrar pela 1ª vez, oferece subir as notas antigas (storage.sync) para a
// conta na nuvem. Depois de migrada, cada nota some do storage.sync.
async function migrarNotasLocais() {
  if (!sessao) return;
  const tudo = await api.storage.sync.get(null);
  const chaves = Object.keys(tudo).filter((k) => k.startsWith("nota:"));
  if (!chaves.length) return;
  const ok = await confirmar(
    `Encontrei ${chaves.length} nota(s) salva(s) só neste computador. Vincular à sua conta na nuvem?`,
    "Vincular");
  if (!ok) return;

  let migradas = 0;
  for (const k of chaves) {
    const n = tudo[k];
    try {
      await fsCriarNotaPessoal(sessao.uid, {
        cnj: n.cnj,
        texto: n.texto,
        data_lembrete: n.data_lembrete || null,
        url: n.url || null,
        concluido: Boolean(n.concluido),
        concluido_em: n.concluido_em || null
      });
      await api.storage.sync.remove(k);   // alarme legado vira inócuo (chave some)
      migradas++;
    } catch { /* deixa local; tenta de novo numa próxima */ }
  }
  if (migradas) mostrarStatus("statusConta", `${migradas} nota(s) migrada(s) para a nuvem.`);
}

/* --- alternador Entrar / Criar conta ---
   Botões lado a lado com o mesmo peso levavam ao cadastro acidental: quem
   errava o e-mail criava uma conta nova, entrava nela e só descobria dias
   depois, ao tentar logar com o e-mail certo. Agora é uma escolha explícita. */
function aplicarModoConta(modo) {
  modoConta = modo;
  const criando = modo === "criar";
  el("campoConfirma").hidden = !criando;
  el("avisoSessao").hidden = !criando;
  el("btnAcaoConta").textContent = criando ? "Criar minha conta" : "Entrar";
  el("authSenha").setAttribute("autocomplete", criando ? "new-password" : "current-password");
  el("authSenha").placeholder = criando ? "Crie uma senha (mín. 6)" : "Sua senha";
}

ligarRadiogroup(document.querySelector(".modo-conta"), (b) => aplicarModoConta(b.dataset.modo));
aplicarModoConta("entrar");

el("olhoSenha").onclick = () => {
  const campo = el("authSenha");
  const mostrando = campo.type === "text";
  campo.type = mostrando ? "password" : "text";
  el("authConfirma").type = campo.type;
  el("olhoSenha").setAttribute("aria-pressed", String(!mostrando));
  el("olhoSenha").setAttribute("aria-label", mostrando ? "Mostrar senha" : "Ocultar senha");
  campo.focus();
};

el("formConta").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const email = el("authEmail").value.trim();
  const senha = el("authSenha").value;

  if (!email || !senha) {
    mostrarStatus("statusConta", "Preencha e-mail e senha.", true);
    return;
  }
  if (modoConta === "criar") {
    if (senha.length < 6) {
      mostrarStatus("statusConta", "A senha precisa ter ao menos 6 caracteres.", true);
      return;
    }
    if (senha !== el("authConfirma").value) {
      mostrarStatus("statusConta", "As duas senhas não são iguais. Confira antes de criar a conta.", true);
      el("authConfirma").focus();
      return;
    }
  }

  const btn = el("btnAcaoConta");
  btn.disabled = true;
  const rotulo = btn.textContent;
  btn.textContent = modoConta === "criar" ? "Criando…" : "Entrando…";
  try {
    await (modoConta === "criar" ? criarConta : entrar)(email, senha);
    el("authEmail").value = "";
    el("authSenha").value = "";
    el("authConfirma").value = "";
    mostrarStatus("statusConta", modoConta === "criar" ? "Conta criada e sessão iniciada." : "Login efetuado.");
    await atualizarUIConta();
    await migrarNotasLocais();
    if (processo) carregarListaProcesso();
    enviarBg({ tipo: "sincronizarPessoais" });
    enviarBg({ tipo: "sincronizarGabinete" });
    // Sem nome definido, o próximo passo é esse — leva o usuário até lá.
    if (!nomeAutor()) el("perfilNome").focus();
  } catch (e) {
    mostrarStatus("statusConta", traduzErroAuth(e.message), true);
  } finally {
    btn.disabled = false;
    btn.textContent = rotulo;
  }
});

el("btnSair").onclick = async () => {
  await sair();
  mostrarStatus("statusConta", "Você saiu da conta.");
  await atualizarUIConta();
  if (processo) carregarListaProcesso();
  enviarBg({ tipo: "sincronizarPessoais" });    // zera o cache pessoal no SW
};

el("lnkEsqueci").onclick = async (ev) => {
  ev.preventDefault();
  const email = el("authEmail").value.trim();
  if (!email) {
    mostrarStatus("statusConta", "Informe o e-mail para redefinir a senha.", true);
    el("authEmail").focus();
    return;
  }
  try {
    await resetSenha(email);
    mostrarStatus("statusConta", "E-mail de redefinição enviado. Confira sua caixa de entrada e o spam.");
  } catch (e) {
    mostrarStatus("statusConta", traduzErroAuth(e.message), true);
  }
};

el("btnSalvarNome").onclick = async () => {
  if (!sessao) return;
  const nome = el("perfilNome").value.trim();
  if (!nome) { mostrarStatus("statusConfig", "Informe seu nome.", true); return; }
  el("btnSalvarNome").disabled = true;
  try {
    perfil = await fsSalvarPerfil(sessao.uid, { nome, grupos: gruposDoPerfil() });
    el("quem").textContent = nome;
    mostrarStatus("statusConfig", "Nome salvo.");
    if (processo) carregarListaProcesso();
  } catch {
    mostrarStatus("statusConfig", "Não consegui salvar o nome. Verifique a conexão.", true);
  } finally {
    el("btnSalvarNome").disabled = false;
  }
};

el("irPainelGrupos").onclick = () => api.runtime.openOptionsPage();

// Quem já usava o token único do storage.sync entra nele automaticamente.
async function migrarTokenLegado() {
  if (!sessao || !config.token) return;
  if (tokensDosGrupos().includes(config.token)) return;
  try {
    perfil = await fsSalvarPerfil(sessao.uid, {
      nome: nomeAutor() || config.nome || "",
      grupos: [...gruposDoPerfil(), { token: config.token, nome: "Gabinete" }]
    });
  } catch { /* sem conexão: tenta de novo na próxima abertura */ }
}

/* ---------- partida ---------- */

async function iniciar() {
  config = (await api.storage.sync.get("config")).config || {};

  await atualizarUIConta();
  montarChipsModelos(el("modelosNota"), el("txtNota"));

  // linkUtil() (comum.js) descarta o error.seam para onde o Seam joga a aba
  // quando a conversa expira; o content script tem o último link válido.
  const [aba] = await api.tabs.query({ active: true, currentWindow: true });
  urlDaAba = linkUtil(aba?.url);

  try {
    processo = await api.tabs.sendMessage(aba.id, { tipo: "pedirProcesso" });
  } catch {
    processo = null; // aba sem content script (fora do PJe, ou aberta antes da instalação)
  }
  if (processo?.url) urlDaAba = processo.url;

  // Abrir o popup é um bom momento para atualizar o cache: o do service worker
  // é periódico e ficaria velho justo quando o usuário está olhando.
  enviarBg({ tipo: "sincronizarPessoais" });
  enviarBg({ tipo: "sincronizarGabinete" });

  if (processo) {
    el("comProcesso").hidden = false;
    pintarCnj(processo.numero);
    pintarMeta();
    carregarListaProcesso();
  } else {
    el("semProcesso").hidden = false;
  }

  const termo = await focoDeBusca();
  if (termo) {
    el("buscaPopup").value = termo;
    termoBusca = termo.toLowerCase();
    trocarAba("lembretes");
    return;
  }

  if (!processo) {
    // Sem processo aberto, a aba útil é a de lembretes — ou a conta, se deslogado.
    trocarAba(sessao ? "lembretes" : "conta");
    if (!sessao) el("authEmail").focus();
    return;
  }
  if (sessao) el("txtNota").focus();
}

// Veio do clique num selo do PJe: abrir já filtrado por aquele processo.
async function focoDeBusca() {
  const { focoBusca } = await api.storage.local.get("focoBusca");
  if (!focoBusca?.termo || Date.now() - (focoBusca.em || 0) > 60000) return null;
  await api.storage.local.remove("focoBusca");
  return focoBusca.termo;
}

iniciar();
