/* =========================================================================
   firestore.js — cliente REST do Cloud Firestore
   Usado pelo popup (via <script>) e pelo service worker (via importScripts).

   Não usamos o SDK do Firebase de propósito: no Manifest V3 o SDK web
   exige empacotamento (bundler) e traz centenas de KB. A API REST faz
   tudo o que precisamos com fetch puro.
   ========================================================================= */

// >>> PREENCHA COM OS DADOS DO SEU PROJETO (console.firebase.google.com) <<<
// Project ID: Configurações do projeto > Geral > "ID do projeto"
// API key:    Configurações do projeto > Geral > "Chave de API da Web"
const FIRESTORE_CONFIG = {
  projectId: "lembrentespje",
  // Chave "Extensao Lembretes PJe" — liberada p/ Cloud Firestore + Identity
  // Toolkit + Token Service (login/cadastro e renovação de sessão).
  apiKey: "AIzaSyBJwZPiNWvDiKvN-cBXWCkSLWPeVVrXXQg"
};

const FS_DOCS =
  `https://firestore.googleapis.com/v1/projects/${FIRESTORE_CONFIG.projectId}` +
  `/databases/(default)/documents`;

const fsConfigurado = () =>
  !FIRESTORE_CONFIG.projectId.startsWith("SEU_") &&
  !FIRESTORE_CONFIG.apiKey.startsWith("SUA_");

/* ---------- conversão JS <-> formato de campos do Firestore ----------
   A API REST não aceita JSON simples: cada valor vem embrulhado no seu
   tipo ({ stringValue: ... }, { booleanValue: ... }, etc.).            */

function paraValor(v) {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === "boolean")        return { booleanValue: v };
  if (typeof v === "number")         return { integerValue: String(v) };
  if (v instanceof Date)             return { timestampValue: v.toISOString() };
  if (Array.isArray(v))              return { arrayValue: { values: v.map(paraValor) } };
  if (typeof v === "object")         return { mapValue: { fields: paraCampos(v) } };
  return { stringValue: String(v) };
}

function paraCampos(obj) {
  const campos = {};
  for (const [k, v] of Object.entries(obj)) campos[k] = paraValor(v);
  return campos;
}

function deValor(v) {
  if ("stringValue" in v)    return v.stringValue;
  if ("booleanValue" in v)   return v.booleanValue;
  if ("integerValue" in v)   return Number(v.integerValue);
  if ("doubleValue" in v)    return Number(v.doubleValue);
  if ("timestampValue" in v) return v.timestampValue;
  if ("arrayValue" in v)     return (v.arrayValue.values || []).map(deValor);
  if ("mapValue" in v)       return deFields(v.mapValue.fields || {});
  return null;
}

function deFields(fields) {
  const saida = {};
  for (const [k, v] of Object.entries(fields)) saida[k] = deValor(v);
  return saida;
}

function deCampos(doc) {
  return { id: doc.name.split("/").pop(), ...deFields(doc.fields || {}) };
}

async function fsFetch(url, opcoes = {}) {
  // Anexa o idToken do usuário logado (quando auth.js está presente): as
  // notas pessoais em usuarios/{uid} só passam pela regra com o Bearer certo.
  const idToken = (typeof tokenValido === "function") ? await tokenValido() : null;
  const sep = url.includes("?") ? "&" : "?";
  const headers = { "Content-Type": "application/json", ...(opcoes.headers || {}) };
  if (idToken) headers.Authorization = "Bearer " + idToken;
  const resp = await fetch(`${url}${sep}key=${FIRESTORE_CONFIG.apiKey}`, {
    ...opcoes,
    headers
  });
  if (!resp.ok) {
    const corpo = await resp.text().catch(() => "");
    throw new Error(`Firestore ${resp.status}: ${corpo.slice(0, 200)}`);
  }
  return resp.json();
}

/* ---------- notas de GRUPO: coleção plana `lembretes` ----------
   As regras publicadas exigem login e guardam as notas de grupo numa coleção
   plana `lembretes`. O vínculo com os gabinetes é o array `tokens` — uma nota
   pode pertencer a VÁRIOS gabinetes de uma vez. Notas antigas usam o campo
   string `token_gabinete`; as consultas cobrem os dois formatos.

   ATENÇÃO: as regras proíbem alterar `tokens` depois de criada a nota, então os
   gabinetes de uma nota são definidos no momento da criação.                  */

// Roda uma structuredQuery na raiz e devolve os documentos já convertidos.
async function fsConsulta(structuredQuery) {
  const linhas = await fsFetch(`${FS_DOCS}:runQuery`, {
    method: "POST",
    body: JSON.stringify({ structuredQuery })
  });
  return linhas.filter((l) => l.document).map((l) => deCampos(l.document));
}

// Gabinetes aos quais a nota pertence, cobrindo o formato antigo.
const gruposDaNota = (n) =>
  (Array.isArray(n.tokens) && n.tokens.length)
    ? n.tokens
    : (n.token_gabinete ? [n.token_gabinete] : []);

// Cria uma nota compartilhada em um ou mais gabinetes. Devolve a nota criada.
async function fsCriarNota(tokens, nota) {
  const lista = (Array.isArray(tokens) ? tokens : [tokens]).filter(Boolean);
  if (!lista.length) throw new Error("SEM_GABINETE");
  const agora = new Date();
  const doc = await fsFetch(`${FS_DOCS}/lembretes`, {
    method: "POST",
    body: JSON.stringify({
      fields: paraCampos({
        tokens: lista.slice(0, 30),                // as regras limitam a 30
        cnj: nota.cnj,
        cnj_digitos: nota.cnj.replace(/\D/g, ""),  // normalizado p/ consulta
        texto: nota.texto,
        autor: nota.autor,
        criado_em: agora,
        url: nota.url || null,                     // abre o processo no PJe
        data_lembrete: nota.data_lembrete || null, // "AAAA-MM-DD" ou null
        concluido: false,
        concluido_por: null,
        concluido_em: null,
        atualizado_em: agora
      })
    })
  });
  return deCampos(doc);
}

// Notas de TODOS os gabinetes informados. Uma consulta ARRAY_CONTAINS_ANY para
// o formato novo + uma consulta de igualdade por gabinete para o legado.
// Sem orderBy no servidor: ordenamos no cliente e evitamos índice composto.
async function fsNotasDosGrupos(tokens) {
  const lista = (tokens || []).filter(Boolean).slice(0, 30);
  if (!lista.length) return [];

  const novas = await fsConsulta({
    from: [{ collectionId: "lembretes" }],
    where: {
      fieldFilter: {
        field: { fieldPath: "tokens" },
        op: "ARRAY_CONTAINS_ANY",
        value: { arrayValue: { values: lista.map((t) => ({ stringValue: t })) } }
      }
    },
    limit: 300
  });

  const legado = [];
  for (const t of lista) {
    legado.push(...await fsConsulta({
      from: [{ collectionId: "lembretes" }],
      where: {
        fieldFilter: {
          field: { fieldPath: "token_gabinete" },
          op: "EQUAL",
          value: { stringValue: t }
        }
      },
      limit: 300
    }));
  }

  const porId = new Map();
  for (const n of [...novas, ...legado]) porId.set(n.id, n);
  return [...porId.values()]
    .sort((a, b) => (b.criado_em || "").localeCompare(a.criado_em || ""));
}

// Notas dos gabinetes para UM processo (filtra o CNJ no cliente).
async function fsNotasDoProcesso(tokens, cnjDigitos) {
  const todas = await fsNotasDosGrupos(tokens);
  return todas.filter((n) => (n.cnj_digitos || "") === cnjDigitos);
}

// updateMask com EXATAMENTE os campos passados. Sem isso o PATCH apagaria o
// resto do documento — e as regras exigem que cnj/autor/criado_em/tokens
// cheguem intactos no update.
const _mask = (campos) => Object.keys(campos)
  .map((c) => `updateMask.fieldPaths=${encodeURIComponent(c)}`)
  .join("&");

async function _patch(url, campos) {
  const dados = { ...campos, atualizado_em: new Date() };
  const doc = await fsFetch(`${url}?${_mask(dados)}`, {
    method: "PATCH",
    body: JSON.stringify({ fields: paraCampos(dados) })
  });
  return deCampos(doc);
}

// Marca/desmarca conclusão.
async function fsConcluirNota(notaId, concluido, quem) {
  return _patch(`${FS_DOCS}/lembretes/${encodeURIComponent(notaId)}`, {
    concluido,
    concluido_por: concluido ? quem : null,
    concluido_em: concluido ? new Date() : null
  });
}

// Edita uma nota de gabinete. `campos` é parcial — { texto }, { data_lembrete }
// ou os dois. Só o que vem é gravado, o resto do documento fica como está.
async function fsEditarNota(notaId, campos) {
  return _patch(`${FS_DOCS}/lembretes/${encodeURIComponent(notaId)}`, campos);
}

async function fsExcluirNota(notaId) {
  await fsFetch(`${FS_DOCS}/lembretes/${encodeURIComponent(notaId)}`, { method: "DELETE" });
}

/* ---------- notas PESSOAIS: usuarios/{uid}/notas ----------
   Espelham as do gabinete, mas escopadas pelo uid do usuário logado. As
   regras só deixam o próprio dono ler/escrever — segurança por request.auth.
   Todas as chamadas passam pelo fsFetch, que injeta o Bearer do idToken.   */

const FS_USUARIO = (uid) => `${FS_DOCS}/usuarios/${encodeURIComponent(uid)}`;

/* ---------- perfil: usuarios/{uid} ----------
   Guarda o `nome` (vira o autor das notas de grupo) e a lista de `grupos`
   [{ token, nome }]. Fica na CONTA, não no dispositivo — por isso reaparece
   igual em qualquer computador onde a pessoa entrar.                        */

async function fsLerPerfil(uid) {
  try {
    return deCampos(await fsFetch(FS_USUARIO(uid)));
  } catch (e) {
    if (/Firestore 404/.test(String(e.message))) return null;  // ainda não criado
    throw e;
  }
}

async function fsSalvarPerfil(uid, perfil) {
  const campos = {
    nome: perfil.nome || "",
    grupos: (perfil.grupos || []).map((g) => ({ token: g.token, nome: g.nome || "" }))
  };
  const mask = Object.keys(campos)
    .map((c) => `updateMask.fieldPaths=${encodeURIComponent(c)}`)
    .join("&");
  const doc = await fsFetch(`${FS_USUARIO(uid)}?${mask}`, {
    method: "PATCH",
    body: JSON.stringify({ fields: paraCampos(campos) })
  });
  return deCampos(doc);
}

async function fsCriarNotaPessoal(uid, nota) {
  const agora = new Date();
  const doc = await fsFetch(`${FS_USUARIO(uid)}/notas`, {
    method: "POST",
    body: JSON.stringify({
      fields: paraCampos({
        cnj: nota.cnj,
        cnj_digitos: (nota.cnj || "").replace(/\D/g, ""),
        texto: nota.texto,
        data_lembrete: nota.data_lembrete || null,
        url: nota.url || null,
        concluido: Boolean(nota.concluido),
        concluido_em: nota.concluido_em || null,
        criado_em: agora,
        atualizado_em: agora
      })
    })
  });
  return deCampos(doc);
}

async function fsNotasPessoaisDoProcesso(uid, cnjDigitos) {
  const linhas = await fsFetch(`${FS_USUARIO(uid)}:runQuery`, {
    method: "POST",
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId: "notas" }],
        where: {
          fieldFilter: {
            field: { fieldPath: "cnj_digitos" },
            op: "EQUAL",
            value: { stringValue: cnjDigitos }
          }
        },
        limit: 100
      }
    })
  });
  return linhas.filter((l) => l.document).map((l) => deCampos(l.document));
}

async function fsTodasNotasPessoais(uid) {
  const linhas = await fsFetch(`${FS_USUARIO(uid)}:runQuery`, {
    method: "POST",
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId: "notas" }],
        orderBy: [{ field: { fieldPath: "criado_em" }, direction: "DESCENDING" }],
        limit: 500
      }
    })
  });
  return linhas.filter((l) => l.document).map((l) => deCampos(l.document));
}

async function fsConcluirNotaPessoal(uid, notaId, concluido) {
  return _patch(`${FS_USUARIO(uid)}/notas/${encodeURIComponent(notaId)}`, {
    concluido,
    concluido_em: concluido ? new Date() : null
  });
}

// Edita uma nota pessoal. `campos` parcial, igual ao fsEditarNota.
async function fsEditarNotaPessoal(uid, notaId, campos) {
  return _patch(`${FS_USUARIO(uid)}/notas/${encodeURIComponent(notaId)}`, campos);
}

async function fsExcluirNotaPessoal(uid, notaId) {
  await fsFetch(
    `${FS_USUARIO(uid)}/notas/${encodeURIComponent(notaId)}`,
    { method: "DELETE" }
  );
}
