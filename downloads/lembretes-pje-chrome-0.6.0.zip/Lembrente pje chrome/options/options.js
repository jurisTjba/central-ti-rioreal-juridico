/* =========================================================================
   options.js — página inteira de visualização (Painel)
   Junta as notas pessoais (Firestore por uid, exige login) e as do gabinete
   (Firestore por token) num modelo único e oferece três visões que o popup
   não comporta:
     • Painel      — carimbos de contagem + agenda de prazos por vencimento
     • Todas as notas — busca, filtro por origem e por status
     • Por processo — notas agrupadas pelo CNJ, com o número decomposto
   Fora da extensão, cai em MODO DEMONSTRAÇÃO com dados de exemplo, para que
   o layout possa ser conferido no navegador comum.
   Todo texto de usuário é inserido com textContent — nunca innerHTML.
   ========================================================================= */

const NA_EXTENSAO =
  typeof api !== "undefined" && api && api.storage && api.storage.sync;

// SEGMENTOS, el() e os utilitários de data/CNJ vêm de comum.js.

let config = {};        // { nome, token } — legado do storage.sync (migração)
let sessao = null;      // sessão do Firebase Auth (auth.js) ou null
let perfil = null;      // { nome, grupos: [{ token, nome }] } — vem da conta
let notas = [];         // modelo unificado
let filtroOrigem = "todas";
let filtroStatus = "pendentes";
let termoBusca = "";

// Nome do autor e gabinetes vêm do perfil da conta; `config` só como legado.
const nomeAutor = () => String(perfil?.nome || config.nome || "").trim();
const gruposDoPerfil = () => (perfil?.grupos || []).filter((g) => g && g.token);
const tokensDosGrupos = () => gruposDoPerfil().map((g) => g.token);
const nomeDoGrupo = (token) =>
  gruposDoPerfil().find((g) => g.token === token)?.nome || "gabinete";

// Repassa uma mensagem ao service worker sem quebrar se ele reiniciar (MV3).
function enviarBg(msg) {
  try { api.runtime.sendMessage(msg); } catch (_) { /* SW reiniciando */ }
}

/* ---------------- copiar número do processo ---------------- */

// Ícone montado sem innerHTML (mesma disciplina do resto do painel).
function iconeCopiar() {
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("width", "14"); svg.setAttribute("height", "14");
  svg.setAttribute("viewBox", "0 0 24 24"); svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor"); svg.setAttribute("stroke-width", "2");
  svg.setAttribute("stroke-linecap", "round"); svg.setAttribute("stroke-linejoin", "round");
  const rect = document.createElementNS(NS, "rect");
  rect.setAttribute("x", "9"); rect.setAttribute("y", "9");
  rect.setAttribute("width", "13"); rect.setAttribute("height", "13"); rect.setAttribute("rx", "2");
  const path = document.createElementNS(NS, "path");
  path.setAttribute("d", "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1");
  svg.append(rect, path);
  return svg;
}

function copiarTexto(texto, aoConcluir) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(texto).then(aoConcluir).catch(() => copiarLegado(texto, aoConcluir));
  } else {
    copiarLegado(texto, aoConcluir);
  }
}
function copiarLegado(texto, aoConcluir) {
  const ta = document.createElement("textarea");
  ta.value = texto; ta.style.position = "fixed"; ta.style.opacity = "0";
  document.body.appendChild(ta); ta.focus(); ta.select();
  try { document.execCommand("copy"); aoConcluir(); } catch { /* ignora */ }
  finally { ta.remove(); }
}

function botaoCopiar(numero, extraClasse) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "btn-copiar" + (extraClasse ? " " + extraClasse : "");
  b.title = "Copiar número do processo";
  b.setAttribute("aria-label", "Copiar número do processo");
  b.appendChild(iconeCopiar());
  b.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation(); // não abre o processo nem alterna o <details>
    copiarTexto(numero, () => {
      b.classList.add("ok");
      b.title = "Copiado!";
      setTimeout(() => { b.classList.remove("ok"); b.title = "Copiar número do processo"; }, 1500);
    });
  };
  return b;
}

/* ---------------- CNJ (digitosDe e decompor vêm de comum.js) ---------------- */

// CNJ decomposto grande (cabeçalho do processo) — a assinatura da extensão.
function cnjFull(numero) {
  const alvo = document.createElement("div");
  alvo.className = "cnj-full";
  let d;
  try { d = decompor(numero); } catch { alvo.textContent = numero; return alvo; }
  const partes = [
    [d.seq, "sequencial"], ["-", null], [d.dv, "dv"], [".", null],
    [d.ano, "ano"], [".", null], [d.j, "segmento"], [".", null],
    [d.tr, "tribunal"], [".", null], [d.origem, "origem"]
  ];
  for (const [txt, rot] of partes) {
    const div = document.createElement("div");
    if (!rot) { div.className = "sep"; div.textContent = txt; }
    else {
      const p = document.createElement("span"); p.className = "parte"; p.textContent = txt;
      const r = document.createElement("span"); r.className = "rot"; r.textContent = rot;
      div.append(p, r);
    }
    alvo.appendChild(div);
  }
  return alvo;
}

// CNJ compacto para as linhas: sequencial destacado + número inteiro pequeno.
function cnjMini(numero) {
  const box = document.createElement("div");
  box.className = "cnj-mini";
  let d;
  try { d = decompor(numero); } catch { box.textContent = numero; return box; }
  const seq = document.createElement("div"); seq.className = "seq"; seq.textContent = d.seq;
  const rot = document.createElement("div");
  rot.className = "rot"; rot.textContent = `${SEGMENTOS[Number(d.j)] || "—"} · ${d.ano}`;
  const inteiro = document.createElement("div"); inteiro.textContent = numero;
  box.append(seq, rot, inteiro, botaoCopiar(numero, "mini"));
  return box;
}

/* ---------------- camada de dados ---------------- */

function normalizarPessoais(lista) {
  return lista.map((n) => ({
    id: n.id,
    origem: "ind",
    cnj: n.cnj,
    cnj_digitos: n.cnj_digitos || digitosDe(n.cnj),
    texto: n.texto || "",
    autor: null,
    data_lembrete: n.data_lembrete || null,
    concluido: Boolean(n.concluido),
    concluido_por: null,
    concluido_em: n.concluido_em || null,
    criado_em: n.criado_em || null,
    url: linkUtil(n.url)
  }));
}

function normalizarGabinete(lista) {
  return lista.map((n) => ({
    id: n.id,
    origem: "gab",
    grupos: gruposDaNota(n),          // tokens dos gabinetes desta nota
    cnj: n.cnj,
    cnj_digitos: n.cnj_digitos || digitosDe(n.cnj),
    texto: n.texto || "",
    autor: n.autor || "gabinete",
    data_lembrete: n.data_lembrete || null,
    concluido: Boolean(n.concluido),
    concluido_por: n.concluido_por || null,
    concluido_em: n.concluido_em || null,
    criado_em: n.criado_em || null,
    url: linkUtil(n.url)
  }));
}

async function carregarTudo() {
  if (!NA_EXTENSAO) { notas = DEMO.slice(); return; }

  config = (await api.storage.sync.get("config")).config || {};
  sessao = (typeof sessaoAtual === "function") ? await sessaoAtual() : null;

  // Perfil da conta (nome + gabinetes). Sem sessão não há perfil.
  perfil = null;
  if (sessao) {
    try {
      perfil = await fsLerPerfil(sessao.uid);
    } catch {
      el("statusNotas").textContent = "Não consegui ler seu perfil (sem conexão?).";
      el("statusNotas").className = "status-linha ruim";
    }
    await migrarTokenLegado();
  }

  let individuais = [];
  if (sessao) {
    try {
      individuais = normalizarPessoais(await fsTodasNotasPessoais(sessao.uid));
    } catch {
      const { cachePessoal } = await api.storage.local.get("cachePessoal");
      individuais = normalizarPessoais(cachePessoal?.notas || []);
      el("statusNotas").textContent =
        "Sem conexão com o Firestore — mostrando a última sincronização.";
      el("statusNotas").className = "status-linha ruim";
    }
  }

  let gab = [];
  const tokens = tokensDosGrupos();
  if (fsConfigurado() && sessao && tokens.length) {
    try {
      gab = normalizarGabinete(await fsNotasDosGrupos(tokens));
    } catch {
      const { cacheGabinete } = await api.storage.local.get("cacheGabinete");
      gab = normalizarGabinete(cacheGabinete?.notas || []);
      el("statusNotas").textContent =
        "Sem conexão com o Firestore — mostrando a última sincronização do gabinete.";
      el("statusNotas").className = "status-linha ruim";
    }
  }
  notas = [...individuais, ...gab];
}

/* ---------------- diálogo de confirmação ----------------
   <dialog> nativo: prende o foco, fecha no Esc e é anunciado como modal. */

function confirmar(texto, rotuloOk = "Excluir", titulo = "Confirmar") {
  const dlg = el("dlgConfirma");
  el("dlgTitulo").textContent = titulo;
  el("dlgTexto").textContent = texto;
  el("dlgConfirmar").textContent = rotuloOk;
  dlg.showModal();
  return new Promise((resolve) => {
    const fim = (v) => {
      el("dlgConfirmar").onclick = null;
      el("dlgCancelar").onclick = null;
      dlg.oncancel = null;
      dlg.onclose = null;
      if (dlg.open) dlg.close();
      resolve(v);
    };
    el("dlgConfirmar").onclick = () => fim(true);
    el("dlgCancelar").onclick = () => fim(false);
    // `cancel` é o Esc. `close` fica como reserva: nem todo motor dispara os
    // dois, e sem um deles a promessa ficaria pendurada para sempre.
    dlg.oncancel = () => fim(false);
    dlg.onclose = () => fim(false);
  });
}

/* ---------------- radiogroup acessível (segmentados e alternadores) ----------------
   Setas circulam entre as opções e só a marcada fica no tab order. */
function ligarRadiogroup(container, aoEscolher) {
  const itens = [...container.querySelectorAll('[role="radio"]')];
  const marcar = (alvo) => itens.forEach((i) => {
    const é = i === alvo;
    i.setAttribute("aria-checked", String(é));
    i.tabIndex = é ? 0 : -1;
  });
  marcar(itens.find((i) => i.getAttribute("aria-checked") === "true") || itens[0]);
  itens.forEach((item) => {
    item.onclick = () => { if (!item.disabled) { marcar(item); aoEscolher(item); } };
    item.onkeydown = (ev) => {
      const passo = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[ev.key];
      if (!passo) return;
      ev.preventDefault();
      const livres = itens.filter((i) => !i.disabled);
      const prox = livres[(livres.indexOf(item) + passo + livres.length) % livres.length];
      marcar(prox); prox.focus(); aoEscolher(prox);
    };
  });
  return { marcar, itens };
}

/* ---------------- ações (conclusão / edição / adiamento / exclusão) ---------------- */

async function alternarConclusao(nota) {
  const marcado = !nota.concluido;
  if (!NA_EXTENSAO) { // demo: só na memória
    nota.concluido = marcado;
    nota.concluido_em = marcado ? new Date().toISOString() : null;
    nota.concluido_por = marcado ? (config.nome || "você") : null;
    return renderTudo();
  }
  if (nota.origem === "ind") {
    if (!sessao) return;
    try {
      await fsConcluirNotaPessoal(sessao.uid, nota.id, marcado);
      enviarBg({ tipo: "sincronizarPessoais" });
    } catch {
      el("statusNotas").textContent = "Não consegui atualizar no Firestore. Tente de novo.";
      el("statusNotas").className = "status-linha ruim";
      return;
    }
  } else {
    try {
      await fsConcluirNota(nota.id, marcado, nomeAutor() || "assessor");
      enviarBg({ tipo: "sincronizarGabinete" });
    } catch {
      el("statusNotas").textContent = "Não consegui atualizar no Firestore. Tente de novo.";
      el("statusNotas").className = "status-linha ruim";
      return;
    }
  }
  await recarregar();
}

// Adia o prazo em N dias úteis. Já venceu (ou não tinha prazo) → conta de
// hoje; ainda no prazo → conta do prazo atual, que é o que "adiar" significa.
async function adiar(nota, dias = 7) {
  const base = (nota.data_lembrete && !venceu(nota.data_lembrete)) ? deISO(nota.data_lembrete) : hoje();
  const novo = isoLocal(somarDiasUteis(base, dias));

  if (!NA_EXTENSAO) { nota.data_lembrete = novo; return renderTudo(); }
  try {
    if (nota.origem === "ind") {
      if (!sessao) return;
      await fsEditarNotaPessoal(sessao.uid, nota.id, { data_lembrete: novo });
      enviarBg({ tipo: "sincronizarPessoais" });
    } else {
      await fsEditarNota(nota.id, { data_lembrete: novo });
      enviarBg({ tipo: "sincronizarGabinete" });
    }
    aviso("statusNotas", `Adiada para ${dataLonga(novo)}.`);
  } catch {
    aviso("statusNotas", "Não consegui adiar. Verifique a conexão.", true);
    return;
  }
  await recarregar();
}

// Edição no lugar: troca o corpo da linha por um campo de texto e um de data.
// Sem modal e sem tirar a nota do contexto em que ela está sendo lida.
function editarInline(nota, linha) {
  const corpo = linha.querySelector(".corpo");
  if (!corpo || corpo.dataset.editando === "1") return;
  corpo.dataset.editando = "1";
  const original = [...corpo.childNodes];
  corpo.textContent = "";

  const ta = document.createElement("textarea");
  ta.value = nota.texto;
  ta.maxLength = 1500;
  ta.setAttribute("aria-label", "Texto da nota");
  ta.style.cssText = "width:100%;min-height:70px;padding:8px 10px;border:1px solid var(--linha);"
    + "border-radius:3px;background:#fff;font:inherit;color:var(--tinta);box-sizing:border-box;resize:vertical";

  const linhaCampos = document.createElement("div");
  linhaCampos.style.cssText = "display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap";

  const rotData = document.createElement("label");
  rotData.textContent = "Prazo";
  rotData.style.cssText = "font-size:12px;color:var(--suave);text-transform:uppercase;letter-spacing:.04em";
  const inData = document.createElement("input");
  inData.type = "date";
  inData.value = nota.data_lembrete || "";
  inData.setAttribute("aria-label", "Data do lembrete");
  inData.style.cssText = "padding:7px 9px;border:1px solid var(--linha);border-radius:3px;"
    + "background:#fff;font:inherit;font-size:12.5px;color:var(--tinta)";
  rotData.htmlFor = inData.id = "edt-data-" + nota.id;

  const bSalvar = document.createElement("button");
  bSalvar.type = "button"; bSalvar.className = "btn-primario"; bSalvar.textContent = "Salvar";
  const bCancelar = document.createElement("button");
  bCancelar.type = "button"; bCancelar.className = "btn-secundario"; bCancelar.textContent = "Cancelar";

  const restaurar = () => { corpo.textContent = ""; original.forEach((n) => corpo.appendChild(n)); corpo.dataset.editando = "0"; };
  bCancelar.onclick = restaurar;

  bSalvar.onclick = async () => {
    const texto = ta.value.trim();
    if (!texto) { aviso("statusNotas", "A nota não pode ficar vazia.", true); ta.focus(); return; }
    bSalvar.disabled = true;
    const campos = { texto, data_lembrete: inData.value || null };
    try {
      if (!NA_EXTENSAO) { Object.assign(nota, campos); return renderTudo(); }
      if (nota.origem === "ind") {
        if (!sessao) return;
        await fsEditarNotaPessoal(sessao.uid, nota.id, campos);
        enviarBg({ tipo: "sincronizarPessoais" });
      } else {
        await fsEditarNota(nota.id, campos);
        enviarBg({ tipo: "sincronizarGabinete" });
      }
      aviso("statusNotas", "Nota atualizada.");
      await recarregar();
    } catch {
      aviso("statusNotas", "Não consegui salvar a edição. Verifique a conexão.", true);
      bSalvar.disabled = false;
    }
  };

  linhaCampos.append(rotData, inData, bSalvar, bCancelar);
  corpo.append(ta, linhaCampos);
  ta.focus();
  ta.setSelectionRange(ta.value.length, ta.value.length);
}

async function excluir(nota) {
  const msg = nota.origem === "gab"
    ? "Esta nota some para todos do gabinete. Não dá para desfazer."
    : "Esta nota será excluída. Não dá para desfazer.";
  if (!(await confirmar(msg, "Excluir", "Excluir nota"))) return;

  if (!NA_EXTENSAO) { notas = notas.filter((n) => n !== nota); return renderTudo(); }

  if (nota.origem === "ind") {
    if (!sessao) return;
    try {
      await fsExcluirNotaPessoal(sessao.uid, nota.id);
      enviarBg({ tipo: "sincronizarPessoais" });
    } catch {
      el("statusNotas").textContent = "Não consegui excluir no Firestore.";
      el("statusNotas").className = "status-linha ruim";
      return;
    }
  } else {
    try {
      await fsExcluirNota(nota.id);
      enviarBg({ tipo: "sincronizarGabinete" });
    } catch {
      el("statusNotas").textContent = "Não consegui excluir no Firestore.";
      el("statusNotas").className = "status-linha ruim";
      return;
    }
  }
  await recarregar();
}

function abrirProcesso(nota) {
  if (!nota.url) return;
  if (NA_EXTENSAO && api.tabs) api.tabs.create({ url: nota.url });
  else window.open(nota.url, "_blank");
}

/* ---------------- construção de uma linha de nota ---------------- */

function linhaNota(n, { comCnj = true } = {}) {
  const linha = document.createElement("div");
  linha.className = "nota" + (n.origem === "gab" ? " gab" : "") + (n.concluido ? " feito" : "");

  const espinha = document.createElement("div");
  espinha.className = "espinha";
  linha.appendChild(espinha);

  if (comCnj) linha.appendChild(cnjMini(n.cnj));

  // corpo
  const corpo = document.createElement("div");
  corpo.className = "corpo";
  const texto = document.createElement("div");
  texto.className = "texto";
  texto.textContent = n.texto;
  if (n.url) { texto.style.cursor = "pointer"; texto.title = "Abrir o processo no PJe"; texto.onclick = () => abrirProcesso(n); }
  corpo.appendChild(texto);

  const meta = document.createElement("div");
  meta.className = "meta";
  const tag = document.createElement("span");
  tag.className = "tag " + (n.origem === "gab" ? "gab" : "sua");
  tag.textContent = n.origem === "gab" ? "gabinete" : "privada";
  meta.appendChild(tag);
  if (n.origem === "gab") {
    const a = document.createElement("span");
    a.className = "autor"; a.textContent = n.autor || "gabinete";
    meta.appendChild(a);
    // Em quais gabinetes esta nota está publicada.
    const nomes = (n.grupos || []).map(nomeDoGrupo).filter(Boolean);
    if (nomes.length) {
      const g = document.createElement("span");
      g.textContent = nomes.join(" · ");
      meta.appendChild(g);
    }
  }
  if (n.concluido && n.concluido_por) {
    const c = document.createElement("span");
    c.textContent = "concluída por " + n.concluido_por;
    meta.appendChild(c);
  }
  corpo.appendChild(meta);
  linha.appendChild(corpo);

  // prazo + ações
  const prazo = document.createElement("div");
  prazo.className = "prazo" + (!n.concluido && venceu(n.data_lembrete) ? " venceu" : "");
  const t = document.createElement("time");
  t.textContent = dataCurta(n.data_lembrete);
  const q = document.createElement("div");
  q.className = "quando";
  q.textContent = n.concluido ? "concluída" : rotuloRelativo(n.data_lembrete);
  prazo.append(t, q);

  const acoes = document.createElement("div");
  acoes.className = "acoes";

  const bOk = document.createElement("button");
  bOk.type = "button";
  bOk.textContent = n.concluido ? "↩" : "✓";
  bOk.title = n.concluido ? "Reabrir" : "Concluir";
  bOk.setAttribute("aria-label", bOk.title);
  bOk.onclick = () => alternarConclusao(n);
  acoes.appendChild(bOk);

  const bEditar = document.createElement("button");
  bEditar.type = "button";
  bEditar.textContent = "✎";
  bEditar.title = "Editar";
  bEditar.setAttribute("aria-label", "Editar nota");
  bEditar.onclick = () => editarInline(n, linha);
  acoes.appendChild(bEditar);

  // Adiar só faz sentido enquanto a nota está pendente.
  if (!n.concluido) {
    const bAdiar = document.createElement("button");
    bAdiar.type = "button";
    bAdiar.textContent = "⏭";
    bAdiar.title = "Adiar 7 dias úteis";
    bAdiar.setAttribute("aria-label", "Adiar 7 dias úteis");
    bAdiar.onclick = () => adiar(n, 7);
    acoes.appendChild(bAdiar);
  }

  const bX = document.createElement("button");
  bX.type = "button";
  bX.className = "apagar"; bX.textContent = "×"; bX.title = "Excluir";
  bX.setAttribute("aria-label", "Excluir nota");
  bX.onclick = () => excluir(n);
  acoes.appendChild(bX);

  prazo.appendChild(acoes);

  linha.appendChild(prazo);
  return linha;
}

/* ---------------- PAINEL: carimbos + agenda ---------------- */

function carimbo(n, rotulo, classe) {
  const c = document.createElement("div");
  c.className = "carimbo" + (classe ? " " + classe : "");
  const num = document.createElement("div"); num.className = "n"; num.textContent = n;
  const rot = document.createElement("div"); rot.className = "r"; rot.textContent = rotulo;
  c.append(num, rot);
  return c;
}

function renderPainel() {
  const pend = notas.filter((n) => !n.concluido);
  const vencidos = pend.filter((n) => venceu(n.data_lembrete));
  const em7 = pend.filter((n) => n.data_lembrete && diasAte(n.data_lembrete) >= 0 && diasAte(n.data_lembrete) <= 7);
  const semPrazo = pend.filter((n) => !n.data_lembrete);
  const gabPend = pend.filter((n) => n.origem === "gab");
  const concl = notas.filter((n) => n.concluido);

  // Só o que cobra ação ganha carimbo. O resto é contexto e virou uma linha —
  // seis números do mesmo tamanho não diziam onde olhar primeiro.
  const cx = el("carimbos");
  cx.textContent = "";
  cx.append(
    carimbo(vencidos.length, "Vencidas", "vencidos"),
    carimbo(em7.length, "Próximos 7 dias", "semana"),
    carimbo(semPrazo.length, "Sem prazo")
  );

  const resumo = el("resumoLinha");
  resumo.textContent = "";
  for (const [rot, valor] of [
    ["Pendentes no total", pend.length],
    ["Do gabinete", gabPend.length],
    ["Concluídas", concl.length]
  ]) {
    const span = document.createElement("span");
    const b = document.createElement("b");
    b.textContent = String(valor);
    span.append(rot + " ", b);
    resumo.appendChild(span);
  }

  // buckets por vencimento
  const baldes = [
    { chave: "venc", titulo: "Vencidas", classe: "g-vencidos", filtro: (n) => venceu(n.data_lembrete) },
    { chave: "hoje", titulo: "Hoje", filtro: (n) => n.data_lembrete && diasAte(n.data_lembrete) === 0 },
    { chave: "amanha", titulo: "Amanhã", filtro: (n) => n.data_lembrete && diasAte(n.data_lembrete) === 1 },
    { chave: "semana", titulo: "Esta semana", filtro: (n) => n.data_lembrete && diasAte(n.data_lembrete) >= 2 && diasAte(n.data_lembrete) <= 7 },
    { chave: "depois", titulo: "Mais adiante", filtro: (n) => n.data_lembrete && diasAte(n.data_lembrete) > 7 },
    { chave: "sem", titulo: "Sem prazo definido", filtro: (n) => !n.data_lembrete }
  ];

  const alvo = el("agenda");
  alvo.textContent = "";
  let algo = false;

  for (const b of baldes) {
    const itens = pend.filter(b.filtro)
      .sort((a, z) => (a.data_lembrete || "9999").localeCompare(z.data_lembrete || "9999"));
    if (!itens.length) continue;
    algo = true;

    const grupo = document.createElement("div");
    grupo.className = "grupo" + (b.classe ? " " + b.classe : "");
    const h = document.createElement("h2");
    h.textContent = b.titulo;
    const cont = document.createElement("span");
    cont.className = "cont";
    cont.textContent = itens.length === 1 ? "1 nota" : `${itens.length} notas`;
    h.appendChild(cont);
    grupo.appendChild(h);

    const linhas = document.createElement("div");
    linhas.className = "linhas";
    itens.forEach((n) => linhas.appendChild(linhaNota(n)));
    grupo.appendChild(linhas);
    alvo.appendChild(grupo);
  }

  if (!algo) {
    alvo.appendChild(vazio(
      "Nada pendente por aqui.",
      "Abra um processo no PJe e anote — os lembretes com prazo aparecem nesta agenda."
    ));
  }
}

/* ---------------- TODAS AS NOTAS ---------------- */

function passaStatus(n) {
  if (filtroStatus === "pendentes") return !n.concluido;
  if (filtroStatus === "concluidos") return n.concluido;
  return true;
}
function passaOrigem(n) {
  return filtroOrigem === "todas" || n.origem === filtroOrigem;
}
function passaBusca(n) {
  if (!termoBusca) return true;
  const alvo = `${n.texto} ${n.autor || ""} ${n.cnj} ${n.cnj_digitos}`.toLowerCase();
  return alvo.includes(termoBusca);
}

function renderNotas() {
  const alvo = el("listaNotas");
  alvo.textContent = "";
  if (!el("statusNotas").classList.contains("ruim")) el("statusNotas").textContent = "";

  const filtradas = notas.filter((n) => passaStatus(n) && passaOrigem(n) && passaBusca(n))
    .sort((a, z) => {
      if (Boolean(a.concluido) !== Boolean(z.concluido)) return a.concluido ? 1 : -1;
      return (a.data_lembrete || "9999").localeCompare(z.data_lembrete || "9999");
    });

  if (!filtradas.length) {
    alvo.appendChild(vazio(
      "Nenhuma nota com esses filtros.",
      termoBusca ? "Tente outro termo de busca." : "Ajuste os filtros acima ou anote em um processo."
    ));
    return;
  }
  filtradas.forEach((n) => alvo.appendChild(linhaNota(n)));
}

/* ---------------- POR PROCESSO ---------------- */

function renderProcessos() {
  const alvo = el("listaProcessos");
  alvo.textContent = "";

  const porProc = new Map();
  for (const n of notas) {
    const k = n.cnj_digitos || n.cnj;
    if (!porProc.has(k)) porProc.set(k, { cnj: n.cnj, dig: k, itens: [] });
    porProc.get(k).itens.push(n);
  }
  if (!porProc.size) {
    alvo.appendChild(vazio("Nenhum processo com notas ainda.",
      "Assim que você anotar em um processo, ele aparece agrupado aqui."));
    return;
  }

  // processos com pendências mais urgentes primeiro
  const grupos = [...porProc.values()].sort((a, z) => {
    const pa = menorPrazoPendente(a.itens), pz = menorPrazoPendente(z.itens);
    return (pa || "9999").localeCompare(pz || "9999");
  });

  for (const g of grupos) {
    const pend = g.itens.filter((n) => !n.concluido).length;
    const det = document.createElement("details");
    det.className = "processo";
    det.dataset.dig = g.dig;          // permite focar o processo vindo do PJe
    det.open = pend > 0;

    const sum = document.createElement("summary");
    const esq = document.createElement("div");
    esq.className = "cnj-full-wrap";
    esq.append(cnjFull(g.cnj), botaoCopiar(g.cnj));
    sum.appendChild(esq);
    const cont = document.createElement("span");
    cont.className = "contagem";
    const total = g.itens.length;
    cont.textContent = "";
    const b = document.createElement("b"); b.textContent = String(pend);
    cont.append(b, ` pendente${pend === 1 ? "" : "s"} · ${total} no total`);
    sum.appendChild(cont);
    det.appendChild(sum);

    const miolo = document.createElement("div");
    miolo.className = "miolo linhas";
    g.itens
      .sort((a, z) => {
        if (Boolean(a.concluido) !== Boolean(z.concluido)) return a.concluido ? 1 : -1;
        return (a.data_lembrete || "9999").localeCompare(z.data_lembrete || "9999");
      })
      .forEach((n) => miolo.appendChild(linhaNota(n, { comCnj: false })));
    det.appendChild(miolo);
    alvo.appendChild(det);
  }
}

function menorPrazoPendente(itens) {
  return itens.filter((n) => !n.concluido && n.data_lembrete)
    .map((n) => n.data_lembrete).sort()[0] || null;
}

/* ---------------- AJUSTES & CONEXÃO ---------------- */

function renderAjustes() {
  const logado = Boolean(sessao);
  el("authDeslogado").hidden = logado || !NA_EXTENSAO;
  el("authLogado").hidden = !logado;
  el("cartaoGrupos").hidden = !logado;

  renderModelos();

  if (logado) {
    el("contaEmail").textContent = sessao.email || "—";
    // Não sobrescreve enquanto o usuário digita.
    if (document.activeElement !== el("perfilNome")) {
      el("perfilNome").value = perfil?.nome || "";
    }
    renderGrupos();
  }

  const estado = el("estadoFs");
  const conf = NA_EXTENSAO ? fsConfigurado() : false;
  if (!NA_EXTENSAO) {
    estado.className = "estado falta";
    estado.textContent = "Modo demonstração — conexão real indisponível fora da extensão.";
  } else if (!conf) {
    estado.className = "estado falta";
    estado.textContent = "Firestore ainda não configurado — preencha firestore.js (passos abaixo).";
  } else if (!logado) {
    estado.className = "estado falta";
    estado.textContent = "Entre na sua conta acima para ver e criar anotações.";
  } else if (!nomeAutor()) {
    estado.className = "estado falta";
    estado.textContent = "Falta definir seu nome — é obrigatório para criar anotações.";
  } else if (!tokensDosGrupos().length) {
    estado.className = "estado ok";
    estado.textContent = "Conectado. Crie ou entre num gabinete para compartilhar anotações.";
  } else {
    const n = tokensDosGrupos().length;
    estado.className = "estado ok";
    estado.textContent = `Conectado como ${nomeAutor()} · ${n} gabinete${n === 1 ? "" : "s"}.`;
  }
}

function renderGrupos() {
  const alvo = el("listaGrupos");
  alvo.textContent = "";
  const grupos = gruposDoPerfil();

  if (!grupos.length) {
    const p = document.createElement("p");
    p.style.cssText = "color:var(--suave);font-size:13px";
    p.textContent = "Você ainda não participa de nenhum gabinete.";
    alvo.appendChild(p);
    return;
  }

  for (const g of grupos) {
    const linha = document.createElement("div");
    linha.className = "grupo-item";

    const nome = document.createElement("span");
    nome.className = "g-nome";
    nome.textContent = g.nome || "(sem nome)";

    const cod = document.createElement("span");
    cod.className = "g-codigo";
    cod.textContent = g.token;

    const dir = document.createElement("div");
    dir.className = "g-dir";

    const bCopiar = document.createElement("button");
    bCopiar.type = "button";
    bCopiar.textContent = "Copiar código";
    bCopiar.onclick = () => copiarTexto(g.token, () => {
      bCopiar.textContent = "Copiado!";
      setTimeout(() => { bCopiar.textContent = "Copiar código"; }, 1500);
    });

    const bSair = document.createElement("button");
    bSair.type = "button";
    bSair.className = "sair";
    bSair.textContent = "Sair";
    bSair.title = "Remover este gabinete da sua conta";
    bSair.onclick = () => sairDoGrupo(g.token);

    dir.append(bCopiar, bSair);
    linha.append(nome, cod, dir);
    alvo.appendChild(linha);
  }
}

/* ---------------- boas-vindas (1ª execução) ----------------
   Os pré-requisitos (conta → nome → gabinete) existiam escondidos: cada um só
   aparecia quando o usuário tropeçava nele, e sempre como texto mandando ir a
   outra aba. Aqui viram uma sequência visível, com o botão junto do passo. */

function passoCartao(n, titulo, texto, feito, rotuloBotao, aoClicar) {
  const c = document.createElement("div");
  c.className = "passo-cartao" + (feito ? " feito" : "");
  const num = document.createElement("div");
  num.className = "num";
  num.textContent = feito ? "✓" : String(n);
  const corpo = document.createElement("div");
  const h = document.createElement("h3");
  h.textContent = titulo;
  const p = document.createElement("p");
  p.textContent = texto;
  corpo.append(h, p);
  if (!feito && rotuloBotao) {
    const acao = document.createElement("div");
    acao.className = "acao";
    const b = document.createElement("button");
    b.type = "button";
    b.className = "btn-primario";
    b.textContent = rotuloBotao;
    b.onclick = aoClicar;
    acao.appendChild(b);
    corpo.appendChild(acao);
  }
  c.append(num, corpo);
  return c;
}

function renderBemvindo() {
  const alvo = el("passos");
  if (!alvo) return;
  alvo.textContent = "";

  const temConta = Boolean(sessao);
  const temNome = Boolean(nomeAutor());
  const temGrupo = gruposDoPerfil().length > 0;

  alvo.append(
    passoCartao(1, "Sua conta",
      temConta ? `Conectado como ${sessao.email}.`
               : "Crie uma conta com e-mail e senha. Suas notas ficam nela e aparecem em qualquer computador.",
      temConta, "Criar conta ou entrar",
      () => { irPara("ajustes"); el("authEmail").focus(); }),

    passoCartao(2, "Seu nome",
      temNome ? `Você aparece como "${nomeAutor()}" nas notas do gabinete.`
              : "É o nome que aparece como autor nas anotações compartilhadas. Só precisa disso para o gabinete — notas privadas não pedem nome.",
      temNome, "Definir meu nome",
      () => { irPara("ajustes"); el("perfilNome").focus(); }),

    passoCartao(3, "Gabinete (opcional)",
      temGrupo ? gruposDoPerfil().map((g) => g.nome || "gabinete").join(" · ")
               : "Para dividir anotações com o resto do gabinete. Dá para pular e fazer depois — notas privadas já funcionam.",
      temGrupo, "Criar ou entrar num gabinete",
      () => { irPara("ajustes"); el("novoGrupoNome").focus(); })
  );

  const fim = document.createElement("p");
  fim.className = "sub";
  fim.style.marginTop = "18px";
  fim.textContent = temConta
    ? "Pronto. Abra um processo no PJe e clique em “✚ nota” ao lado do número — a nota é escrita ali mesmo."
    : "Depois da conta, abra um processo no PJe: aparece um “✚ nota” ao lado do número.";
  alvo.appendChild(fim);
}

/* ---------------- conta: entrar / criar / sair / nome ---------------- */

// Erro NÃO some sozinho: é a única explicação do que deu errado e quem lê
// devagar (ou foi interrompido) perderia. Só o sucesso se apaga.
function aviso(id, msg, ruim = false, ms = 5000) {
  const alvo = el(id);
  alvo.textContent = msg;
  alvo.className = "status-linha" + (ruim ? " ruim" : "");
  if (msg && !ruim) setTimeout(() => { if (alvo.textContent === msg) alvo.textContent = ""; }, ms);
}

const avisoConta = (msg, ruim = false) => aviso("statusConta", msg, ruim);
const avisoGrupos = (msg, ruim = false) => aviso("statusGrupos", msg, ruim, 6000);

/* --- Entrar OU criar conta ---
   Os dois botões lado a lado levavam ao cadastro acidental: quem errava o
   e-mail criava uma conta nova, entrava nela e só descobria dias depois, ao
   tentar logar com o e-mail certo. Agora é uma escolha explícita, com
   confirmação de senha e o aviso de que a sessão não expira. */
let modoConta = "entrar";

function aplicarModoConta(modo) {
  modoConta = modo;
  const criando = modo === "criar";
  el("campoConfirma").hidden = !criando;
  el("avisoSessao").hidden = !criando;
  el("btnAcaoConta").textContent = criando ? "Criar minha conta" : "Entrar";
  el("authSenha").setAttribute("autocomplete", criando ? "new-password" : "current-password");
  el("authSenha").placeholder = criando ? "Crie uma senha (mín. 6)" : "Sua senha";
}

if (NA_EXTENSAO) {
  ligarRadiogroup(document.querySelector(".modo-conta"), (b) => aplicarModoConta(b.dataset.modo));
  aplicarModoConta("entrar");

  el("olhoSenha").onclick = () => {
    const campo = el("authSenha");
    const mostrando = campo.type === "text";
    campo.type = mostrando ? "password" : "text";
    el("authConfirma").type = campo.type;
    el("olhoSenha").setAttribute("aria-pressed", String(!mostrando));
    el("olhoSenha").setAttribute("aria-label", mostrando ? "Mostrar senha" : "Ocultar senha");
    campo.focus();
  };

  el("formConta").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const email = el("authEmail").value.trim();
    const senha = el("authSenha").value;
    if (!email || !senha) { avisoConta("Preencha e-mail e senha.", true); return; }

    if (modoConta === "criar") {
      if (senha.length < 6) {
        avisoConta("A senha precisa ter ao menos 6 caracteres.", true); return;
      }
      if (senha !== el("authConfirma").value) {
        avisoConta("As duas senhas não são iguais. Confira antes de criar a conta.", true);
        el("authConfirma").focus();
        return;
      }
    }

    const btn = el("btnAcaoConta");
    const rotulo = btn.textContent;
    btn.disabled = true;
    btn.textContent = modoConta === "criar" ? "Criando…" : "Entrando…";
    try {
      await (modoConta === "criar" ? criarConta : entrar)(email, senha);
      el("authSenha").value = "";
      el("authConfirma").value = "";
      avisoConta(modoConta === "criar" ? "Conta criada e sessão iniciada." : "Login efetuado.");
      enviarBg({ tipo: "sincronizarPessoais" });
      enviarBg({ tipo: "sincronizarGabinete" });
      await recarregar();
      if (!nomeAutor()) el("perfilNome").focus();
    } catch (e) {
      avisoConta(traduzErroAuth(e.message), true);
    } finally {
      btn.disabled = false;
      btn.textContent = rotulo;
    }
  });

  el("lnkEsqueci").onclick = async (ev) => {
    ev.preventDefault();
    const email = el("authEmail").value.trim();
    if (!email) { avisoConta("Informe o e-mail para redefinir a senha.", true); return; }
    try {
      await resetSenha(email);
      avisoConta("E-mail de redefinição enviado. Confira a caixa de entrada e o spam.");
    } catch (e) {
      avisoConta(traduzErroAuth(e.message), true);
    }
  };

  el("btnSair").onclick = async () => {
    await sair();
    avisoConta("Você saiu da conta.");
    enviarBg({ tipo: "sincronizarPessoais" });
    enviarBg({ tipo: "sincronizarGabinete" });
    await recarregar();
  };

  el("btnSalvarNome").onclick = async () => {
    if (!sessao) return;
    const nome = el("perfilNome").value.trim();
    if (!nome) { avisoConta("Informe um nome.", true); return; }
    el("btnSalvarNome").disabled = true;
    try {
      perfil = await fsSalvarPerfil(sessao.uid, { nome, grupos: gruposDoPerfil() });
      avisoConta("Nome salvo.");
      renderTudo();
      pintarCabecalho();
    } catch {
      avisoConta("Não consegui salvar o nome. Verifique a conexão.", true);
    } finally {
      el("btnSalvarNome").disabled = false;
    }
  };

  el("btnCriarGrupo").onclick = async () => {
    if (!sessao) return;
    const nome = el("novoGrupoNome").value.trim();
    if (!nome) { avisoGrupos("Dê um nome ao gabinete.", true); return; }
    el("btnCriarGrupo").disabled = true;
    try {
      const novos = [...gruposDoPerfil(), { token: novoCodigoGrupo(), nome }];
      el("novoGrupoNome").value = "";
      await salvarGrupos(novos, `Gabinete "${nome}" criado — compartilhe o código de acesso.`);
    } catch {
      avisoGrupos("Não consegui criar o gabinete.", true);
    } finally {
      el("btnCriarGrupo").disabled = false;
    }
  };

  el("btnEntrarGrupo").onclick = async () => {
    if (!sessao) return;
    const codigo = el("entrarGrupoCodigo").value.trim();
    const nome = el("entrarGrupoNome").value.trim() || "Gabinete";
    if (codigo.length < 8) {
      avisoGrupos("Código de acesso inválido (mínimo 8 caracteres).", true); return;
    }
    if (tokensDosGrupos().includes(codigo)) {
      avisoGrupos("Você já participa desse gabinete.", true); return;
    }
    el("btnEntrarGrupo").disabled = true;
    try {
      const novos = [...gruposDoPerfil(), { token: codigo, nome }];
      el("entrarGrupoCodigo").value = "";
      el("entrarGrupoNome").value = "";
      await salvarGrupos(novos, `Você entrou em "${nome}".`);
    } catch {
      avisoGrupos("Não consegui entrar no gabinete.", true);
    } finally {
      el("btnEntrarGrupo").disabled = false;
    }
  };
}

/* ---------------- gabinetes ---------------- */

// O código é a chave de acesso do gabinete: precisa ser impossível de adivinhar.
function novoCodigoGrupo() {
  const abc = "abcdefghjkmnpqrstuvwxyz23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  let s = "";
  for (const b of bytes) s += abc[b % abc.length];
  return `GAB-${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}-${s.slice(12)}`;
}

async function salvarGrupos(grupos, msgOk) {
  perfil = await fsSalvarPerfil(sessao.uid, { nome: nomeAutor(), grupos });
  avisoGrupos(msgOk);
  enviarBg({ tipo: "sincronizarGabinete" });
  await recarregar();
}

async function sairDoGrupo(token) {
  const ok = await confirmar(
    "As anotações continuam existindo para os outros participantes — você só deixa de vê-las.",
    "Sair do gabinete", "Sair do gabinete");
  if (!ok) return;
  try {
    await salvarGrupos(gruposDoPerfil().filter((g) => g.token !== token), "Você saiu do gabinete.");
  } catch {
    avisoGrupos("Não consegui sair do gabinete.", true);
  }
}

// Quem já usava o token único do storage.sync entra nele automaticamente.
async function migrarTokenLegado() {
  if (!sessao || !config.token) return;
  if (tokensDosGrupos().includes(config.token)) return;
  try {
    const grupos = [...gruposDoPerfil(), { token: config.token, nome: "Gabinete" }];
    perfil = await fsSalvarPerfil(sessao.uid, { nome: nomeAutor(), grupos });
  } catch { /* sem conexão: tenta de novo na próxima carga */ }
}

/* ---------------- utilidades de UI ---------------- */

function vazio(grande, pequeno) {
  const d = document.createElement("div");
  d.className = "vazio";
  const g = document.createElement("div"); g.className = "grande"; g.textContent = grande;
  const p = document.createElement("div"); p.textContent = pequeno;
  d.append(g, p);
  return d;
}

function renderTudo() {
  renderPainel();
  renderNotas();
  renderProcessos();
  renderAjustes();
  if (el("v-bemvindo") && !el("v-bemvindo").hidden) renderBemvindo();
}

// Enquanto a rede responde, mostra a forma do conteúdo em vez de tela branca.
function esqueletoPainel() {
  for (const id of ["agenda", "listaNotas", "listaProcessos"]) {
    const alvo = el(id);
    if (!alvo) continue;
    alvo.textContent = "";
    const d = document.createElement("div");
    d.className = "esqueleto";
    for (let i = 0; i < 4; i++) d.appendChild(document.createElement("div"));
    alvo.appendChild(d);
  }
}

/* ---------------- roteamento por hash (#/painel etc.) ---------------- */

// "bemvindo" não tem link na navegação: é a vista da primeira execução,
// alcançada por #/bemvindo (o service worker abre nela ao instalar).
const VISTAS = ["painel", "notas", "processos", "ajustes", "bemvindo"];
function irPara(vista) {
  if (!VISTAS.includes(vista)) vista = "painel";
  document.querySelectorAll("nav.abas a").forEach((a) =>
    a.classList.toggle("ativa", a.dataset.vista === vista));
  VISTAS.forEach((v) => { el("v-" + v).hidden = v !== vista; });
  if (vista === "bemvindo") renderBemvindo();
  if (location.hash !== "#/" + vista) history.replaceState(null, "", "#/" + vista);
}
document.querySelectorAll("nav.abas a").forEach((a) => {
  a.onclick = (e) => { e.preventDefault(); irPara(a.dataset.vista); };
});
window.addEventListener("hashchange", () => irPara((location.hash.split("/")[1]) || "painel"));

/* ---------------- filtros e busca ---------------- */

ligarRadiogroup(el("filtroOrigem"), (b) => { filtroOrigem = b.dataset.o; renderNotas(); });
ligarRadiogroup(el("filtroStatus"), (b) => { filtroStatus = b.dataset.s; renderNotas(); });
el("busca").oninput = (e) => { termoBusca = e.target.value.trim().toLowerCase(); renderNotas(); };

// alert() bloqueia a página e não é anunciado como mensagem: o recado vai
// para a própria linha do atalho.
const RECADO_POPUP = "Clique no ícone da extensão na barra do navegador (ou tecle Alt+Shift+L).";
el("abrirPopup").onclick = (e) => {
  e.preventDefault();
  const alvo = el("recadoPopup");
  if (NA_EXTENSAO && api.action && api.action.openPopup) {
    api.action.openPopup().catch(() => { alvo.textContent = RECADO_POPUP; });
  } else {
    alvo.textContent = RECADO_POPUP;
  }
};

// Dispara pelo service worker a mesma notificação (e o mesmo som) do dia do
// lembrete, mais o resumo de vencidas se houver — teste de ponta a ponta.
/* ---------------- modelos de nota ---------------- */

let modelosNota = null;

async function renderModelos() {
  if (modelosNota === null) modelosNota = [...(await lerModelos()).modelos];
  const ul = el("listaModelos");
  ul.textContent = "";
  if (!modelosNota.length) {
    const li = document.createElement("li");
    li.className = "vazio-modelos";
    li.textContent = "Nenhum modelo ainda. Adicione a primeira frase abaixo.";
    ul.appendChild(li);
    return;
  }
  modelosNota.forEach((t, i) => {
    const li = document.createElement("li");
    const s = document.createElement("span");
    s.textContent = t;
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = "×";
    b.title = "Remover";
    b.setAttribute("aria-label", "Remover: " + t);
    b.onclick = () => { modelosNota.splice(i, 1); salvarModelos("Frase removida."); };
    li.append(s, b);
    ul.appendChild(li);
  });
}

async function salvarModelos(msg) {
  renderModelos();
  try {
    await api.storage.sync.set({ modelosNota });
    aviso("statusModelos", msg);
  } catch {
    aviso("statusModelos", "Não consegui salvar os modelos.", true);
  }
}

el("formModelo").onsubmit = (e) => {
  e.preventDefault();
  const t = el("novoModelo").value.trim();
  if (!t) return;
  if (modelosNota.includes(t)) { aviso("statusModelos", "Essa frase já está na lista.", true); return; }
  if (modelosNota.length >= 20) { aviso("statusModelos", "Limite de 20 modelos. Remova algum antes.", true); return; }
  modelosNota.push(t);
  el("novoModelo").value = "";
  el("novoModelo").focus();
  salvarModelos("Frase adicionada.");
};

el("btnTestarNotif").onclick = async () => {
  const alvo = el("statusNotif");
  if (!NA_EXTENSAO) { alvo.textContent = "Disponível só dentro da extensão."; return; }
  el("btnTestarNotif").disabled = true;
  alvo.textContent = "Enviando…";
  try {
    const r = await api.runtime.sendMessage({ tipo: "testarNotificacoes" });
    if (r?.ok) {
      alvo.textContent = r.vencidas
        ? `Notificação de teste enviada + resumo: ${r.vencidas} vencida(s). Não apareceu? Verifique as permissões de notificação do navegador e do sistema.`
        : "Notificação de teste enviada. Não apareceu? Verifique as permissões de notificação do navegador e do sistema.";
    } else {
      alvo.textContent = r?.erro || "Não consegui enviar a notificação.";
    }
  } catch {
    alvo.textContent = "Não consegui falar com o service worker — recarregue a extensão.";
  } finally {
    el("btnTestarNotif").disabled = false;
  }
};

/* ---------------- atualizar / partida ---------------- */

async function recarregar() {
  const btn = el("btnAtualizar");
  btn.disabled = true;
  esqueletoPainel();
  try { await carregarTudo(); renderTudo(); pintarCabecalho(); }
  finally { btn.disabled = false; }
}
el("btnAtualizar").onclick = recarregar;

function pintarCabecalho() {
  el("quem").textContent = nomeAutor() || (sessao && sessao.email)
    || (NA_EXTENSAO ? "sem conta conectada" : "Ana (demonstração)");
  const pino = el("pinoFonte");
  const txt = el("estadoFonte");
  if (!NA_EXTENSAO) { pino.className = "pino off"; txt.textContent = "modo demonstração"; return; }
  const n = tokensDosGrupos().length;
  const partes = [];
  if (sessao) partes.push("conta conectada");
  if (n) partes.push(n === 1 ? "1 gabinete" : `${n} gabinetes`);
  pino.className = "pino" + (sessao ? "" : " off");
  txt.textContent = partes.length ? partes.join(" · ") : "sem conexão";
}

async function iniciar() {
  if (!NA_EXTENSAO) { el("demoFita").hidden = false; config = { nome: "Ana" }; }
  esqueletoPainel();
  await carregarTudo();
  pintarCabecalho();
  renderTudo();
  const termo = await focoDeBusca();
  if (termo) {
    el("busca").value = termo;
    termoBusca = termo.toLowerCase();
    irPara("notas");
    renderNotas();
    return;
  }
  irPara((location.hash.split("/")[1]) || "painel");
}

// Veio do clique num selo do PJe: abrir já filtrado por aquele processo.
async function focoDeBusca() {
  if (!NA_EXTENSAO) return null;
  try {
    const { focoBusca } = await api.storage.local.get("focoBusca");
    if (!focoBusca?.termo || Date.now() - (focoBusca.em || 0) > 60000) return null;
    await api.storage.local.remove("focoBusca");
    return focoBusca.termo;
  } catch { return null; }
}

/* ---------------- dados de demonstração ---------------- */

function maisDias(n) {
  const d = new Date(); d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}
const DEMO = [
  { id: "gab|1", origem: "gab", cnj: "0001234-56.2026.8.05.0001", cnj_digitos: "00012345620268050001",
    texto: "Minutar decisão sobre a tutela de urgência antes da audiência.", autor: "Ana",
    data_lembrete: maisDias(-2), concluido: false, concluido_por: null, concluido_em: null },
  { id: "nota:00012345620268050001", origem: "ind", cnj: "0001234-56.2026.8.05.0001", cnj_digitos: "00012345620268050001",
    texto: "Conferir se a petição inicial juntou a procuração atualizada.", autor: null,
    data_lembrete: maisDias(0), concluido: false, url: "https://pje.tjba.jus.br/" },
  { id: "gab|2", origem: "gab", cnj: "0007788-99.2026.8.05.0113", cnj_digitos: "00077889920268050113",
    texto: "Aguardar manifestação do MP sobre o parecer — prazo em 5 dias.", autor: "Carlos",
    data_lembrete: maisDias(1), concluido: false, concluido_por: null, concluido_em: null },
  { id: "nota:00077889920268050113", origem: "ind", cnj: "0007788-99.2026.8.05.0113", cnj_digitos: "00077889920268050113",
    texto: "Revisar cálculo de honorários antes de encaminhar para assinatura.", autor: null,
    data_lembrete: maisDias(4), concluido: false, url: "https://pje.tjba.jus.br/" },
  { id: "gab|3", origem: "gab", cnj: "0003456-12.2025.8.05.0039", cnj_digitos: "00034561220258050039",
    texto: "Publicar sentença e intimar as partes.", autor: "Ana",
    data_lembrete: maisDias(12), concluido: false, concluido_por: null, concluido_em: null },
  { id: "nota:00034561220258050039", origem: "ind", cnj: "0003456-12.2025.8.05.0039", cnj_digitos: "00034561220258050039",
    texto: "Sem prazo, mas lembrar de anexar o laudo pericial ao voto.", autor: null,
    data_lembrete: null, concluido: false, url: "https://pje.tjba.jus.br/" },
  { id: "gab|4", origem: "gab", cnj: "0009999-01.2026.8.05.0001", cnj_digitos: "00099990120268050001",
    texto: "Despacho de saneamento concluído e assinado.", autor: "Carlos",
    data_lembrete: maisDias(-6), concluido: true, concluido_por: "Ana", concluido_em: maisDias(-5) }
];

iniciar();
