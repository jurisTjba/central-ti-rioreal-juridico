/* =========================================================================
   comum.js — utilitários compartilhados entre popup.js e options.js
   (datas sempre no fuso local, CNJ e segmentos do Judiciário).

   Carregado como <script> ANTES dos dois arquivos, então tudo aqui é
   global e NÃO pode ser redeclarado em quem consome (senão o navegador
   estoura "Identifier already declared").
   ========================================================================= */

const SEGMENTOS = {
  1: "STF", 2: "CNJ", 3: "STJ", 4: "Just. Federal", 5: "Just. do Trabalho",
  6: "Just. Eleitoral", 7: "Just. Militar da União", 8: "Just. Estadual",
  9: "Just. Militar Estadual"
};

const el = (id) => document.getElementById(id);

/* ---------- link do processo no PJe ----------
   O Seam derruba a aba em error.seam?cid=... quando a conversa expira. Notas
   gravadas nesse instante ficaram com um link que só reabre o erro. */

const LINK_ERRO = /\/error\.seam/i;
const LINK_PROCESSO = /listAutosDigitais\.seam|ConsultaProcesso|[?&]idProcesso=/i;

const linkUtil = (u) => (u && LINK_PROCESSO.test(u) && !LINK_ERRO.test(u)) ? u : null;

/* ---------- datas no fuso local ---------- */

function hoje() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

// "2026-07-20" -> Date local. new Date(str) leria como UTC e erraria um dia.
function deISO(iso) {
  const [a, m, d] = iso.split("-").map(Number);
  return new Date(a, m - 1, d);
}

const diasAte = (iso) => Math.round((deISO(iso) - hoje()) / 86400000);
const venceu = (iso) => Boolean(iso) && diasAte(iso) < 0;

// "2026-07-20" -> "20/07". Sem data, usa o rótulo `vazio` (varia por tela).
function dataCurta(iso, vazio = "—") {
  if (!iso) return vazio;
  const [, m, d] = iso.split("-");
  return `${d}/${m}`;
}

// "2026-08-28" -> "28/08/2026" (linha de prévia do prazo).
function dataLonga(iso) {
  if (!iso) return "";
  const [a, m, d] = iso.split("-");
  return `${d}/${m}/${a}`;
}

// Rótulo relativo ao hoje: "venceu há 2 dias", "hoje", "amanhã", "em 5 dias".
function rotuloRelativo(iso) {
  if (!iso) return "sem prazo";
  const n = diasAte(iso);
  if (n < 0) return `venceu há ${-n} ${-n === 1 ? "dia" : "dias"}`;
  if (n === 0) return "hoje";
  if (n === 1) return "amanhã";
  if (n <= 7) return `em ${n} dias`;
  return deISO(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "long" });
}

/* ---------- CNJ ---------- */

const digitosDe = (cnj) => (cnj || "").replace(/\D/g, "");

function decompor(numero) {
  const [seq, resto] = numero.split("-");
  const [dv, ano, j, tr, origem] = resto.split(".");
  return { seq, dv, ano, j, tr, origem };
}

/* ---------- agenda: em que balde a nota cai ---------- */

const BALDES = [
  { chave: "venc",   titulo: "Vencidas" },
  { chave: "hoje",   titulo: "Hoje" },
  { chave: "amanha", titulo: "Amanhã" },
  { chave: "semana", titulo: "Esta semana" },
  { chave: "depois", titulo: "Mais adiante" },
  { chave: "sem",    titulo: "Sem prazo" }
];

function baldeDe(n) {
  if (!n.data_lembrete) return "sem";
  const d = diasAte(n.data_lembrete);
  if (d < 0) return "venc";
  if (d === 0) return "hoje";
  if (d === 1) return "amanha";
  if (d <= 7) return "semana";
  return "depois";
}

/* ---------- modelos de nota (Ajustes) e textos recentes ---------- */

const MODELOS_PADRAO = [
  "Aguardando resposta do ofício",
  "Cobrar devolução do mandado",
  "Incluir em pauta",
  "Falei com ___, aguardando retorno"
];

async function lerModelos() {
  let modelos = MODELOS_PADRAO;
  let recentes = [];
  try {
    const s = await api.storage.sync.get("modelosNota");
    if (Array.isArray(s.modelosNota)) modelos = s.modelosNota;
  } catch (_) { /* sem storage */ }
  try {
    const l = await api.storage.local.get("textosRecentes");
    if (Array.isArray(l.textosRecentes)) recentes = l.textosRecentes;
  } catch (_) { /* sem storage */ }
  return { modelos, recentes: recentes.filter((t) => !modelos.includes(t)) };
}

async function registrarTextoRecente(texto) {
  const t = String(texto || "").trim().slice(0, 200);
  if (!t) return;
  try {
    const { textosRecentes = [] } = await api.storage.local.get("textosRecentes");
    const lista = [t, ...textosRecentes.filter((x) => x !== t)].slice(0, 6);
    await api.storage.local.set({ textosRecentes: lista });
  } catch (_) { /* sem storage */ }
}

// Chips acima do textarea: clicou, o texto entra na nota.
async function montarChipsModelos(container, textarea) {
  const { modelos, recentes } = await lerModelos();
  container.textContent = "";
  const itens = [
    ...modelos.map((t) => ({ t, recente: false })),
    ...recentes.map((t) => ({ t, recente: true }))
  ];
  container.hidden = !itens.length;
  for (const { t, recente } of itens) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "modelo" + (recente ? " recente" : "");
    b.textContent = t.length > 40 ? t.slice(0, 38) + "…" : t;
    b.title = recente ? "Usado há pouco: " + t : t;
    b.onclick = () => {
      const atual = textarea.value.trim();
      textarea.value = atual ? atual + "\n" + t : t;
      textarea.focus();
    };
    container.appendChild(b);
  }
}
